import sqlite3

# Database configuration
DB_FILE = 'reservations.db'

# Function to check availability
def check_availability(start_date, end_date):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM reservations WHERE start_date <= ? AND end_date >= ?",
              (end_date, start_date))
    count = c.fetchone()[0]
    conn.close()
    return count == 0

# Function to create a reservation record
def create_reservation(start_date, end_date, customer_id):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("INSERT INTO reservations (start_date, end_date, customer_id) VALUES (?, ?, ?)",
              (start_date, end_date, customer_id))
    reservation_id = c.lastrowid
    conn.commit()
    conn.close()
    return reservation_id
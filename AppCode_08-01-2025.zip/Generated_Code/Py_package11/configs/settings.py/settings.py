# Server settings
SERVER_HOST = '0.0.0.0'
SERVER_PORT = 5000
DEBUG = True
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 12:44:11 2022

@author: aishwarya.a.raj
"""

from ai_core.configs.settings import APP_SERVICE_UID,ProductEntityClientPropertyValues,CONNECT_TIMEOUT,READ_TIMEOUT
from ai_core.commons import (_get_request_api_kwargs_,invoke_api ,get_logger)
#from ai_core.cache import error_hook
from phoenixconstants import attr, WorkItem , TestCase
from typing import List,Union,Dict
from ai_core.cache import CacheManager 
from uuid import UUID
import json
import sys,traceback
from dataclasses import dataclass, field

uid_or_str = Union[UUID,str]
int_or_flot = Union[int,float]
uid_list = field(init=False, default_factory=list)
w=WorkItem()
timeout=(CONNECT_TIMEOUT, READ_TIMEOUT)

logger = get_logger(name='CNModule',app="CNModule" ,filename='rsp_run.log')

@dataclass
class CacheKey:
    clientUid: uid_or_str
    dcUId: uid_or_str
    entityUId: uid_or_str
    workItemTypeUId: uid_or_str
    entity_attributes = ['StateUId', 'PriorityUId', 'TypeUId','State','Priority','Type']
    
    def __post_init__(self):
        if self.workItemTypeUId is None:
            self.workItemTypeUId = 'None'
    
    def get_key(self) -> str:
       
        return APP_SERVICE_UID+'/'+self.clientUid+'/'+self.dcUId+'/'+self.entityUId+'/'+self.workItemTypeUId
        
    def get_formated_attr_keys(self,attrs) -> List[str]:
        if not attrs:
            # default attributes to format
            attrs = self.entity_attributes
        formated_keys = []
        for i in attrs:
            formated_keys.append(self.get_key() + '/' + i)
        return formated_keys
    
    def get_entity_attributes(self) ->List[str]:
        return self.entity_attributes  
    
    



def fetch_store(cache_key, attrs, error_hook=None):
    """ call productEntityProperty api, store required attributes
    'simplified' response in both redis & SQLite db
    """

    fetch_store_state = False
    if not attrs:
        attrs = cache_key.get_entity_attributes()
    
    
    
    try:
        kwargs = dict(clientUId=str(cache_key.clientUid), deliveryConstructUId=cache_key.dcUId)
        criteria = dict(clientUId=str(cache_key.clientUid),
                        deliveryConstructUId=str(cache_key.dcUId), 
                        EntityUId=str(cache_key.entityUId) )
        if criteria['EntityUId'] == WorkItem().s_uid:
            criteria['WorkItemTypeUId'] = str(cache_key.workItemTypeUId)
        kwargs['criteria']=criteria
        req=_get_request_api_kwargs_(ProductEntityClientPropertyValues,timeout,kwargs)
        logger.info("Invoking ProductEntity API")
        resp, errors = invoke_api(req,"POST")
        if errors:
            tb = traceback.format_exc().split("\n")
            logger.error(tb)
            #error_hook(errors)
            return False, str(resp)#.status_code) +" error while calling ProductEntityAPI" 

        
        if resp  and resp.status_code == 200:
                
            resp = resp.json()

            if not isinstance(resp['EntityPropertyValues'],List) or 'EntityPropertyValues' not in resp :
                msg = "Invalid json response EntityProperty value key missing"
                error_hook(msg)
                logger.error(msg)
                return False,msg
                #raise Exception("Invalid json response EntityProperty value key missing")
            #resp_req = required attributes reponse
            resp_req=[]
            state_cdms,priority_cdms,type_cdms = dict(),dict(),dict()
            state_str,priority_str,type_str = dict(),dict(),dict()
            for attributes in resp['EntityPropertyValues']:
                if attributes['Name'] in cache_key.get_entity_attributes() :
                    resp_req.append(attributes)
        
            if str(cache_key.entityUId) == w.s_uid and len(resp_req)!=3:
                if str(cache_key.workItemTypeUId) != w.risk.s_uid:
                    msg = "Missing response of either or any of State,Type, Priority attributes from api response"
                    error_hook(msg)
                    logger.error(msg)
                    return False,msg
                #raise Exception("Missing response of either or any entity attributes from api response ")
            for attributes in resp_req:
                if attributes['Name'] == 'StateUId':
                    if len(attributes['Values']) == 0:
                        error_hook("Invalid StateUId response")
                        raise Exception("Invalid StateUId response")
                    for j in attributes['Values'] :
                        cdmUId = j['EntityPropertyIdValue']
                        nativeuid = j['ProductPropertyValueUId']
                        if j['ProductPropertyValueDisplayName'] is not None and 'test' in j['ProductPropertyValueDisplayName'].lower():
                            cdmstr = 'Test'
                        else:
                            cdmstr = j['EntityPropertyValue']
                        cdmstr = j['EntityPropertyValue']
                        cnstr = j['ProductPropertyValue']
                        value_str=(nativeuid,cnstr,cdmstr)
                        #breakpoint()
                        if cdmUId  in state_cdms:
                            state_cdms[cdmUId].append(nativeuid)
                        else:
                            state_cdms[cdmUId] = list()
                            state_cdms[cdmUId].append(nativeuid)
                        if cdmUId + '_str' in state_str:
                            state_str[cdmUId + '_str'].append(value_str)
                        else:
                            state_str[cdmUId+ '_str'] = list()
                            state_str[cdmUId+ '_str'].append(value_str)
                       
                elif attributes['Name'] == 'PriorityUId':
                    if len(attributes['Values']) == 0:
                        error_hook("Invalid PriorityUId response")
                        raise Exception("Invalid PriorityUId response")
                    for j in attributes['Values'] :
                        cdmUId = j['EntityPropertyIdValue']
                        nativeuid = j['ProductPropertyValueUId']
                        cdmstr = j['EntityPropertyValue']
                        cnstr = j['ProductPropertyValue']
                        value_str=(nativeuid,cnstr,cdmstr)
                        
                        if cdmUId in priority_cdms:
                            priority_cdms[cdmUId].append(nativeuid)
                        else:
                            priority_cdms[cdmUId] = list()
                            priority_cdms[cdmUId].append(nativeuid)
                        if cdmUId + '_str' in priority_str:
                            priority_str[cdmUId + '_str'].append(value_str)
                        else:
                            priority_str[cdmUId+ '_str'] = list()
                            priority_str[cdmUId+ '_str'].append(value_str)
                elif attributes['Name'] == 'TypeUId':
                    if len(attributes['Values']) == 0:
                        error_hook("Invalid TypeUid response")
                        raise Exception("Invalid TypeUid response")
                    for j in attributes['Values'] :
                        cdmUId = j['EntityPropertyIdValue']
                        nativeuid = j['ProductPropertyValueUId']
                        cdmstr = j['EntityPropertyValue']
                        cnstr = j['ProductPropertyValue']
                        value_str=(nativeuid,cnstr,cdmstr)
                        if cdmUId  in type_cdms:
                            type_cdms[cdmUId].append(nativeuid)
                        else:
                            type_cdms[cdmUId] = list()
                            type_cdms[cdmUId].append(nativeuid)
                        if cdmUId + '_str' in type_str:
                            type_str[cdmUId + '_str'].append(value_str)
                        else:
                            type_str[cdmUId+ '_str'] = list()
                            type_str[cdmUId+ '_str'].append(value_str)
            
            key =cache_key.get_key()
            cache_obj=CacheManager.connect()
            #cdbw = DBCacheManagerWrapper()
            cache_obj.set(key, resp_req)
            unique_key = cache_key.get_formated_attr_keys(['StateUId','PriorityUId','TypeUId','State','Priority','Type'])
            cache_obj.set(unique_key[0], state_cdms) #set State
            # priority_key = cache_key.get_formated_attr_keys('PriorityUId')
            cache_obj.set(unique_key[1], priority_cdms) #Priority
            # type_key = cache_key.get_formated_attr_keys('TypeUId')
            cache_obj.set(unique_key[2], type_cdms)
            cache_obj.set(unique_key[3], state_str) #set State
            # priority_key = cache_key.get_formated_attr_keys('PriorityUId')
            cache_obj.set(unique_key[4], priority_str) #Priority
            # type_key = cache_key.get_formated_attr_keys('TypeUId')
            cache_obj.set(unique_key[5], type_str)
            fetch_store_state = True
            return fetch_store_state,"CN Response successfully cached"
           
            
    except  Exception as e:
        tb = traceback.format_exc().split("\n")
        logger.error(tb)
        return False, str(tb)
    
    
def is_key_present_in_cache(cache_key, error_hook) -> bool:
    found = False
    try:
        cache_obj=CacheManager.connect()
        #cdbw = DBCacheManagerWrapper()
        """conenct to redis
        find key 
        if key_found:
            found = True"""
        if cache_obj.exists(cache_key)== 1:
            found= True
    #except RedisConnectionError:
    except Exception as e:
        
         if error_hook:
             error_hook(e)
        #     cdb.open('cache_db')
        #     if cdb.exists(cache_key) == 1:
        #         found= True
            
       
    return found
    
def get_cdm_mapping(cache_key: CacheKey, entity_attributes: List[str], error_hook=None) -> dict:
    """
    return { attr1: {cdm_active: [], cdm_closed: []},
             attr2: {cdm_active: [], cdm_closed: []},
            }
    """
    mappings = []
    attr_cache_keys:list = cache_key.get_formated_attr_keys(entity_attributes) 
    cache_obj=CacheManager.connect()
    #cdbw = DBCacheManagerWrapper()
    try:
        if not is_key_present_in_cache(cache_key.get_key(), error_hook):
            stored,msg = fetch_store(cache_key,attr_cache_keys, error_hook)
            if stored == False:
                error_hook(str(msg))
                logger.error(msg)
                return False,mappings
        for i in attr_cache_keys:
            #key=i.split('/')[5]
            cache_resp=cache_obj.get(i)
            mappings.append({i: cache_resp})
        return True,mappings
    except Exception as e:
       tb = traceback.format_exc().split("\n")
       logger.error(tb)
       return False, str(tb)
   

# epic = WorkItem().epic.s_uid
# risk = WorkItem().risk.s_uid
# feature = WorkItem().feature.s_uid
# bug =  WorkItem().feature.s_uid
# test = TestCase().s_uid
# cache_key = CacheKey("09900000-0000-0000-0000-000000000000","2c4d8c4d-9cb8-44eb-b7e0-8b83d4cecc8f","00020040-0200-0000-0000-000000000000","00020040-0200-0010-0040-000000000000")
# m= get_cdm_mapping(cache_key, ['StateUId', 'PriorityUId', 'TypeUId'])
# cache_key = CacheKey("09900000-0000-0000-0000-000000000000","2c4d8c4d-9cb8-44eb-b7e0-8b83d4cecc8f","00020040-0200-0000-0000-000000000000",epic)
# m= get_cdm_mapping(cache_key, ['StateUId', 'PriorityUId', 'TypeUId'])
# cache_key = CacheKey("09900000-0000-0000-0000-000000000000","2c4d8c4d-9cb8-44eb-b7e0-8b83d4cecc8f","00020040-0200-0000-0000-000000000000",epic)
# m= get_cdm_mapping(cache_key, ['StateUId', 'PriorityUId', 'TypeUId'],catch_errors)
# cache_key = CacheKey("09900000-0000-0000-0000-000000000000","2c4d8c4d-9cb8-44eb-b7e0-8b83d4cecc8f","00020040-0200-0000-0000-000000000000",feature)
# m= get_cdm_mapping(cache_key, ['StateUId', 'PriorityUId', 'TypeUId'])
# cache_key = CacheKey("09900000-0000-0000-0000-000000000000","2c4d8c4d-9cb8-44eb-b7e0-8b83d4cecc8f","00020040-0200-0000-0000-000000000000",bug)
# m= get_cdm_mapping(cache_key, ['StateUId', 'PriorityUId', 'TypeUId'])
# #test
# cache_key = CacheKey("09900000-0000-0000-0000-000000000000","2c4d8c4d-9cb8-44eb-b7e0-8b83d4cecc8f",test,None)
# m= get_cdm_mapping(cache_key, ['StateUId', 'PriorityUId', 'TypeUId'])

# cache_key = CacheKey("00500000-0000-0000-0000-000000000000","f76b41a5-5a5e-459b-b632-75228cbb83b7","00020040-0200-0000-0000-000000000000","00020040-0200-0010-0040-000000000000")
# m= get_cdm_mapping(cache_key, ['StateUId', 'PriorityUId', 'TypeUId'])
# cache_key = CacheKey("00500000-0000-0000-0000-000000000000","f76b41a5-5a5e-459b-b632-75228cbb83b7","00020040-0200-0000-0000-000000000000",epic)
# m= get_cdm_mapping(cache_key, ['StateUId', 'PriorityUId', 'TypeUId'])
# cache_key = CacheKey("00500000-0000-0000-0000-000000000000","f76b41a5-5a5e-459b-b632-75228cbb83b7","00020040-0200-0000-0000-000000000000",risk)
# m= get_cdm_mapping(cache_key, ['StateUId', 'PriorityUId', 'TypeUId'])
# cache_key = CacheKey("00500000-0000-0000-0000-000000000000","f76b41a5-5a5e-459b-b632-75228cbb83b7","00020040-0200-0000-0000-000000000000",feature)
# m= get_cdm_mapping(cache_key, ['StateUId', 'PriorityUId', 'TypeUId'])
# cache_key = CacheKey("00500000-0000-0000-0000-000000000000","f76b41a5-5a5e-459b-b632-75228cbb83b7","00020040-0200-0000-0000-000000000000",bug)
# m= get_cdm_mapping(cache_key, ['StateUId', 'PriorityUId', 'TypeUId'])

# cache_key = CacheKey("00500000-0000-0000-0000-000000000000","f76b41a5-5a5e-459b-b632-75228cbb83b7",test,None)
# m= get_cdm_mapping(cache_key, ['StateUId', 'PriorityUId', 'TypeUId'])

# #t=is_key_present_in_cache(cache_key.get_key(), error_hook)
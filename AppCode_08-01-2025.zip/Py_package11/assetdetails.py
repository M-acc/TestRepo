import uuid, json
import psycopg2
import configparser
import os,traceback
from datetime import datetime
from config import insertAsset_query, assetDetails_query
from app_logger import get_alogger
from ai_core.configs.file_encryptor import get_configparser_obj

# config = configparser.ConfigParser()
conf_file_path = os.path.join(os.path.dirname(__file__),"pythonconfig.ini")
# config.read(conf_file_path)
config = get_configparser_obj(conf_file_path)
db_conf = config["postgres.details"]
host_ = db_conf.get("host")
database_ = db_conf.get("database")
user_ = db_conf.get("user")
password_ = db_conf.get("password")

logger = get_alogger()


def insert_to_asset(asset_dict,prompt,token):
    try:
        from flask_app.dbutils import run_query,RowStatus
        logger.info("Asset insertion Begins")
        assetLogUId  = uuid.uuid4()
        featureName = "Code Generation"
        subFeatureName = None
        deploymentId = token['ModelName']
        modelName = token['ModelName']
        createdOn =datetime.now()
        createdbyUser = 'SYSTEM'
        modifiedByUser = 'SYSTEM'
        rowStatusUId = str(RowStatus["Active"].value)
        DemographicUId = asset_dict['DemographicUId']
        ActivityLogUId = asset_dict['ActivityLogUId']
        prompttoken = token.get('PromptToken', 0) if isinstance(token.get('PromptToken'), int) and 'PromptToken' in token else 0
        completiontoken = token.get('CompletionToken', 0) if isinstance(token.get('CompletionToken'), int) and 'CompletionToken' in token else 0
        status, result2 = run_query(assetDetails_query, (deploymentId,))  
        logger.debug(f"Status of query: {str(status)}")
        if result2:
            logger.debug(f"result2: {str(result2)}")
            promptcost = result2[0] * 10 * prompttoken
            completioncost = result2[1] * 10 * completiontoken
        else:
            #logger.error(f"Cost details not present in cost table for deployment id: {deploymentId}")
            raise Exception("Cost details not present")
        subscriptionId = token['SubscriptionId']
        endpoint = token['Endpoint']
        userEmailId =asset_dict['UserEmailId']
        sessionId = asset_dict['SessionUId']
        # clientUId = asset_dict['ClientUId']
        # dcuid = asset_dict['DeliveryConstructUId']
        responsetime = token['Responsetime']
        # demographicUId = uuid.UUID('8646038a-d9d6-4c19-8528-5075b65d8f1d')
        if completiontoken:
            issuccess = True
        else:
            issuccess = False
        values=(str(assetLogUId),sessionId,featureName,subFeatureName,modelName,promptcost,completioncost,subscriptionId,prompttoken,completiontoken,responsetime,prompt,createdOn,userEmailId,createdbyUser,modifiedByUser,rowStatusUId,str(DemographicUId),ActivityLogUId, issuccess, endpoint)
        logger.debug(f"values: {str(values)}")
        run_query(insertAsset_query, values)
    except Exception as e :
        #tb = traceback.format_exc()
        logger.info(f"Exception: {e}")


def get_common_assest_details(req):
    asset_dict = {}
    emailid = req['UserEmailId']
    asset_dict['UserEmailId'] = emailid
    asset_dict['ClientUId'] = req["ClientUId"]
    asset_dict['DeliveryConstructUId'] = req["DeliveryConstructUId"]
    asset_dict['SessionUId'] =req['SessionId']
    asset_dict['DemographicUId'] =req['DemographicUId']
    asset_dict['ActivityLogUId'] = req['ActivityLogUId']
    logger.debug(f"asset_dict: {str(asset_dict)}")
    return asset_dict

def update_asset_details_image_models(model_name,key,response_json,response_time, asset_details, prompt):
    try:
        if model_name=='anthropic.claude-3-sonnet-20240229-v1:0':
            token={}
            token['ModelName']=model_name
            token['SubscriptionId']=key
            token['PromptToken']=response_json["usage"]["input_tokens"]
            token['CompletionToken']=response_json["usage"]["output_tokens"]
            token['Responsetime']=response_time
        elif "gemini" in model_name.lower():
            token = {}
            token['ModelName']=model_name
            token['SubscriptionId']=key
            token['PromptToken']=response_json.usage_metadata.prompt_token_count
            token['CompletionToken']=response_json.usage_metadata.total_token_count
            token['Responsetime']=response_time
        elif model_name=='gpt-4-vision-preview' or model_name=='gpt-4o':
            token={}
            token['ModelName']=model_name
            token['SubscriptionId']=key
            token['PromptToken']=response_json["usage"]["prompt_tokens"]
            token['CompletionToken']=response_json["usage"]["completion_tokens"]
            token['Responsetime']=response_time
        insert_to_asset(asset_details,prompt,token)
        return True
    except Exception as e:
        logger.info(f"Error updating asset details for image models. Exception: {e}")
        return False

import os, traceback, boto3, json
from langchain.callbacks.openai_info import OpenAICallbackHandler
from langchain.chat_models import AzureChatOpenAI
from botocore.config import Config
from azure.identity import ClientSecretCredential, DefaultAzureCredential
from langchain_community.llms import Bedrock
from langchain_community.chat_models import BedrockChat
# from ai_core.configs.settings import readOpenAISecrets, decrypt_username
from app_logger import get_alogger
from config import ANTHROPIC_CLAUDE_V2
from ai_core.configs.file_encryptor import get_configparser_obj
from custom_llm.gcp_custom_llm import GeminiPro,DeCompressAndDecodeBase64String


python_conf_file_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),"pythonconfig.ini")
# config.read(python_conf_file_path)
config = get_configparser_obj(python_conf_file_path)
azure_conf = config["Azure-openai"]
openaiauth = config["OpenAIAuthentication"]
auth_conf = config["Auth-Mode"]
# gemini_pro = config["google-gemini"]
AUTH_MODE = auth_conf.get('secret_key')
logger = get_alogger()

def read_json_file(file_path):
    try:
        data = None
        with open(file_path, 'r') as json_file:
            data = json.load(json_file)
        return data
    except FileNotFoundError:
        print(f"Error: The file {file_path} does not exist.")
        return None
    except json.JSONDecodeError:
        print(f"Error: The file {file_path} is not a valid JSON file.")
        return None
    
modelconfig_path = os.path.join(os.path.abspath(os.path.dirname(os.path.abspath(os.path.dirname(os.path.abspath(__file__))))), 'modelconfig.json')
model_configs = read_json_file(modelconfig_path)

def get_llm(modelDetails, language, authmethod, max_token=azure_conf.get("max_tokens_gpt4_32k")):
    print("Started llm method")
    if authmethod==AUTH_MODE:
        if "gpt" in modelDetails["ModelName"]:
            config = model_configs[modelDetails["ModelName"]]
            if language == "java":
                config["model_kwargs"]["frequency_penalty"] = 0.3
            llm = get_llm_gpt(modelDetails, config)
        elif "anthropic" in modelDetails["ModelName"]:
            config = model_configs[modelDetails["ModelName"]]
            llm = get_llm_bedrock(modelDetails, config)
        elif "gemini" in modelDetails["ModelName"]:
            config = model_configs[modelDetails["ModelName"]]
            llm = get_llm_gemini(modelDetails, config)
            
    else :
        llm = auth_based_llm(authmethod)
    print("Completed llm method")
    return llm

def auth_based_llm(authmethod):
    token = get_token(authmethod)
    os.environ["OPENAI_API_KEY"] = token
    os.environ["OPENAI_API_TYPE"] = "azure_ad"
    #https://srch-nvi-dev-genres.openai.azure.com/openai/deployments/myWiz-gpt-35-turbo-16k/chat/completions?api-version=2023-03-15-preview
    os.environ["OPENAI_API_VERSION"] = openaiauth.get("api_version")
    os.environ["OPENAI_API_BASE"] = openaiauth.get("openai_base_url")
    llm = AzureChatOpenAI(
        deployment_name=openaiauth.get("deployment_name"),
        model_name=openaiauth.get("model_name"),
        max_tokens=azure_conf.get("max_tokens_gpt4_32k"),
        temperature=0,
        model_kwargs={"frequency_penalty": 0},
        max_retries=7,
        request_timeout=200,
        callbacks=[OpenAICallbackHandler()]
    )
    return llm

def get_token(auth_method):
    token = ''
    if auth_method == "ServicePrincipleIdentity" :
        token = get_service_principal_token()
    elif auth_method == "UserAssignedManagedIdentity" :
        token = get_userassigned_mananged_identity_token()
    return token 

def get_service_principal_token():
    token = ''
    os.environ["AZURE_CLIENT_ID"] = openaiauth.get("OpenAIServicePrincipleClientId")
    os.environ["AZURE_CLIENT_SECRET"] = openaiauth.get("OpenAIServicePrincipleClientSecret")
    os.environ["AZURE_TENANT_ID"] = openaiauth.get("OpenAITenantId")
    credential = ClientSecretCredential(os.environ["AZURE_TENANT_ID"], os.environ["AZURE_CLIENT_ID"], os.environ["AZURE_CLIENT_SECRET"])
    try :
        token  = credential.get_token(openaiauth.get("OpenAIResource") + "/.default").token
        return token 
    except :
        return token
    
def get_userassigned_mananged_identity_token():
    token = ''
    credential = DefaultAzureCredential(managed_identity_client_id=openaiauth.get("OpenAIUserAssignedManagedIdentity"))
    try:
        token = credential.get_token(openaiauth.get("OpenAIResource") +'/.default').token
    except:
        token = credential.get_token(openaiauth.get("OpenAIResource")).token
    return token

def get_llm_gpt(modelDetails, modelConfigs):
    # key_gpt = readOpenAISecrets(azure_conf.get("openai_api_base_langchain") + "/")
    model = modelDetails['ModelName']
    endpoint = modelDetails['Endpoint']
    deploymentId = modelDetails['DeploymentId']
    secretKey = modelDetails['SecretKey']
    # key_gpt = readOpenAISecrets(endpoint)
    max_tokens = modelConfigs["max_tokens"]
    temperature = modelConfigs["temperature"]
    model_kwargs = modelConfigs["model_kwargs"]
    max_retries = modelConfigs["max_retries"]
    request_timeout = modelConfigs["request_timeout"]
    key_gpt = secretKey
    # try:
    #     if (not key_gpt or key_gpt == "") and secretKey:
    #         if len(secretKey) < 64:
    #             key_gpt = secretKey
    #         else:
    #             key_gpt = decrypt_username(secretKey)
    # except Exception:
    #     tb = traceback.format_exc()
    #     logger.error(f"unable to decrypt secret key: {str(tb)}")
    #     key_gpt = secretKey

    if not key_gpt or key_gpt == "":
        raise ValueError(f"key_gpt: {key_gpt} is empty for Model: {model}, Secret: {secretKey}")
    logger.debug(f"key_gpt: {key_gpt}")
    os.environ["OPENAI_API_TYPE"] = "azure"
    os.environ["OPENAI_API_VERSION"] = azure_conf.get("openai_api_version")
    os.environ["OPENAI_API_BASE"] = endpoint
    # os.environ["OPENAI_API_KEY"] = key_gpt
    os.environ["OPENAI_API_KEY"] = azure_conf.get("key_gpt4_32k")
    llm = AzureChatOpenAI(
        deployment_name = deploymentId,
        model_name = model,
        max_tokens = max_tokens,
        temperature = temperature,
        model_kwargs = model_kwargs,
        max_retries = max_retries,
        request_timeout = request_timeout,
        callbacks = [OpenAICallbackHandler()]
    )

    return llm

def get_llm_bedrock(modelDetails, modelConfigs):
    model = modelDetails['ModelName']
    endpoint = modelDetails['Endpoint']
    secretKey = modelDetails['SecretKey']
    key_gpt = readOpenAISecrets(endpoint)
    region_name = modelConfigs["region_name"]
    max_attempts = modelConfigs["max_attempts"]
    mode = modelConfigs["mode"]
    service_name = modelConfigs["service_name"]
    max_tokens = modelConfigs["max_tokens"]
    temperature = modelConfigs["temperature"]
    top_p = modelConfigs["top_p"]
    top_k = modelConfigs["top_k"]

    if (not key_gpt or key_gpt == "") and secretKey:
        key_gpt = decrypt_username(secretKey)

    if not key_gpt or key_gpt == "":
        raise ValueError(f"key_gpt: {key_gpt} is empty for Model: {model}, Secret: {secretKey}")
    
    logger.debug(f"key_gpt: {key_gpt}")
    access_key, secret_key = get_aws_keys(key_gpt)
    session = boto3.session.Session()
    retry_config = Config(
        region_name = region_name,
        retries = {
            'max_attempts': max_attempts,
            'mode': mode
        }
    )
    boto3_bedrock_runtime = session.client(
        service_name, 
        aws_access_key_id = access_key,
        aws_secret_access_key = secret_key,
        config = retry_config)
    
    if model == ANTHROPIC_CLAUDE_V2:
        body = {
            "max_tokens_to_sample": max_tokens,
            "temperature": temperature,
            "top_p": top_p,
            "top_k": top_k
        }

        llm = Bedrock(
            model_id = model,
            client = boto3_bedrock_runtime,
            model_kwargs = body,
            # callbacks=[StreamingStdOutCallbackHandler()]
        )
    else:
        body = {
            "max_tokens": max_tokens,
            "temperature": temperature,
            "top_p": top_p,
            "top_k": top_k,
        }

        llm = BedrockChat(
            model_id=model,
            client=boto3_bedrock_runtime,
            model_kwargs=body,
            # callbacks=[StreamingStdOutCallbackHandler()]
        )
    return llm

def get_llm_gemini(modelDetails, modelConfigs):
    
    encrypted_secretKey = modelDetails["SecretKey"]
    decrypted_secretKey = decrypt_username(encrypted_secretKey)
    if type(decrypted_secretKey) is bytes:
        decrypted_secretKey = modelDetails["SecretKey"]
    # decrypted_secretKey = gemini_pro.get("credential")    
    json_credentials = DeCompressAndDecodeBase64String(decrypted_secretKey)
    llm = GeminiPro(json_credentials, modelConfigs, modelDetails["ModelName"])
    return llm

def get_aws_keys(keys: str) -> tuple:
    access = ""
    secret = ""
    ids = keys.split(';')
    for id in ids:
        if 'accesskey' in id:
            access = id.split(':')[1]
        if 'secretkeyid' in id:
            secret = id.split(':')[1]

    return (access, secret)

def get_llm_gpt432k(modelDetails, max_token, frequency_penalty ):
    # key_gpt = readOpenAISecrets(azure_conf.get("openai_api_base_langchain") + "/")
    model = modelDetails['ModelName']
    endpoint = modelDetails['Endpoint']
    deploymentId = modelDetails['DeploymentId']
    secretKey = modelDetails['SecretKey']
    key_gpt = readOpenAISecrets(endpoint)

    try:
        if (not key_gpt or key_gpt == "") and secretKey:
            if len(secretKey) < 64:
                key_gpt = secretKey
            else:
                key_gpt = decrypt_username(secretKey)
    except Exception:
        tb = traceback.format_exc()
        logger.error(f"unable to decrypt secret key: {str(tb)}")
        key_gpt = secretKey

    if not key_gpt or key_gpt == "":
        raise ValueError(f"key_gpt: {key_gpt} is empty for Model: {model}, Secret: {secretKey}")
    logger.debug(f"key_gpt: {key_gpt}")
    os.environ["OPENAI_API_TYPE"] = "azure"
    os.environ["OPENAI_API_VERSION"] = azure_conf.get("openai_api_version")
    # os.environ["OPENAI_API_BASE"] = azure_conf.get("openai_api_base_langchain")
    os.environ["OPENAI_API_BASE"] = endpoint
    os.environ["OPENAI_API_KEY"] = key_gpt
    # os.environ["OPENAI_API_KEY"] = azure_conf.get("key_gpt4_32k")
    llm = AzureChatOpenAI(
        # deployment_name=azure_conf.get("deployment_name_gpt4_32k"),
        deployment_name = deploymentId,
        model_name="gpt-4-32k",

        max_tokens=max_token,
        temperature=0,
        model_kwargs={"frequency_penalty": frequency_penalty},
        max_retries=7,
        request_timeout=200,
        callbacks=[OpenAICallbackHandler()]
    )

    return llm

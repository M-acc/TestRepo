import traceback
import os,sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + os.path.sep + '..')

from app_logger import get_alogger
logger = get_alogger()
from ai_core.configs.file_encryptor import get_configparser_obj
conf_file_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),"pythonconfig.ini")
config = get_configparser_obj(conf_file_path)

uploadMethodConfig = config["CodeUploadMethod"]
codeUploadMethod = uploadMethodConfig.get("upload_method")
mount_path = uploadMethodConfig.get("mount_path")

def check_mount_upload()-> bool :
    try :
        if codeUploadMethod == 'blob':
            return False
        elif codeUploadMethod == 'mount':
            return True
        else :
            raise Exception("No value set in CodeUploadMethod section of config file")
    except Exception :
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False
    
def get_mount_path() -> str :
    server_path = os.path.join(mount_path,'CodeBase')
    return server_path




from uuid import UUID
import uuid
import psycopg2
from psycopg2 import extras
from datetime import datetime
import traceback
import json
import os
from enum import Enum
from config import (userstories_UId_query, nonFunctionalComponent_query, codeGenInsert_query, blobInsert_query,nonFunctionalComponentLimitOne_query,
  selectversion_query,storyPublish_query, usuid_query, cssFileUpload_query,workspace_query,sessionfetchquery,
  request_fetch, aiModelNamefetchquery, brownfield_request_fetch, brownfieldcodeGenInsert_query,modelCounterQuery,modelsCounterInsert,modelsCounterUpdate,
  codeGenInsert_react_native_query,aiModelNameNoDemofetchquery,apimConfigModelNamefetchquery,codeGenInsertArch_query, imageListFetchQuery, codeGenImageToCode_query, codeGenImageInsert_query)
from config import models, angular_models, react_models, xd_models, brownfield_models, html_models, react_native_models, image_models, ANTHROPIC_CLAUDE_3_SONNET_V1
from app_logger import get_alogger
from ai_core.configs.file_encryptor import get_configparser_obj
import copy
from ai_core.configs.settings import readOpenAISecretsAIMConfig
conf_file_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),"pythonconfig.ini")
config = get_configparser_obj(conf_file_path)

db_conf = config["postgres.details"]
host_ = db_conf.get("host")
database_ = db_conf.get("database")
user_ = db_conf.get("user")
password_ = db_conf.get("password")
_schema = db_conf.get("schema")

aimodelcheck = config["aimodelcheck"]
byPassDemogCheckForAIModel = aimodelcheck.get("ByPassDemogCheckForAIModel")
enable_aipm = aimodelcheck.get("enable_apim")
instance = aimodelcheck.get("instance")
is_cloud = aimodelcheck.get("isCloud")

components_codegen = config["components_codegen"]
component_codegen_userstroies_count = components_codegen.get("component_codegen_userstroies_count")
# ai_model_name = config["ai_model_name"]
# gpt_4_32k = ai_model_name.get("gpt4_name")
# anthropic_claude_v2_1 = ai_model_name.get("aws_bedrock_claude_name")

logger = get_alogger()

def create_request_body(request_body) -> dict :
    body = {}
    try :
        print("request_body--------> DbUtil "+ str(request_body))
        body['Is_SelectedComponentsForAppcode'] = False
        if "SelectedComponentsForAppcode" in request_body and request_body["SelectedComponentsForAppcode"]:
            body['Is_SelectedComponentsForAppcode'] = True
            sessionid = str(SessionAndTranscationStatus["Default"].value)
            transactionid = str(SessionAndTranscationStatus["Default"].value)
            stories_UIds = []
            functionalComponentList = request_body["SelectedComponentsForAppcode"]
            functionalComponentList = json.loads(functionalComponentList)
            for res in functionalComponentList:
                FunctionalComponent = res["FunctionalComponent"]
                userstories_UIds = res["UserStories"]
                stories_UIds.extend(userstories_UIds)
                
            uid_tuple = tuple(stories_UIds)
            
            if uid_tuple:
                status,result =  run_query(userstories_UId_query, (uid_tuple,), fetchone=False, cursor_factory=True)
            else:
                status, result = None, []
                
        else:
            #To - do Remove commented code
            status, result = run_query(sessionfetchquery, (request_body['DemographicUId'],))
            if not result:
                return False, "Unable to find Session and TransactionId in userstory table"
            sessionid = result[0]
            transactionid = result[1]
            if byPassDemogCheckForAIModel.lower() == 'true' :
                status, result = run_query(nonFunctionalComponentLimitOne_query, (sessionid, transactionid, sessionid, transactionid), fetchone=False, cursor_factory=True)
            else :
                status, result = run_query(nonFunctionalComponent_query, (sessionid, transactionid), fetchone=False, cursor_factory=True)

        if not result:
            return False, "Unable to find details in userstory table"
            
        userstroies_count = int(component_codegen_userstroies_count) if 'ArchitectureComponents' in request_body else 5 
        functionalareasnames =set()
        re = []
        for each in result :
            comp = each['Data']['FunctionalComponent']
            fun = {}
            fun['FunctionalComponent'] = comp
            fun['UserStories'] = []
            index = -1
            if comp not in functionalareasnames :
                functionalareasnames.add(comp)
            else :
                index = get_functional_area_index(comp,re)

            story = {}
            story['UserStoryUId'] = each['UserStoryUId']
            story['Title'] = each['Data']['Title']
            story['Description'] = each['Data']['Description']
            story['AcceptanceCriteria'] = each['Data']['AcceptanceCriteria']
            fun['UserStories'].append(story)
            if index == -1 :
                re.append(fun)
            else :
                if len(re[index]['UserStories']) < userstroies_count :
                    re[index]['UserStories'].append(story)
    
        
        #Select Model based on DemographicUId
        # priority=['gpt_models','bedrock_models']
        # def check_model(result, counter_result, DemographicUId, image=False):
        #     model = ""
        #     endpoint = ""
        #     deploymentId = ""
        #     secretKey = ""
        #     total_count = 0
        #     current_counter = 1
        #     for item in result:
        #         if item[0] == 'gpt-4-32k':
        #             total_count += 1
        #         elif item[0] == 'gpt-4o':
        #             total_count += 1
        #         elif item[0] ==  'anthropic.claude-v2:1':
        #             total_count += 1
        #         elif item[0] ==  'anthropic.claude-3-sonnet-20240229-v1:0':
        #             total_count += 1
                

        #     if counter_result is None or len(counter_result) == 0 :
        #         # current_counter = 1
        #         run_query(modelsCounterInsert,(str(DemographicUId),total_count,1))
        #     else :
        #         current_counter = counter_result['Counter'] 
        #         #check total subscription matches
        #         if  total_count != counter_result['TotalSubscription'] :
        #             current_counter = 1
        #         else :#increment current_counter by 1
        #             current_counter = (current_counter + 1) % (counter_result['TotalSubscription']+1)
        #             current_counter = current_counter if current_counter > 0 else 1
        #         #check condition where zero is there current_counter
        #         modifiedon = datetime.now()
        #         run_query(modelsCounterUpdate,(total_count,current_counter,modifiedon,str(DemographicUId)))
                

        #     c = 0
        #     for item in result:
        #         if item[0] == 'gpt-4-32k':
        #             c += 1
        #             if c == current_counter :
        #                 return item[0], item[1], item[2], item[3]
        #         elif item[0] == 'gpt-4o':
        #             c += 1
        #             if c == current_counter :
        #                 return item[0], item[1], item[2], item[3]
        #         elif item[0] ==  'anthropic.claude-v2:1':
        #             c += 1
        #             if c == current_counter :
        #                 return item[0], item[1], item[2], item[3]
        #         elif item[0] ==  'anthropic.claude-3-sonnet-20240229-v1:0':
        #             c += 1
        #             if c == current_counter :
        #                 return item[0], item[1], item[2], item[3]
  
                    
        #     return model, endpoint, deploymentId, secretKey

        # check_gpt_presence = lambda result: any(item[0] in ('gpt-4-32k') for item in result)  # , 'gpt-35-turbo-16k', 'text-davinchi-003'
        # check_bedrock_presence = lambda result: any(item[0] in ('anthropic.claude-v2:1') for item in result)  # , 'ai21.j2-ultra-v1', 'cohere.command-text-v14'

        
        if byPassDemogCheckForAIModel.lower() == 'true' :
            status,result = run_query(aiModelNameNoDemofetchquery,(str(RowStatus["Active"].value),),fetchone=False, cursor_factory=True)
        else :
            status, result = run_query(aiModelNamefetchquery, (str(RowStatus["Active"].value), request_body['DemographicUId'], str(RowStatus["Active"].value)), fetchone=False, cursor_factory=True)
        logger.debug(f"Ai Query status: {str(status)} and result: {str(result)}")
        if not status or not result:
            return False, f"For DemographicUId: {request_body['DemographicUId']} there is no AI Model configured."

        if byPassDemogCheckForAIModel.lower() == 'true' :
            tempdemoid = '00000000-0000-0000-0000-000000000000'
        else :
            tempdemoid = request_body['DemographicUId']

        if str(enable_aipm).lower() == "true":
            if is_cloud == "true":
                modelname = 'gpt-4-32k'
                endpoint, secretKey, deploymentid = readOpenAISecretsAIMConfig()
                logger.debug(f"ReadOpenAISecrets: {modelname}, {endpoint}, {deploymentid}")
            else:
                status, result = run_query(apimConfigModelNamefetchquery, 
                                           (instance, str(RowStatus["Active"].value)), 
                                           fetchone=False, cursor_factory=True)
                logger.debug(f"Ai Query status: {str(status)} and result: {str(result)}")
                if not status or not result:
                    return False, f"For DemographicUId: {request_body['DemographicUId']} \
                        No AI Model configured."
                modelname, endpoint, deploymentid, secretKey = check_apim_config(result)
        else:
            status, counter_result = run_query(modelCounterQuery,(tempdemoid,),fetchone=True, cursor_factory=True)
            
            # modelname, endpoint, deploymentid, secretKey = check_model(result,counter_result,tempdemoid)
            # models = [GPT_4_32K, GPT_4O, ANTHROPIC_CLAUDE_V2, ANTHROPIC_CLAUDE_3_SONNET_V1]
            modelname, endpoint, deploymentid, secretKey =  check_model(result, counter_result, tempdemoid, models)

        if modelname == "":
            return False, f"Incorrect AI Model is configured. It should be one of the following:  'gpt-4-32k',  'gpt-4o', 'anthropic.claude-v2:1', 'anthropic.claude-3-sonnet-20240229-v1:0' , 'gemini-pro', 'gemini-1.5-pro-001'"

        if 'ArchitectureComponents' in request_body:
            body['ArchitectureComponents'] = request_body['ArchitectureComponents']

        body['FolderName'] = request_body['FolderName']
        body['SessionId'] = sessionid
        body['CSSFileUploadUId'] = request_body['CSSFileUploadUId']
        body['ClientUId'] = request_body['ClientUId']
        body['DeliveryConstructUId'] = request_body['DeliveryConstructUId']
        # body['UseCase'] = request_body['Usecase']
        body['UserEmailId'] = request_body['UserEmailId']
        # body['Languages'] = request_body['Languages']
        body['AppName']=request_body['AppName']
        body['DemographicUId']=request_body['DemographicUId']
        body['FunctionaAreas'] = re
        if 'WorkspaceProvisioned' in request_body:
            body['WorkspaceProvisioned']= request_body['WorkspaceProvisioned']
        else:
            body['WorkspaceProvisioned']=False
        # body['ModelName'] = modelname
        # body['Endpoint'] = endpoint
        # body['DeploymentId'] = deploymentid
        # body['SecretKey'] = secretKey
        body['ModelDetails'] = {'ModelName': modelname, 'Endpoint': endpoint, 'DeploymentId': deploymentid, 'SecretKey': secretKey}
        # body['ModelName'] = 'anthropic.claude-v2:1'
        from flask_app.utils import get_modeluid
        body['ModelUId'] = get_modeluid(body)
        if "SelectedConfiguration" in request_body:
            body["SelectedConfiguration"] = request_body["SelectedConfiguration"]
        else:
            body["SelectedConfiguration"] = "Arch" 

        if "ComponentType" in request_body:
            body["ComponentType"] = request_body["ComponentType"]
        else:
            body["ComponentType"] = '' 
        
        body['WorkflowUId'] = request_body['WorkflowUId'] if 'WorkflowUId' in request_body else None
        if 'ActivityLogUId' in request_body:
            body['ActivityLogUId'] = request_body['ActivityLogUId']
        else:
            body['ActivityLogUId'] = '00000000-0000-0000-0000-000000000000'
        logger.debug(f"New Request Body : {str(body)}")
        return True, body 

    except Exception :
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False, str(tb)
    
def create_request_body_codegen(request_body) -> dict :
    body = {}
    try :
        conn = psycopg2.connect( host=host_,database=database_,user=user_,password=password_)
        cur = conn.cursor(cursor_factory=extras.DictCursor)
        query = """SELECT * FROM genwizard."UserStory" WHERE "SessionId" = %s AND "TransactionId" = %s AND "Data" ->> 'NonFunctionalComponent' is null  AND "Data" ->>  'FunctionalComponent' is not null ; """
        cur.execute(query, (request_body['SessionId'], request_body['TransactionUId']))
        result = cur.fetchall()  
        functionalareasnames =set()
        re = []#[{'FunctionalComponent':'Aythorization','UserStory':[]},{'FunctionalComponent':'connectiom','UserStory':[]}]
        if not result:
            return False, "Unable to find details in userstory table"

        for each in result :
            comp = each['Data']['FunctionalComponent']
            fun = {}
            fun['FunctionalComponent'] = comp
            fun['UserStories'] = []
            index = -1
            if comp not in functionalareasnames :
                functionalareasnames.add(comp)
            else :
                index = get_functional_area_index(comp,re)

            story = {}
            story['UserStoryUId'] = each['UserStoryUId']
            story['Title'] = each['Data']['Title']
            story['Description'] = each['Data']['Description']
            story['AcceptanceCriteria'] = each['Data']['AcceptanceCriteria']
            fun['UserStories'].append(story)
            if index == -1 :
                re.append(fun)
            else :
                if len(re[index]['UserStories']) < 4 :
                    re[index]['UserStories'].append(story)
        body ={}
        body['FolderName'] = request_body['FolderName']
        body['SessionId'] = request_body['SessionId']
        # body['Languages'] = request_body['Languages']
        body['FunctionaAreas'] = re
        logger.debug(f"New Request Body : {str(body)}") 
        return True, body 

    except Exception :
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False, str(tb)
    
def get_functional_area_index(comp,re) :
    index = -1 
    for i,each in enumerate(re) :
        if each['FunctionalComponent'] == comp :
            index = i
            break
    return index


def insert_in_request_table(requestid,body) :
    try:
        new = str(RequestState["New"].value)
        functional_areas = body['FunctionaAreas']
        sessionId = UUID(body['SessionId'])
        time = datetime.utcnow()
        lang = body['Languages']
        appName = str(body['AppName'])
        demoid = UUID(body['DemographicUId'])
        architecture_components = {}
        if 'ArchitectureComponents' in body:
            architecture_components = body['ArchitectureComponents']
        version = check_version_codegen(demoid,appName)
        if not version:
            return False,"Error in checking version in codegen"
        # folderName = str(body['FolderName'])+"_v"+str(version)
        folderName = str(body['FolderName'])
        
        count = 0 
        workspaceprovisioned=body['WorkspaceProvisioned']
        workspaceuid = '00000000-0000-0000-0000-000000000000'
        workspacename = ""
        workspacetype ='00000000-0000-0000-0000-000000000000'

        SelectedConfiguration = body["SelectedConfiguration"]
        ComponentType = body["ComponentType"]
        WorkflowUId = body["WorkflowUId"]
        status, result = run_query(workspace_query, (str(demoid),))
        if status:
            workspaceuid = result[0]
            workspacename = result[1]
            workspacetype = result[2]
        for index, fun_component in enumerate(functional_areas) :
            verbose = ''
            area = fun_component['FunctionalComponent']
            stories = []
            req_body = []
            for story in fun_component['UserStories'] :
                if check_story_publish(story['UserStoryUId'],story['Title'],sessionId) or body['Is_SelectedComponentsForAppcode']:
                    stories.append(story['UserStoryUId'])
                    req_body.append({"Id": str(story['UserStoryUId']),"Title" : story["Title"]}) 
            # values=[str(requestid),str(sessionId),area,"New",stories,time,"New", json.dumps(req_body)]
            # sql = ("INSERT INTO favourite (number, info) VALUES (%s, %s)", (numbers, animals))
            requestid = str(requestid)
            CodeGenerationUId = str(uuid.uuid4())
            sessionId = str(sessionId)
            modelname=body['ModelDetails']['ModelName'] 
            modelendpoint=body['ModelDetails']['Endpoint']
            if index == 0 :
               verbose = json.dumps(body)
            #    status, rowcoount = run_query(codeGenInsert_query, (CodeGenerationUId,requestid,sessionId,area,new,stories,lang,folderName,time,body['UserEmailId'],new, 
            #             json.dumps(req_body),str(demoid),appName,version,workspacename,workspaceuid,workspacetype,workspaceprovisioned,body['UserEmailId'],verbose))
            
               status, rowcoount = run_query(codeGenInsertArch_query, (CodeGenerationUId,requestid,sessionId,area,new,stories,lang,folderName,time,body['UserEmailId'],new, 
                        json.dumps(req_body),str(demoid),appName,version,workspacename,workspaceuid,workspacetype,workspaceprovisioned,body['UserEmailId'],verbose, SelectedConfiguration, None, None, None, ComponentType,json.dumps(architecture_components),WorkflowUId,modelname,modelendpoint))
            else :   
                # status, rowcoount = run_query(codeGenInsert_query, (CodeGenerationUId,requestid,sessionId,area,new,stories,lang,folderName,time,body['UserEmailId'],new, 
                #         json.dumps(req_body),str(demoid),appName,version,workspacename,workspaceuid,workspacetype,workspaceprovisioned,body['UserEmailId'],verbose))
                status, rowcoount = run_query(codeGenInsertArch_query, (CodeGenerationUId,requestid,sessionId,area,new,stories,lang,folderName,time,body['UserEmailId'],new, 
                        json.dumps(req_body),str(demoid),appName,version,workspacename,workspaceuid,workspacetype,workspaceprovisioned,body['UserEmailId'],verbose, SelectedConfiguration, None, None, None, ComponentType,json.dumps(architecture_components),WorkflowUId,modelname,modelendpoint))
            #rowcoount = run_query(codeGenInsert_query, (CodeGenerationUId,requestid,sessionId,area,new,stories,lang,folderName,time,body['UserEmailId'],new, 
            #         json.dumps(req_body),str(demoid),appName,version,body['UserEmailId']))
            tb=[]
            if status:
                count += rowcoount
                # cur.execute(sql,values)
                # rowcoount = cur.rowcount
                logger.debug(f"Rowcount {str(rowcoount)} Added record succesfully  :")
            else:
                tb.append(rowcoount)


        if count > 0 :
            return True , ""
        else :
            logger.error("Error inserting CodeGenerationRequest table")
            verbose={'traceback':str(tb),
                   'ErrorMessage':"Error inserting CodeGenerationRequest table"}
            return False ,json.dumps(verbose)
     
    except Exception as e:
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False, str(tb)


def insert_in_request_table_figma_react(requestid,body) :
    try:
        new = str(RequestState["New"].value)
        functional_areas = body['FunctionaAreas']
        sessionId = UUID(body['SessionId'])
        time = datetime.utcnow()
        lang = body['Languages']
        appName = str(body['AppName'])
        demoid = UUID(body['DemographicUId'])
        req_body = [{'FigmaURL':body['FigmaURL']}]
        version = 1
        folderName = ''
        count = 0 
        workspaceprovisioned=body['WorkspaceProvisioned']
        workspaceuid = '00000000-0000-0000-0000-000000000000'
        workspacename = ""
        workspacetype ='00000000-0000-0000-0000-000000000000'
        FigmaURL = body['FigmaURL']
        FigmaPageName = body['FigmaPageName']
        SelectedConfiguration = body['SelectedConfiguration']
        WorkflowUId = body['WorkflowUId']
        status, result = run_query(workspace_query, (str(demoid),))
        if status:
            workspaceuid = result[0]
            workspacename = result[1]
            workspacetype = result[2]

        requestid = str(requestid)
        CodeGenerationUId = str(uuid.uuid4())
        sessionId = str(sessionId)
        verbose = json.dumps(body)
        status, rowcoount = run_query(codeGenInsert_query, (CodeGenerationUId,requestid,sessionId,'',new,[],lang,folderName,time,body['UserEmailId'],new, 
                    json.dumps(req_body),str(demoid),appName,version,workspacename,workspaceuid,workspacetype,workspaceprovisioned,body['UserEmailId'],verbose,SelectedConfiguration,FigmaURL,FigmaPageName,None,'', WorkflowUId))
        #rowcoount = run_query(codeGenInsert_query, (CodeGenerationUId,requestid,sessionId,area,new,stories,lang,folderName,time,body['UserEmailId'],new, 
        #         json.dumps(req_body),str(demoid),appName,version,body['UserEmailId']))
        # count += rowcoount
        # cur.execute(sql,values)
        # rowcoount = cur.rowcount
# value=('fafda272-c62d-4740-86d3-e1e515217ffa', '0ff74e35-a192-4741-89d3-ef5432632503', '00000000-0000-0000-0000-000000000000', '', '00100000-0000-0000-0000-000000000000', [], ['react'], 'test_div_MedOrderApp1_v1', datetime.datetime(2023, 11, 24, 12, 53, 54, 975270), 'null', '00100000-0000-0000-0000-000000000000', '[]', 'e6762f4c-0212-476f-a5f8-13d13e9b9a90', 'https://www.figma.com/file/Y5qHpNPXbp3PCUweP3keOK', 1, 'Sample WorkSpace19', '00000319-0000-0000-0000-000000000000', '00000000-0000-0000-0000-000000000000', 'null')
        if not status:
            logger.error("No table found CodeGenrationRequest")
            return False , rowcoount[0]
        else:
            logger.debug(f"Rowcount {str(rowcoount)} Added record succesfully  :")
            return True,""
     
    except Exception as e:
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False, str(tb)

def insert_in_request_table_javalib(requestid,body,libname):
    try:
        new = str(RequestState["New"].value)
        functional_areas = "kafka"
        sessionId = UUID(body['SessionId'])
        time = datetime.utcnow()
        lang = ["java"]
        appName = ""
        if "AppName" in body:
            appName = body["AppName"]
        demoid = UUID(body['DemographicUId'])
        version = check_version_codegen(demoid,appName)
        folderName = str(body['FolderName'])
        count = 0 
        workspaceprovisioned=body['WorkspaceProvisioned']
        workspaceuid = '00000000-0000-0000-0000-000000000000'
        workspacename = ""
        workspacetype ='00000000-0000-0000-0000-000000000000'
        status, result = run_query(workspace_query, (str(demoid),))

        if "SelectedConfiguration" in body:
            SelectedConfiguration = body["SelectedConfiguration"]
        else:
            SelectedConfiguration = "Arch"

        if "ComponentType" in body:
            ComponentType = body["ComponentType"]
        else:
            ComponentType = ''

        WorkflowUId = body["WorkflowUId"] if "WorkflowUId" in body else None
        
        if status:
            workspaceuid = result[0]
            workspacename = result[1]
            workspacetype = result[2]
        requestid = str(requestid)
        CodeGenerationUId = str(uuid.uuid4())
        sessionId = str(sessionId)
        verbose = json.dumps(body)
        # status, rowcoount = run_query(codeGenInsert_query, (CodeGenerationUId,requestid,sessionId,libname,new,[],lang,folderName,time,body['UserEmailId'],new, json.dumps(body),str(demoid),appName,version,workspacename,workspaceuid,workspacetype,workspaceprovisioned,body['UserEmailId'],verbose))
        status, rowcoount = run_query(codeGenInsert_query, (CodeGenerationUId,requestid,sessionId,libname,new,[],lang,folderName,time,body['UserEmailId'],new, json.dumps(body),str(demoid),appName,version,workspacename,workspaceuid,workspacetype,workspaceprovisioned,body['UserEmailId'],verbose, SelectedConfiguration, None, None, None,ComponentType, WorkflowUId))
        count += rowcoount
        logger.debug(f"Rowcount {str(rowcoount)} Added record succesfully  :")

        if count > 0 :
            return True , ""
        else :
            logger.error("No table found CodeGenrationRequest")
            return False ,"No table found CodeGenrationRequest"
     
    except Exception as e:
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False, str(tb)

def insert_in_blob_table(folderName,demoid):
    try:
        count=0
        blobuid= str(uuid.uuid4())
        status, rowcoount = run_query(blobInsert_query, (blobuid,folderName,"",demoid,datetime.utcnow(),datetime.utcnow(),"SYSTEM","SYSTEM")) 
        count += rowcoount
        logger.debug(f"Rowcount {str(rowcoount)} Added record succesfully  :")

        if count > 0 :
            return True , ""
        else :
            logger.error("No table found BlobFolderDeletionRequest")
            return False ,"No table found BlobFolderDeletionRequest"
     
    except Exception as e:
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False, str(tb)

def check_version_codegen(demoid,appname):
    try:
        overallstatus = str(RequestState["Success"].value)
        status, result = run_query(selectversion_query, (appname, str(demoid),overallstatus))
        if status:
            if result[0] is not None:
                logger.debug(f"Version already exists.Combination of Demographicuid and AppName not unique")
                version = result[0]+1
            else:
                logger.debug(f"Combination of Demographicuid and AppName is unique")
                version = 1
        return version
    except Exception as e :
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False

def check_story_publish(userstoryuid,title,sessionid):
    try :
        status, result = run_query(storyPublish_query, (str(sessionid), title))
        if status:
            logger.debug(f"The IsPublishToMyWizard column is True for the specified userstoryuid {str(userstoryuid)}")
            return True
        else:
            logger.debug(f"The IsPublishToMyWizard column is not True for the specified userstoryuid {str(userstoryuid)}")
            return False
    except Exception as e :
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False

def get_us_uid(title, sessionid):
    status, result = run_query(usuid_query, (title, sessionid))
    logger.debug(str((status, result)))
    
    return status, result

def get_css_file_upload(CSSFileUploadUId):
    try :
        CSSFileUploadUId = str(CSSFileUploadUId)
        status, result = run_query(cssFileUpload_query, (CSSFileUploadUId,))
        
        if status:
            return result
        else:
            return False
    except Exception as e :
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False
    
def run_query(query: str, value, fetchone=True, cursor_factory=False):
    try:
        result = list()
        r_flag = False
        _options = f"-c search_path={_schema}"
        conn = psycopg2.connect(host=host_, database=database_, user=user_, password=password_, options=_options)
        cur = conn.cursor()
        if cursor_factory:
            cur = conn.cursor(cursor_factory=extras.DictCursor)
        logger.debug(str((query, value)))
        cur.execute(query, value)
        conn.commit()
        if query.startswith("INSERT") or query.startswith("UPDATE"):
            return True, cur.rowcount
        
        if fetchone:
            result = cur.fetchone()
        else:
            result = cur.fetchall()

        if result is not None:
            r_flag = True

        cur.close()
        conn.close()
        logger.debug(str((r_flag, result)))
        return (r_flag, result)

    except Exception as e:
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return (False, [str(tb)])

def fetch_request(requestid) :
    status, result = run_query(request_fetch,(requestid,))
    return status, result

def create_request_body_figma_react(request_body, language):
    body = {}
    try :
       
        body ={}
        body['FolderName'] = ''
        body['SessionId'] = '00000000-0000-0000-0000-000000000000'
        body['CSSFileUploadUId'] = request_body['CSSFileUploadUId']
        body['ClientUId'] = request_body['ClientUId']
        body['DeliveryConstructUId'] = request_body['DeliveryConstructUId']
        # body['UseCase'] = request_body['Usecase']
        body['UserEmailId'] = request_body['UserEmailId']
        # body['Languages'] = request_body['Languages']
        body['AppName']=request_body.get('AppName','')
        body['DemographicUId']=request_body['DemographicUId']
        body['FunctionaAreas'] = ''
        if 'WorkspaceProvisioned' in request_body:
            body['WorkspaceProvisioned']= request_body['WorkspaceProvisioned']
        else:
            body['WorkspaceProvisioned']=False
        if "Languages" in request_body and request_body["Languages"]:
            body["Languages"] = request_body["Languages"]
        else:
            body["Languages"] = [language]
        if 'FigmaURL' in request_body:
            body['FigmaURL'] = request_body['FigmaURL']
        else:
            body['FigmaURL'] = None
        if "FigmaPageName" in request_body:
            body['FigmaPageName'] = request_body['FigmaPageName']
        else:
            body['FigmaPageName'] = None
        if 'SelectedConfiguration' in request_body:
            body['SelectedConfiguration'] = request_body['SelectedConfiguration']
        else:
            body['SelectedConfiguration'] = "Arch"
        body['WorkflowUId'] = request_body['WorkflowUId'] if 'WorkflowUId' in request_body else None
        if 'ActivityLogUId' in request_body:
            body['ActivityLogUId'] = request_body['ActivityLogUId']
        else:
            body['ActivityLogUId'] = '00000000-0000-0000-0000-000000000000'
        logger.debug(f"New Request Body : {str(body)}")
        if 'ConfiguredLanguage' in request_body:
            body['ConfiguredLanguage']=request_body['ConfiguredLanguage']
        else:
            body['ConfiguredLanguage']=''

        if 'angular' in body["Languages"]:
            # def check_model(result):
                
            #     model = ""
            #     endpoint = ""
            #     deploymentId = ""
            #     secretKey = ""
            #     for item in result:
            #         if item[0] == 'gpt-4-vision-preview' or 'gpt-4o':
            #             return item[0], item[1], item[2], item[3]
            #         elif item[0] ==  'anthropic.claude-3-sonnet-20240229-v1:0':
            #             model = item[0]
            #             endpoint = item[1]
            #             deploymentId = item[2]
            #             secretKey = item[3]
                        
            #     return model, endpoint, deploymentId, secretKey

            status, result = run_query(aiModelNamefetchquery, (str(RowStatus["Active"].value), request_body['DemographicUId'], str(RowStatus["Active"].value)), fetchone=False, cursor_factory=True)
            logger.debug(f"Ai Query status: {str(status)} and result: {str(result)}")
            if not status or not result:
                return False, f"For DemographicUId: {request_body['DemographicUId']} there is no AI Model configured."

            # modelname, endpoint, deploymentid, secretKey = check_model(result)
            status, counter_result = run_query(modelCounterQuery,(request_body['DemographicUId'],),fetchone=True, cursor_factory=True)
            # models = [GPT_4_VISION_PREVIEW, GPT_4O, ANTHROPIC_CLAUDE_3_SONNET_V1]
            modelname, endpoint, deploymentid, secretKey =  check_model(result, counter_result, request_body['DemographicUId'], angular_models)
            if modelname == "":
                return False, f"Incorrect AI Model is configured. It should be 'gpt-4-vision-preview' or 'gpt-4o' or 'anthropic.claude-3-sonnet-20240229-v1:0 or 'gemini-1.5pro-001'"
            
            body['ModelDetails'] = {'ModelName': modelname, 'Endpoint': endpoint, 'DeploymentId': deploymentid, 'SecretKey': secretKey}
            from flask_app.utils import get_modeluid
            body['ModelUId'] = get_modeluid(body)
        elif 'react' in body["Languages"]:
            # def check_model(result):
            #     model = ""
            #     endpoint = ""
            #     deploymentId = ""
            #     secretKey = ""
            #     for item in result:
            #         if item[0] == 'gpt-4-32k' or 'gpt-4o':
            #             return item[0], item[1], item[2], item[3]
            #         elif item[0] ==  'anthropic.claude-v2:1':
            #             model = item[0]
            #             endpoint = item[1]
            #             deploymentId = item[2]
            #             secretKey = item[3]
            #         elif item[0] ==  'anthropic.claude-3-sonnet-20240229-v1:0':
            #             model = item[0]
            #             endpoint = item[1]
            #             deploymentId = item[2]
            #             secretKey = item[3]

            #     return model, endpoint, deploymentId, secretKey
           
            status, result = run_query(aiModelNamefetchquery, (str(RowStatus["Active"].value), request_body['DemographicUId'], str(RowStatus["Active"].value)), fetchone=False, cursor_factory=True)
            logger.debug(f"Ai Query status: {str(status)} and result: {str(result)}")
            if not status or not result:
                return False, f"For DemographicUId: {request_body['DemographicUId']} there is no AI Model configured."

            # modelname, endpoint, deploymentid, secretKey = check_model(result)
            status, counter_result = run_query(modelCounterQuery,(request_body['DemographicUId'],),fetchone=True, cursor_factory=True)
            # models = [ANTHROPIC_CLAUDE_V2, ANTHROPIC_CLAUDE_3_SONNET_V1]
            modelname, endpoint, deploymentid, secretKey =  check_model(result, counter_result, request_body['DemographicUId'], react_models)
            if modelname == "":
                return False, f"Incorrect AI Model is configured. It should be one of the following:  'gpt-4-32k',  'gpt-4o', 'anthropic.claude-v2:1', 'anthropic.claude-3-sonnet-20240229-v1:0' , 'gemini-1.5-pro-001'"
            
            body['ModelDetails'] = {'ModelName': modelname, 'Endpoint': endpoint, 'DeploymentId': deploymentid, 'SecretKey': secretKey}
            from flask_app.utils import get_modeluid
            body['ModelUId'] = get_modeluid(body)
        return True, body

    except Exception :
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False, str(tb)

def create_request_body_xd(request_body, language):
    body = {}
    try :
       
        body ={}
        body['FolderName'] = request_body["FolderName"]
        body['SessionId'] = request_body["SessionUId"]
        body['CSSFileUploadUId'] = request_body['CSSFileUploadUId']
        body['ClientUId'] = request_body['ClientUId']
        body['DeliveryConstructUId'] = request_body['DeliveryConstructUId']
        body['UserEmailId'] = request_body['UserEmailId']
        body['AppName'] = request_body['AppName']
        body['DemographicUId']=request_body['DemographicUId']
        body['FunctionaAreas'] = list()
        body['Usecase'] = request_body['Usecase']
        if 'CodeGenImageUploadUId' in request_body:
            body['CodeGenImageUploadUId'] = request_body['CodeGenImageUploadUId']
        else:
            body['CodeGenImageUploadUId'] = None
        if 'SelectedConfiguration' in request_body:
            body['SelectedConfiguration'] = request_body['SelectedConfiguration']
        else:
            body['SelectedConfiguration'] = "Arch"
        if 'WorkspaceProvisioned' in request_body:
            body['WorkspaceProvisioned']= request_body['WorkspaceProvisioned']
        else:
            body['WorkspaceProvisioned']=False
        if "Languages" in request_body and request_body["Languages"]:
            body["Languages"] = request_body["Languages"]
        else:
            body["Languages"] = [language]
        body['WorkflowUId'] = request_body['WorkflowUId'] if 'WorkflowUId' in request_body else None
        if 'ActivityLogUId' in request_body:
            body['ActivityLogUId'] = request_body['ActivityLogUId']
        else:
            body['ActivityLogUId'] = '00000000-0000-0000-0000-000000000000'
        logger.debug(f"New Request Body : {str(body)}")

        # def check_model(result):
            
        #     model = ""
        #     endpoint = ""
        #     deploymentId = ""
        #     secretKey = ""
        #     for item in result:
        #         if item[0] == 'gpt-4-vision-preview' or 'gpt-4o':
        #             return item[0], item[1], item[2], item[3]  
        #         elif item[0] ==  'anthropic.claude-3-sonnet-20240229-v1:0':
        #             model = item[0]
        #             endpoint = item[1]
        #             deploymentId = item[2]
        #             secretKey = item[3]
                    
        #     return model, endpoint, deploymentId, secretKey

        status, result = run_query(aiModelNamefetchquery, (str(RowStatus["Active"].value), request_body['DemographicUId'], str(RowStatus["Active"].value)), fetchone=False, cursor_factory=True)
        logger.debug(f"Ai Query status: {str(status)} and result: {str(result)}")
        if not status or not result:
            return False, f"For DemographicUId: {request_body['DemographicUId']} there is no AI Model configured."

        # modelname, endpoint, deploymentid, secretKey = check_model(result)
        status, counter_result = run_query(modelCounterQuery,(request_body['DemographicUId'],),fetchone=True, cursor_factory=True)
        # models = [GPT_4_VISION_PREVIEW, GPT_4O, ANTHROPIC_CLAUDE_3_SONNET_V1]
        modelname, endpoint, deploymentid, secretKey =  check_model(result, counter_result, request_body['DemographicUId'], xd_models)
        if modelname == "":
            return False, f"Incorrect AI Model is configured. It should be 'gpt-4-vision-preview' or 'gpt-4o' or 'anthropic.claude-3-sonnet-20240229-v1:0' or 'gemini-1.5-pro-001'"
        
        body['ModelDetails'] = {'ModelName': modelname, 'Endpoint': endpoint, 'DeploymentId': deploymentid, 'SecretKey': secretKey}
        from flask_app.utils import get_modeluid
        body['ModelUId'] = get_modeluid(body)
        return True, body

    except Exception :
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False, str(tb)

def insert_in_request_table_xd(requestid,body) :
    try:
        new = str(RequestState["New"].value)
        functional_areas = body['FunctionaAreas']
        sessionId = UUID(body['SessionId'])
        time = datetime.utcnow()
        lang = body['Languages']
        appName = str(body['AppName'])
        demoid = UUID(body['DemographicUId'])
        req_body = [{'CodeGenImageUploadUId':body['CodeGenImageUploadUId']}]
        version = check_version_codegen(demoid,appName)
        if not version:
            return False,"Error in checking version in codegen"
        folderName = body['FolderName']
        count = 0 
        workspaceprovisioned=body['WorkspaceProvisioned']
        workspaceuid = '00000000-0000-0000-0000-000000000000'
        workspacename = ""
        workspacetype ='00000000-0000-0000-0000-000000000000'  
        CodeGenImageUploadUId = body['CodeGenImageUploadUId']
        SelectedConfiguration = body['SelectedConfiguration']
        WorkflowUId = body["WorkflowUId"]
        status, result = run_query(workspace_query, (str(demoid),))
        if status:
            workspaceuid = result[0]
            workspacename = result[1]
            workspacetype = result[2]

        requestid = str(requestid)
        CodeGenerationUId = str(uuid.uuid4())
        sessionId = str(sessionId)
        verbose = json.dumps(body)
        rowcoount = run_query(codeGenInsert_query, (CodeGenerationUId,requestid,sessionId,'',new,[],lang,folderName,time,body['UserEmailId'],new, 
                    json.dumps(req_body),str(demoid),appName,version,workspacename,workspaceuid,workspacetype,workspaceprovisioned,body['UserEmailId'],verbose,SelectedConfiguration,None,None,CodeGenImageUploadUId,'', WorkflowUId))

        logger.debug(f"Rowcount {str(rowcoount)} Added record succesfully  :")

        if rowcoount[1] > 0 :
            return True , ""
        else :
            logger.error("Table not found: CodeGenrationRequest")
            return False ,"Table not found: CodeGenrationRequest"
    except Exception as e:
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False, str(tb)

def fetch_brownfield_request(requestid) :
    status, result = run_query(brownfield_request_fetch,(requestid,))
    return status, result

def create_request_body_brownfield_codegen(request_body) -> dict :
    body = {}
    try :
        body['IsBrownField'] = True
        body['FolderPath'] = request_body['FolderPath']
        body['FolderName'] = request_body['FolderName']
        body['Languages'] = request_body['Languages']
        body['GeneratedCodeFolderName'] = request_body['GeneratedCodeFolderName']
        body['WorkflowUId'] = request_body['WorkflowUId'] if 'WorkflowUId' in request_body else None
        #Select Model based on DemographicUId
        # priority=['gpt_models','bedrock_models']
        # def check_model(result):
        #     model = ""
        #     endpoint = ""
        #     deploymentId = ""
        #     secretKey = ""
        #     for item in result:
        #         if item[0] == 'gpt-4-32k' or 'gpt-4o':
        #             return item[0], item[1], item[2], item[3]
        #         elif item[0] ==  'anthropic.claude-v2:1':
        #             model = item[0]
        #             endpoint = item[1]
        #             deploymentId = item[2]
        #             secretKey = item[3]
        #         elif item[0] ==  'anthropic.claude-3-sonnet-20240229-v1:0':
        #             model = item[0]
        #             endpoint = item[1]
        #             deploymentId = item[2]
        #             secretKey = item[3]

        #     return model, endpoint, deploymentId, secretKey

        # check_gpt_presence = lambda result: any(item[0] in ('gpt-4-32k') for item in result)  # , 'gpt-35-turbo-16k', 'text-davinchi-003'
        # check_bedrock_presence = lambda result: any(item[0] in ('anthropic.claude-v2:1') for item in result)  # , 'ai21.j2-ultra-v1', 'cohere.command-text-v14'

        status, result = run_query(aiModelNamefetchquery, (str(RowStatus["Active"].value), request_body['DemographicUId'], str(RowStatus["Active"].value)), fetchone=False, cursor_factory=True)
        logger.debug(f"Ai Query status: {str(status)} and result: {str(result)}")
        if not status or not result:
            return False, f"For DemographicUId: {request_body['DemographicUId']} there is no AI Model configured."

        # modelname, endpoint, deploymentid, secretKey = check_model(result)
        status, counter_result = run_query(modelCounterQuery,(request_body['DemographicUId'],),fetchone=True, cursor_factory=True)
        # models = [ANTHROPIC_CLAUDE_V2, ANTHROPIC_CLAUDE_3_SONNET_V1]
        modelname, endpoint, deploymentid, secretKey =  check_model(result, counter_result, request_body['DemographicUId'], models)
        if modelname == "":
            return False, f"Incorrect AI Model is configured. It should be one of the following:  'gpt-4-32k',  'gpt-4o', 'anthropic.claude-v2:1', 'anthropic.claude-3-sonnet-20240229-v1:0' , 'gemini-pro', 'gemini-1.5-pro-001'"
        
        body['ModelDetails'] = {'ModelName': modelname, 'Endpoint': endpoint, 'DeploymentId': deploymentid, 'SecretKey': secretKey}

        if 'UserStory' in request_body['Requirement']:
            body['Requirement'] = request_body['Requirement']['UserStory']

        if request_body['GenerateOrRegenerateVectors']:
            body['GenerateOrRegenerateVectors'] = request_body['GenerateOrRegenerateVectors']
        else:
            body['GenerateOrRegenerateVectors'] = False

        body['SessionId'] = request_body['SessionId']
        body['ClientUId'] = request_body['ClientUId']
        body['DeliveryConstructUId'] = request_body['DeliveryConstructUId']
        body['UserEmailId'] = request_body['UserEmailId']
        body['AppName'] = request_body['AppName']
        body['DemographicUId']=request_body['DemographicUId']
        body['IsPckgRef']=request_body['IsPckgRef']
        if 'WorkspaceProvisioned' in request_body:
            body['WorkspaceProvisioned']= request_body['WorkspaceProvisioned']
        else:
            body['WorkspaceProvisioned']=False

        if 'SelectedConfiguration' in request_body:
            body['SelectedConfiguration'] = request_body['SelectedConfiguration']
        else:
            body['SelectedConfiguration'] = "Arch"
        if 'CodeGenBrownFieldUId' in request_body:
            body['CodeGenBrownFieldUId'] = request_body['CodeGenBrownFieldUId']
        else:
            body['CodeGenBrownFieldUId'] = '00000000-0000-0000-0000-000000000000'
        if 'ActivityLogUId' in request_body:
            body['ActivityLogUId'] = request_body['ActivityLogUId']
        else:
            body['ActivityLogUId'] = '00000000-0000-0000-0000-000000000000'

        
        logger.debug(f"New Request Body : {str(body)}")
        return True, body 

    except Exception :
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False, str(tb)

def insert_in_request_table_brownfield_codegen(requestid, body) :
    try:
        isbrownfield = body['IsBrownField']
        new = str(RequestState["New"].value)
        sessionId = str(UUID(body['SessionId']))
        time = datetime.utcnow()
        lang = body['Languages']
        appName = str(body['AppName'])
        demoid = UUID(body['DemographicUId'])
        version = check_version_codegen(demoid,appName)
        if not version:
            return False,"Error in checking version in codegen",{}
        
        if 'GeneratedCodeFolderName' in body:
            generatedCodeFolderName = str(body['GeneratedCodeFolderName'])
        else:
            generatedCodeFolderName = str(body['FolderName'])
        workspaceprovisioned=body['WorkspaceProvisioned']
        workspaceuid = '00000000-0000-0000-0000-000000000000'
        workspacename = ""
        workspacetype ='00000000-0000-0000-0000-000000000000'

        SelectedConfiguration = body['SelectedConfiguration']

        status, result = run_query(workspace_query, (str(demoid),))
        if status:
            workspaceuid = result[0]
            workspacename = result[1]
            workspacetype = result[2]

        requestid = str(requestid)
        CodeGenerationUId = str(uuid.uuid4())
        
        body_and_verbose = json.dumps(body)

        rowcount = run_query(brownfieldcodeGenInsert_query, (CodeGenerationUId,requestid,sessionId,
                                                              body_and_verbose, 
                                                              lang,generatedCodeFolderName,body_and_verbose,new,time,body['UserEmailId'],body['UserEmailId'],
                                                              str(demoid),version,appName,workspacename,workspaceuid,workspacetype,workspaceprovisioned, isbrownfield, SelectedConfiguration, None, None, None, '', body['WorkflowUId']))
        
        logger.debug(f"Rowcount {str(rowcount)} Added record succesfully  :")
        if rowcount[1] > 0 :
            return True , ""
        else :
            logger.error("No table found BrownfieldCodeGenerationRequest")
            return False ,"No table found BrownfieldCodeGenerationRequest"
     
    except Exception as e:
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False, str(tb)

class SessionAndTranscationStatus(Enum):
    Default = '00000000-0000-0000-0000-000000000000'
    
class RequestState(Enum):
    New = '00100000-0000-0000-0000-000000000000'
    Inprogress = '00200000-0000-0000-0000-000000000000'
    Success = '00300000-0000-0000-0000-000000000000'
    Failed = '00400000-0000-0000-0000-000000000000'
    Processed = '00500000-0000-0000-0000-000000000000'
    Completed = '00600000-0000-0000-0000-000000000000'

class USStatus(Enum):
    Active = '00500000-0000-0000-0000-000000000000'
    Inactive = '00600000-0000-0000-0000-000000000000'

class RowStatus(Enum):
    Active = '00100000-0000-0000-0000-000000000000'
    Inactive = '00200000-0000-0000-0000-000000000000'

# if __name__ == "__main__":
#     rb = {
#         "FolderName": "dotnet_angular_05_march",
#         "SessionId": "6b39fbdd-8e7b-4b3c-939b-115ff4549fe2",
#         "TransactionUId": "3a8bcb5d-50ac-424d-8b71-1a6f1ededa44",
#         "ModelName": "gpt-4-32k",
#         "CSSFileUploadUId": "4b96bd4b-c8f6-4b04-a8ba-ca2f5647a589",
#         "ClientUId": "8646038a-d9d6-4c19-8528-5075b65d8f1d",
#         "DeliveryConstructUId": "030c096d-49dd-43dd-b851-117c7a4468eb",
#         "Usecase":"null",
#         "UserEmailId": "w4dHc7VGIdr7buKlPXCqAE7oPd5UHJuP7UtDHaJMOAoNuFws7qC5BHgUcZO1u9Fu",
#         "DemographicUId" : "6e74ae2b-6551-4d97-81e2-92805953928b",
#         "AppName":"Authentication App",
#         "Languages": [
#                 "dotnet",
#                 "angular"
#             ],
#         "WorkSpaceName" :"abcd",
#         "WorkSpaceURL":"https",
#         "WorkSpaceUId":"10000000-0000-0000-0000-000000000000",
#         "WorkSpaceTypeUId":"10000000-0000-0000-0000-000000000000"
#     }

#     status, content = create_request_body(rb)
#     print(status, content)
# #     logger.debug(str(get_us_uid("Display Shipping Carrier Costs for Italian Customers", "665562b4-775b-46fd-9b17-49cc8d0bf6f0")))

def create_request_body_figma_html(request_body) -> dict :
    body = {}
    try :
       
        body ={}
        body['FolderName'] = request_body["FolderName"]
        body['FigmaURL']=request_body['FigmaURL']
        body['SessionId'] = '00000000-0000-0000-0000-000000000000'
        body['ClientUId'] = request_body['ClientUId']
        body['DeliveryConstructUId'] = request_body['DeliveryConstructUId']
        body['UserEmailId'] = request_body['UserEmailId']
        body['AppName']=''
        body['DemographicUId']=request_body['DemographicUId']
        body['FunctionaAreas'] = ''
        if 'WorkspaceProvisioned' in request_body:
            body['WorkspaceProvisioned']= request_body['WorkspaceProvisioned']
        else:
            body['WorkspaceProvisioned']=False
        if 'FigmaURL' in request_body:
            body['FigmaURL'] = request_body['FigmaURL']
        else:
            body['FigmaURL'] = None
        if "FigmaPageName" in request_body:
            body['FigmaPageName'] = request_body['FigmaPageName']
        else:
            body['FigmaPageName'] = None
        if 'SelectedConfiguration' in request_body:
            body['SelectedConfiguration'] = request_body['SelectedConfiguration']
        else:
            body['SelectedConfiguration'] = "Arch"
        body['WorkflowUId'] = request_body['WorkflowUId'] if 'WorkflowUId' in request_body else None
        logger.debug(f"New Request Body : {str(body)}")

        # def check_model(result):
                
        #         model = ""
        #         endpoint = ""
        #         deploymentId = ""
        #         secretKey = ""
        #         for item in result:
        #             if item[0] == 'gpt-4-32k' or 'gpt-4o':
        #                 return item[0], item[1], item[2], item[3]
                        
        #         return model, endpoint, deploymentId, secretKey

        status, result = run_query(aiModelNamefetchquery, (str(RowStatus["Active"].value), request_body['DemographicUId'], str(RowStatus["Active"].value)), fetchone=False, cursor_factory=True)
        logger.debug(f"Ai Query status: {str(status)} and result: {str(result)}")
        if not status or not result:
            return False, f"For DemographicUId: {request_body['DemographicUId']} there is no AI Model configured."

        # modelname, endpoint, deploymentid, secretKey = check_model(result)
        status, counter_result = run_query(modelCounterQuery,(request_body['DemographicUId'],),fetchone=True, cursor_factory=True)
        # models = [GPT_4_32K, GPT_4O]
        modelname, endpoint, deploymentid, secretKey =  check_model(result, counter_result, request_body['DemographicUId'], html_models)
        if modelname == "":
            return False, f"Incorrect AI Model is configured. It should be 'gpt-4-32k' or 'gpt-4o'"
        
        body['ModelDetails'] = {'ModelName': modelname, 'Endpoint': endpoint, 'DeploymentId': deploymentid, 'SecretKey': secretKey}
        
        return True, body
        

    except Exception :
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False, str(tb)

def create_request_body_figma_react_native(request_body) -> dict :
    body = {}
    try :
       
        body ={}
        body['ComponentName']=request_body['ComponentName']
        body["HTML"]=request_body["HTML"]
        body["CSS"]=request_body["CSS"]
        body['SessionId'] = '00000000-0000-0000-0000-000000000000'
        body['FolderName'] = request_body['FolderName']
        body['ClientUId'] = request_body['ClientUId']
        body['DeliveryConstructUId'] = request_body['DeliveryConstructUId']
        body['UserEmailId'] = request_body['UserEmailId'] 
        body['AppName']=request_body["ComponentName"]
        body['DemographicUId']=request_body['DemographicUId']
        body['FunctionaAreas'] = ''
        if 'WorkspaceProvisioned' in request_body:
            body['WorkspaceProvisioned']= request_body['WorkspaceProvisioned']
        else:
            body['WorkspaceProvisioned']=False
        body['WorkflowUId'] = request_body['WorkflowUId'] if 'WorkflowUId' in request_body else None
        logger.debug(f"New Request Body : {str(body)}")
        # def check_model(result):
                
        #         model = ""
        #         endpoint = ""
        #         deploymentId = ""
        #         secretKey = ""
        #         for item in result:
        #             if item[0] == 'gpt-4-32k' or 'gpt-4o':
        #                 return item[0], item[1], item[2], item[3]
                        
        #         return model, endpoint, deploymentId, secretKey

        status, result = run_query(aiModelNamefetchquery, (str(RowStatus["Active"].value), request_body['DemographicUId'], str(RowStatus["Active"].value)), fetchone=False, cursor_factory=True)
        logger.debug(f"Ai Query status: {str(status)} and result: {str(result)}")
        if not status or not result:
            return False, f"For DemographicUId: {request_body['DemographicUId']} there is no AI Model configured."

        # modelname, endpoint, deploymentid, secretKey = check_model(result)
        status, counter_result = run_query(modelCounterQuery,(request_body['DemographicUId'],),fetchone=True, cursor_factory=True)
        # models = [GPT_4_32K, GPT_4O]
        modelname, endpoint, deploymentid, secretKey =  check_model(result, counter_result, request_body['DemographicUId'], react_native_models)
        if modelname == "":
            return False, f"Incorrect AI Model is configured. It should be 'gpt-4-32k' or 'gpt-4o'"
        
        body['ModelDetails'] = {'ModelName': modelname, 'Endpoint': endpoint, 'DeploymentId': deploymentid, 'SecretKey': secretKey}
        
        return True, body
    except Exception :
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False, str(tb)
    
def insert_in_request_table_figma_react_native(requestid,body) :
    try:
        new = str(RequestState["New"].value)
        functional_areas = body['FunctionaAreas']
        sessionId = UUID(body['SessionId'])
        time = datetime.utcnow()
        lang = body['Languages']
        appName = ''
        demoid = UUID(body['DemographicUId'])
        req_body = [{'ComponentName':body['ComponentName'], 'HTML':body["HTML"],'CSS':body["CSS"]}]
        
        folderName = str(body['FolderName'])
        version = check_version_codegen(demoid,appName)
        if not version:
            return False,"Error in checking version in codegen"
        folderName = str(body['FolderName'])+"_v"+str(version)
        
        workspaceprovisioned=body['WorkspaceProvisioned']
        workspaceuid = '00000000-0000-0000-0000-000000000000'
        workspacename = ""
        workspacetype ='00000000-0000-0000-0000-000000000000'
        status, result = run_query(workspace_query, (str(demoid),))
        if status:
            workspaceuid = result[0]
            workspacename = result[1]
            workspacetype = result[2]

        requestid = str(requestid)
        CodeGenerationUId = str(uuid.uuid4())
        sessionId = str(sessionId)
        verbose = json.dumps(body)
        WorkflowUId = body["WorkflowUId"]
        rowcoount = run_query(codeGenInsert_react_native_query, (CodeGenerationUId,requestid,sessionId,'',new,[],lang,folderName,time,body['UserEmailId'],new, 
                    json.dumps(req_body),str(demoid),appName,version,workspacename,workspaceuid,workspacetype,workspaceprovisioned,body['UserEmailId'],verbose, WorkflowUId))
       
        logger.debug(f"Rowcount {str(rowcoount)} Added record succesfully  :")
        if rowcoount[1] > 0 :
            return True , ""
        else :
            logger.error("No table found CodeGenrationRequest")
            return False ,"No table found CodeGenrationRequest"
     
    except Exception as e:
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False, str(tb)

def check_apim_config(result):
    model = "gpt-4-32k"
    endpoint = ""
    deploymentId = ""
    secretKey = ""
    for item in result:
        if item[0] == 'apimEndpointUrl':
            endpoint = item[1]
        elif item[0] == 'apimCredential':
            secretKey = item[1]
        elif item[0] == 'apimGPT4DeploymentName':
            deploymentId = item[1]
    return model, endpoint, deploymentId, secretKey

def create_request_body_image_angular(request_body):
    try :
        body ={}
        body['FolderPath']=request_body['FolderPath']
        body["FolderNameMasterlib"]=request_body["FolderNameMasterlib"]
        body["FolderNameMasterPage"]=request_body["FolderNameMasterPage"]
        body['SessionId'] = request_body['SessionId']
        body['TransactionId'] = request_body['TransactionId']
        body['ClientUId'] = request_body['ClientUId']
        body['DeliveryConstructUId'] = request_body['DeliveryConstructUId']
        body['UserEmailId'] = request_body['UserEmailId'] 
        body['AppName']=request_body["AppName"]
        body['DemographicUId']=request_body['DemographicUId']
        body['ConsiderUserStories']=request_body['ConsiderUserStories']
        body['WorkflowUId']=request_body['WorkflowUId']
        body['IsDemo']=request_body['IsDemo']
        body['CodeGenImageToCodeUploadUId']=request_body['CodeGenImageToCodeUploadUId']
        body['SelectedConfiguration']=request_body['SelectedConfiguration']
        body['GeneratedCodeFolderName']=request_body['GeneratedCodeFolderName']
        body['Is_SelectedComponentsForAppcode'] = False
        
        if request_body['ConsiderUserStories']:
            if "SelectedComponentsForAppcode" in request_body and request_body["SelectedComponentsForAppcode"]:
                body['Is_SelectedComponentsForAppcode'] = True
                sessionid = str(SessionAndTranscationStatus["Default"].value)
                transactionid = str(SessionAndTranscationStatus["Default"].value)
                stories_UIds = []
                functionalComponentList = request_body["SelectedComponentsForAppcode"]
                functionalComponentList = json.loads(functionalComponentList)
                for res in functionalComponentList:
                    FunctionalComponent = res["FunctionalComponent"]
                    userstories_UIds = res["UserStories"]
                    stories_UIds.extend(userstories_UIds)
                    
                uid_tuple = tuple(stories_UIds)
                
                if uid_tuple:
                    status,result =  run_query(userstories_UId_query, (uid_tuple,), fetchone=False, cursor_factory=True)
                else:
                    status, result = None, []
            else:
                status, result =run_query(sessionfetchquery, (request_body['DemographicUId'],))
                if not result:
                    logger.error("Unable to find Session and TransactionId in userstory table")
                    raise Exception("Unable to find Session and TransactionId in userstory table")
                sessionid = result[0]
                transactionid = result[1]
                status, result = run_query(nonFunctionalComponentLimitOne_query, (sessionid, transactionid, sessionid, transactionid), fetchone=False, cursor_factory=True)
            if not status:
                logger.error("Unable to find user story details in userstory table")
                raise Exception("Unable to find user story details in userstory table") # "Unable to find details in userstory table"
            res=[]
            functionalareasnames =set()
            for each in result :
                comp = each['Data']['FunctionalComponent']
                fun = {}
                fun['FunctionalComponent'] = comp
                fun['UserStories'] = []
                index = -1
                if comp not in functionalareasnames :
                    functionalareasnames.add(comp)
                else :
                    index = get_functional_area_index(comp,res)
                story = {}
                story['UserStoryUId'] = each['UserStoryUId']
                story['Title'] = each['Data']['Title']
                story['Description'] = each['Data']['Description']
                story['AcceptanceCriteria'] = each['Data']['AcceptanceCriteria']
                fun['UserStories'].append(story)
                if index == -1 :
                    res.append(fun)
                else :
                    if len(res[index]['UserStories']) < 2 :
                        res[index]['UserStories'].append(story)
            body['UserStories'] = res
        
        if 'ActivityLogUId' in request_body:
            body['ActivityLogUId'] = request_body['ActivityLogUId']
        else:
            body['ActivityLogUId'] = '00000000-0000-0000-0000-000000000000'

        status, result = run_query(imageListFetchQuery, (str(body['CodeGenImageToCodeUploadUId']),))
        if not status:
            logger.error(f"Unable to find ImageList in create_request_body_image_angular {str(body['CodeGenImageToCodeUploadUId'])}")
            raise Exception(f"Unable to find ImageList in create_request_body_image_angular {str(body['CodeGenImageToCodeUploadUId'])}")
        functionalAreas=[]
        for res in result[0]:
            imageName=res.get('ImageName')
            position = imageName.find('.')
            if position != -1:
                imageName = imageName[:position]
            functionalAreas.append(imageName)

        body['FunctionaAreas'] = functionalAreas
        if 'WorkspaceProvisioned' in request_body:
            body['WorkspaceProvisioned']= request_body['WorkspaceProvisioned']
        else:
            body['WorkspaceProvisioned']=False
        logger.debug(f"New Request Body : {str(body)}")
        #priority [ Claude-3-sonnet, gpt4vision]
        # def check_model(result):
        #     model = ""
        #     endpoint = ""
        #     deploymentId = ""
        #     secretKey = ""
        #     for item in result:
        #         if item[0] ==  'anthropic.claude-3-sonnet-20240229-v1:0':
        #             model = item[0]
        #             endpoint = item[1]
        #             deploymentId = item[2]
        #             secretKey = item[3]
        #         elif item[0] ==  'gpt-4-vision-preview' or 'gpt-4o':
        #             model = item[0]
        #             endpoint = item[1]
        #             deploymentId = item[2]
        #             secretKey = item[3]

        #     return model, endpoint, deploymentId, secretKey

        if byPassDemogCheckForAIModel.lower() == 'true' :
            status,result = run_query(aiModelNameNoDemofetchquery,(str(RowStatus["Active"].value),),fetchone=False, cursor_factory=True)
        else :
            status, result = run_query(aiModelNamefetchquery, (str(RowStatus["Active"].value), request_body['DemographicUId'], str(RowStatus["Active"].value)), fetchone=False, cursor_factory=True)
        logger.debug(f"Ai Query status: {str(status)} and result: {str(result)}")
        if not status or not result:
            return False, f"For DemographicUId: {request_body['DemographicUId']} there is no AI Model configured."

        if byPassDemogCheckForAIModel.lower() == 'true' :
            tempdemoid = '00000000-0000-0000-0000-000000000000'
        else :
            tempdemoid = request_body['DemographicUId']

        if str(enable_aipm).lower() == "true":
            if is_cloud == "true":
                modelname = 'gpt-4-vision-preview'
                endpoint, secretKey, deploymentid = readOpenAISecretsAIMConfig()
                logger.debug(f"ReadOpenAISecrets: {modelname}, {endpoint}, {deploymentid}")
            else:
                status, result = run_query(apimConfigModelNamefetchquery, 
                                           (instance, str(RowStatus["Active"].value)), 
                                           fetchone=False, cursor_factory=True)
                logger.debug(f"Ai Query status: {str(status)} and result: {str(result)}")
                if not status or not result:
                    return False, f"For DemographicUId: {request_body['DemographicUId']} \
                        No AI Model configured."
                modelname, endpoint, deploymentid, secretKey = check_apim_config(result)
        else:
            # status, counter_result = run_query(modelCounterQuery,(tempdemoid,),fetchone=True, cursor_factory=True)
            # modelname, endpoint, deploymentid, secretKey = check_model(result,counter_result,tempdemoid)
            status, counter_result = run_query(modelCounterQuery,(request_body['DemographicUId'],),fetchone=True, cursor_factory=True)
            # models = [ANTHROPIC_CLAUDE_3_SONNET_V1, GPT_4_VISION_PREVIEW, GPT_4O]
            modelname, endpoint, deploymentid, secretKey =  check_model(result, counter_result, request_body['DemographicUId'], image_models, isFrontend=True)
            # modelname, endpoint, deploymentid, secretKey = check_model(result)

        if modelname == "":
            return False, f"Incorrect AI Model is configured. It should be either 'gpt-4-vision-preview' or 'gpt-4o' or 'anthropic.claude-3-sonnet-20240229-v1:0' or 'gemini-1.5-pro-001'"
        
        body['ModelDetails'] = {'ModelName': modelname, 'Endpoint': endpoint, 'DeploymentId': deploymentid, 'SecretKey': secretKey}
        from flask_app.utils import get_modeluid
        body['ModelUId'] = get_modeluid(body)
        return True, body
    except Exception :
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False, str(tb)
    
def insert_in_request_table_image_angular(requestid,body):
    try:
        new = str(RequestState["New"].value)
        functional_areas = body['FunctionaAreas']
        sessionId = UUID(body['SessionId'])
        time = datetime.utcnow()
        lang = body['Languages']
        appName = str(body['AppName'])
        demoid = UUID(body['DemographicUId'])       
        version = check_version_codegen(demoid,appName)
        if not version:
            return False,"Error in checking version in codegen"
        folderName = str(body['GeneratedCodeFolderName'])
        count = 0 
        workspaceprovisioned=body['WorkspaceProvisioned']
        workspaceuid = '00000000-0000-0000-0000-000000000000'
        workspacename = ""
        workspacetype ='00000000-0000-0000-0000-000000000000'

        status, result = run_query(workspace_query, (str(demoid),))
        if status:
            workspaceuid = result[0]
            workspacename = result[1]
            workspacetype = result[2]
            
        stories = []
        if body['ConsiderUserStories']:
            for index, fun_component in enumerate(body['UserStories']) :
                req_body = []
                for story in fun_component['UserStories'] :
                    if check_story_publish(story['UserStoryUId'],story['Title'],sessionId) or body['Is_SelectedComponentsForAppcode']:
                        stories.append(story['UserStoryUId'])
                        # req_body.append({"Id": str(story['UserStoryUId']),"Title" : story["Title"]})
        
        
        for index, name in enumerate(functional_areas) :
            verbose = ''
            requestid = str(requestid)
            CodeGenerationUId = str(uuid.uuid4())
            sessionId = str(sessionId)
            if index == 0 :
               verbose = json.dumps(body)
               status, rowcoount = run_query(codeGenImageInsert_query, (CodeGenerationUId,requestid,sessionId,name,new,stories,lang,folderName,time,body['UserEmailId'],new, 
                        json.dumps(body),str(demoid),appName,version,workspacename,workspaceuid,workspacetype,workspaceprovisioned,body['UserEmailId'],verbose, body['CodeGenImageToCodeUploadUId'], body['SelectedConfiguration']))
            else :   
                stories = []
                status, rowcoount = run_query(codeGenImageInsert_query, (CodeGenerationUId,requestid,sessionId,name,new,stories,lang,folderName,time,body['UserEmailId'],new, 
                        json.dumps(body),str(demoid),appName,version,workspacename,workspaceuid,workspacetype,workspaceprovisioned,body['UserEmailId'],verbose, body['CodeGenImageToCodeUploadUId'], body['SelectedConfiguration']))
            if not status:
                raise Exception("Unable to insert data in CodeGenerationRequest table")
            count += rowcoount
            logger.debug(f"Rowcount {str(rowcoount)} Added record succesfully  :")

        if count > 0 :
            return True , ""
        else :
            logger.error("No table found CodeGenrationRequest")
            return False ,"No table found CodeGenrationRequest"
     
    except Exception as e:
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False, str(tb)

def insert_in_codegen_image_to_code(requestid,request_body):
    try:
        CodeGenImageToCodeUId=str(uuid.uuid4())
        MasterLibraryFilePath=os.path.join(os.path.join(request_body["FolderPath"],request_body["DemographicUId"]),"MasterLibrary")
        MasterPageFilePath=os.path.join(os.path.join(request_body["FolderPath"],request_body["DemographicUId"]),"MasterPage")
        time = datetime.utcnow()
        RowStatusUId='00100000-0000-0000-0000-000000000000'
        status, rowcoount = run_query(codeGenImageToCode_query, (CodeGenImageToCodeUId,MasterLibraryFilePath,request_body['FolderNameMasterlib'],MasterPageFilePath,
                                    request_body['FolderNameMasterPage'], request_body["GeneratedCodeFolderName"], request_body["ConsiderUserStories"], request_body["DemographicUId"], 
                                    request_body["WorkflowUId"], request_body["IsDemo"], request_body["SessionId"], RowStatusUId, time, 'SYSTEM', time, 'SYSTEM', str(requestid)))
        if not status:
            raise Exception("Unable to insert data in CodeGenImageToCode table")
        return True
    except Exception as e:
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return str(tb)
    
def create_request_body_feature_story(request_body) -> dict :
    body = {}
    try :
        body['FileName'] = request_body['FileName'] if 'FileName' in request_body else ''
        
        # def check_model(result):
        #     model = ""
        #     endpoint = ""
        #     deploymentId = ""
        #     secretKey = ""
        #     for item in result:
        #         if item[0] == 'gpt-4-32k' or 'gpt-4o':
        #             return item[0], item[1], item[2], item[3]
        #         elif item[0] ==  'anthropic.claude-v2:1':
        #             model = item[0]
        #             endpoint = item[1]
        #             deploymentId = item[2]
        #             secretKey = item[3]
        #         elif item[0] ==  'anthropic.claude-3-sonnet-20240229-v1:0':
        #             model = item[0]
        #             endpoint = item[1]
        #             deploymentId = item[2]
        #             secretKey = item[3]

        #     return model, endpoint, deploymentId, secretKey

        status, result = run_query(aiModelNamefetchquery, (str(RowStatus["Active"].value), request_body['DemographicUId'], str(RowStatus["Active"].value)), fetchone=False, cursor_factory=True)
        logger.debug(f"Ai Query status: {str(status)} and result: {str(result)}")
        if not status or not result:
            return False, f"For DemographicUId: {request_body['DemographicUId']} there is no AI Model configured."

        # modelname, endpoint, deploymentid, secretKey = check_model(result)
        status, counter_result = run_query(modelCounterQuery,(request_body['DemographicUId'],),fetchone=True, cursor_factory=True)
        # models = [ANTHROPIC_CLAUDE_V2, ANTHROPIC_CLAUDE_3_SONNET_V1]
        modelname, endpoint, deploymentid, secretKey =  check_model(result, counter_result, request_body['DemographicUId'], models)
        if modelname == "":
            return False, f"Incorrect AI Model is configured. It should be one of the following:  'gpt-4-32k',  'gpt-4o', 'anthropic.claude-v2:1', 'anthropic.claude-3-sonnet-20240229-v1:0' , 'gemini-pro', 'gemini-1.5-pro-001'"
        
        body['ModelDetails'] = {'ModelName': modelname, 'Endpoint': endpoint, 'DeploymentId': deploymentid, 'SecretKey': secretKey}
        from flask_app.utils import get_modeluid
        body['ModelUId'] = get_modeluid(body)
        body['SessionId'] = request_body['SessionId'] if "SessionId" in request_body else str(uuid.uuid4())
        body['ClientUId'] = request_body['ClientUId'] if "ClientUId" in request_body else None
        body['DeliveryConstructUId'] = request_body['DeliveryConstructUId'] if "DeliveryConstructUId" in request_body else None
        body['UserEmailId'] = request_body['UserEmailId'] if "UserEmailId" in request_body else ""
        body['AppName'] = request_body['AppName'] if "AppName" in request_body else None
        body['DemographicUId'] = request_body['DemographicUId']
        if 'ActivityLogUId' in request_body:
            body['ActivityLogUId'] = request_body['ActivityLogUId']
        else:
            body['ActivityLogUId'] = '00000000-0000-0000-0000-000000000000'
        
        body['FolderName'] = request_body['FolderName'] if 'FolderName' in request_body else ''
        
        
        logger.debug(f"New Request Body : {str(body)}")
        return True, body 

    except Exception :
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False, str(tb)
    
def insert_in_feature_story_gen_request_table(requestid,body) :
    try:
        new = str(RequestState["New"].value)
        functional_areas = body['FunctionaAreas'] if "FunctionaAreas" in body else ""
        sessionId = str(UUID(body['SessionId']))
        time = datetime.utcnow()
        lang = body['Languages'] if "Languages" in body else []
        appName = str(body['AppName'])
        demoid = str(UUID(body['DemographicUId']))
        
        version = check_version_codegen(demoid,appName)
        if not version:
            return False,"Error in checking version in codegen"
        # folderName = str(body['FolderName'])+"_v"+str(version)
        folderName = str(body['FolderName']) if "FolderName" in body else ""
        
        count = 0 
        
        workspaceuid = '00000000-0000-0000-0000-000000000000'
        workspacename = ""
        workspacetype ='00000000-0000-0000-0000-000000000000'

        WorkflowUId = body["WorkflowUId"] if "WorkflowUId" in body else None
        CodeGenerationUId = str(uuid.uuid4())
        verbose = json.dumps(body)
        functional_areas = "Feature and UserStory"
        status, rowcoount = run_query(codeGenInsert_query, (CodeGenerationUId,str(requestid),sessionId,functional_areas,new,[],lang,folderName,time,body['UserEmailId'],new, json.dumps(body),str(demoid),appName,version,workspacename,workspaceuid,workspacetype,None,body['UserEmailId'],verbose, None, None, None, None, "Feature UserStory Generation", WorkflowUId))
        count += rowcoount
        logger.debug(f"Rowcount {str(rowcoount)} Added record succesfully  :")

        if count > 0 :
            return True , ""
        else :
            logger.error("No table found CodeGenrationRequest")
            return False ,"No table found CodeGenrationRequest"
     
    except Exception as e:
        tb = traceback.format_exc()
        logger.error(f"traceback: {str(tb)}")
        return False, str(tb)

def check_model(result, counter_result, DemographicUId, models, isFrontend=False):
    model = ""
    endpoint = ""
    deploymentId = ""
    secretKey = ""
    total_count = 0
    current_counter = 1
    allowed_models = []
    for item in result:
        if isFrontend and item[0] == ANTHROPIC_CLAUDE_3_SONNET_V1:
            return item[0], item[1], item[2], item[3]
        if item[0] in models:
            allowed_models.append(item)
            total_count += 1

    if counter_result is None or len(counter_result) == 0 :
        run_query(modelsCounterInsert,(str(DemographicUId),total_count,1))
    else :
        current_counter = counter_result['Counter'] 
        #check total subscription matches
        if  total_count != counter_result['TotalSubscription'] :
            current_counter = 1
        else :#increment current_counter by 1
            current_counter = (current_counter + 1) % (counter_result['TotalSubscription']+1)
            current_counter = current_counter if current_counter > 0 else 1
        #check condition where zero is there current_counter
        modifiedon = datetime.now()
        run_query(modelsCounterUpdate,(total_count,current_counter,modifiedon,str(DemographicUId)))
        

    c = 0
    for item in allowed_models:
        c += 1
        if c == current_counter :
            model, endpoint, deploymentId, secretKey = item[0], item[1], item[2], item[3]
            break

    return model, endpoint, deploymentId, secretKey

# if __name__ == "__main__":
#     # GPT_4_32K = 'gpt-4-32k'
#     # GPT_4O = 'gpt-4o'
#     # GPT_4_VISION_PREVIEW = 'gpt-4-vision-preview'
#     # ANTHROPIC_CLAUDE_V2 = 'anthropic.claude-v2:1'
#     # ANTHROPIC_CLAUDE_3_SONNET_V1 = 'anthropic.claude-3-sonnet-20240229-v1:0'
#     result = [[GPT_4O, "ep", "di", "sk"], [ANTHROPIC_CLAUDE_3_SONNET_V1, "e1", "di1", "sk1"]]
#     counter_result = {}
#     counter_result['Counter'] = 1
#     counter_result['TotalSubscription'] = 2
#     DemographicUId = "auuid"
#     models = [ANTHROPIC_CLAUDE_3_SONNET_V1, GPT_4_VISION_PREVIEW, GPT_4O]
#     print(str(check_model(result, counter_result, DemographicUId, models, isFrontend=False)))
import os, requests, json, ast, re, boto3
from azure.storage.blob import BlobServiceClient
from azure.core.exceptions import (
    AzureError,
    ClientAuthenticationError,
    ResourceNotFoundError,
    ServiceRequestTimeoutError
)
from enum import Enum
import time
import traceback
from assetdetails import insert_to_asset, update_asset_details_image_models
from app_logger import get_alogger
from config import prompt_custom_query, prompt_default_query, modeluid_query, GPT_4TURBO, GPT_4O, GPT_4_VISION_PREVIEW
from ai_core.configs.settings import KEY_GPT3_ENC, KEY_GPT4_ENC
from ai_core.configs.file_encryptor import get_configparser_obj
# import vertexai
# from vertexai.generative_models import GenerativeModel, Part , Image
from google.oauth2 import service_account
import base64
from codegen_langchain.models import get_llm
from botocore.config import Config
from tenacity import retry, stop_after_attempt, wait_fixed, retry_if_exception_type
from ai_core.configs.settings import readOpenAISecrets, decrypt_username
# Read the configuration file
# config = configparser.ConfigParser()
# conf_file_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),"config.ini")
# config.read(conf_file_path)

#Read pythonconfig for azure openai
python_conf_file_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),"pythonconfig.ini")
config = get_configparser_obj(python_conf_file_path)

# Get the container name and blob name from the configuration file
azure_blob_conf = config["AzureBlob"]
connection_string = azure_blob_conf.get("ConnectionString")
container_name =  azure_blob_conf.get("ContainerName")
blob_name = azure_blob_conf.get("BlobName")


azure_conf = config["Azure-openai"]
openai_api_base = azure_conf.get("openai_api_base")
key = azure_conf.get("key")
deployment_name = azure_conf.get("deployment_name")
openai_api_version = azure_conf.get("openai_api_version")
#gpt4
openai_api_base_gpt4 = azure_conf.get("openai_api_base_gpt4")
key_gpt4 = azure_conf.get("key_gpt4")
deployment_name_gpt4 = azure_conf.get("deployment_name_gpt4")
#gpt35
openai_api_base_gpt35 = azure_conf.get("openai_api_base_gpt35")
key_gpt35 = azure_conf.get("key_gpt35")

#Image_models
openai_api_version = azure_conf.get("openai_api_version")
openai_api_version_gpt4o = azure_conf.get("openai_api_version_gpt4o")
openai_api_version_4_turbo = azure_conf.get("openai_api_version_gpt4-turbo")

aws_conf = config["aws"]
bedrock_conf=config["bedrock"]
# gemini_conf = config["google_gemini"]

logger = get_alogger()

class ModelUID(Enum):
    GPT4 = '00600000-0000-0000-0030-000000000000'
    CLAUDE3 = '00600000-0000-0000-0140-000000000000'
    CLAUDE2 = '00600000-0000-0000-0090-000000000000'
    GPT4O = '00600000-0000-0000-0160-000000000000'

def get_resp(query):
    data = { 
    "prompt":query,
    "temperature": 0,
    "top_p": 1,
    "frequency_penalty": 0,
    "presence_penalty": 0,
    "max_tokens": 3500,
    "stop": None }
    kwargs = {"api-version":openai_api_version}
    headers = {"Content-Type": "application/json", "api-key":key,"Authorization":"Bearer " + key}
    # Calling the API
    response = requests.post(url = openai_api_base,params = kwargs,headers=headers,json=data,verify=False)
    return response

def get_data(query,asset_details):
    count = 1
    response = None
    resp_new ={}
    token ={}
    resp_new['Responses']=[]
    while count < 4:
        if count>1:
            time.sleep(15)
        count += 1
        response = get_resp(query)
        if response.status_code == 200:
            resp_json = response.json()
            #get token,model
            token['PromptToken'] = resp_json['usage']['prompt_tokens']
            token['CompletionToken'] = resp_json['usage']['completion_tokens']
            token['Responsetime'] = response.elapsed.total_seconds()
            token['ModelName'] = deployment_name
            token['SubscriptionId'] = KEY_GPT3_ENC
            prompt = query
            insert_to_asset(asset_details,prompt,token)
            resp_new['Responses'].append(resp_json['choices'][0]['text'])
            return resp_new

    return None


def get_resp_gpt4(query:str)-> requests.post:
    """
    Creating a function to get the data from the API for GPT 4
    Args: query:str
    Returns: dict
    """
    data =  {
            "messages":[{"role": "user","content": query}],
            "frequency_penalty": 0.9,
            "presence_penalty": 0,
            "max_tokens": 4000,
            "stop": None,
            "temperature": 0.0 }
    kwargs = {"api-version":openai_api_version}
    headers = {"Content-Type": "application/json", "api-key":key_gpt4,"Authorization":"Bearer " + key_gpt4}
    # Calling the API
    response = requests.post(url = openai_api_base_gpt4,params = kwargs,headers=headers,json=data,verify=False)
    return response


def get_data_gpt4(query, asset_details):
    count = 1
    response = None
    token ={}
    while count < 4:
        count += 1
        # time.sleep(15)
        response = get_resp_gpt4(query)
        if response.status_code == 200:
            resp_json = response.json()
            #get token,model
            token['PromptToken'] = resp_json['usage']['prompt_tokens']
            token['CompletionToken'] = resp_json['usage']['completion_tokens']
            token['Responsetime'] = response.elapsed.total_seconds()
            token['ModelName'] = deployment_name_gpt4
            token['SubscriptionId'] = KEY_GPT4_ENC
            prompt = query
            try:
                insert_to_asset(asset_details,prompt,token)
            except Exception as e:
                tb = traceback.format_exc()
                logger.error(f"Error in updating asset details: {str(tb)}")
            return resp_json['choices'][0]['message']['content']
    logger.debug(f"response : {str(response.text)}")
    return None

def get_data_gpt4_lib(query, asset_details):
    count = 1
    response = None
    token ={}
    # time.sleep(15)
    while count < 7:
        count += 1
        time.sleep(15)
        response = get_resp_gpt4(query)
        if response.status_code == 200:
            resp_json = response.json()
            #get token,model
            token['PromptToken'] = resp_json['usage']['prompt_tokens']
            token['CompletionToken'] = resp_json['usage']['completion_tokens']
            token['Responsetime'] = response.elapsed.total_seconds()
            token['ModelName'] = deployment_name_gpt4
            token['SubscriptionId'] = KEY_GPT4_ENC
            prompt = query
            try:
                insert_to_asset(asset_details,prompt,token)
            except Exception as e:
                tb = traceback.format_exc()
                logger.error(f"Error in updating asset details: {str(tb)}")
            return resp_json['choices'][0]['message']['content']

    logger.debug(f"response : {str(response.text)}")

    return None

def get_resp_gpt35(query:str)-> requests.post:
    """
    Creating a function to get the data from the API for GPT 35
    Args: query:str
    Returns: dict
    """
    data =  {
            "messages":[ {"role": "system","content": "You are a senior python developer"},
                {"role": "user","content": query}],
            "frequency_penalty": 0.0,
            "presence_penalty": 0,
            "max_tokens": 4000,
            "stop": None,
            "temperature": 0.0 }
    kwargs = {"api-version":openai_api_version}
    headers = {"Content-Type": "application/json", "api-key":key_gpt35,"Authorization":"Bearer " + key_gpt35}
    # Calling the API
    response = requests.post(url = openai_api_base_gpt35,params = kwargs,headers=headers,json=data,verify=False)
    return response


def get_data_gpt35(query, asset_details):
    count = 1
    response = None
    token ={}
    while count < 4:
        count += 1
        response = get_resp_gpt35(query)
        if response.status_code == 200:
            resp_json = response.json()
            #get token,model
            token['PromptToken'] = resp_json['usage']['prompt_tokens']
            token['CompletionToken'] = resp_json['usage']['completion_tokens']
            token['Responsetime'] = response.elapsed.total_seconds()
            prompt = query
            try:
                insert_to_asset(asset_details,prompt,token)
            except Exception as e:
                tb = traceback.format_exc()
                logger.error(f"Error in updating asset details: {str(tb)}")
            return resp_json['choices'][0]['message']['content']

    return None


def write_to_file(file_name:str, data:str):
    """
    Creating a function to write the data to a file
    Args: file_name:str, data:str
    Returns: None
    """
    try:
        with open(file_name, "w") as f:
            f.write(data)
    except Exception as e:
        logger.error(f"Exception occured: {str(e)}")

def upload_to_blob(data, foldername='', filename=''):
    """Uploads data to an Azure blob.

    Args:
        data: The data to be uploaded.
        foldername: The folder name within the blob container.
        filename: The file name within the blob container.

    Returns:
        The path to the uploaded blob.
    """

    blob = get_blob_path(foldername, filename)

    success = False  # Flag to track success or failure

    try:
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        # Get a reference to a specific blob within a container
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob)

        # Upload the string data to the blob
        blob_client.upload_blob(data, overwrite=True)

        # Upload successful, set the flag to True
        success = True

    except ResourceNotFoundError as e:
        logger.error(f"Blob or container not found: {str(e)}")
    except ServiceRequestTimeoutError as e:
        logger.error(f"Request to upload blob timed out: {str(e)}")
    except ClientAuthenticationError as e:
        logger.error(f"Authentication error or Invalid connection string: {str(e)}")
    except AzureError as e:
        logger.error(f"Azure error: {str(e)}")
    except Exception as e:
        logger.error(f"An error occurred: {str(e)}")
    
    return success


def delete_blob(foldername='', filename=''):
    """Uploads data to an Azure blob.

    Args:
        data: The data to be uploaded.
        foldername: The folder name within the blob container.
        filename: The file name within the blob container.

    Returns:
        The path to the uploaded blob.
    """

    blob = get_blob_path(foldername, filename)

    success = False  # Flag to track success or failure

    try:
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        # Get a reference to a specific blob within a container
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob)

        # Upload the string data to the blob
        blob_client.delete_blob(delete_snapshots="include")

        # Upload successful, set the flag to True
        success = True

    except ResourceNotFoundError as e:
        logger.error(f"Blob or container not found: {str(e)}")
    except ServiceRequestTimeoutError as e:
        logger.error(f"Request to upload blob timed out: {str(e)}")
    except ClientAuthenticationError as e:
        logger.error(f"Authentication error or Invalid connection string: {str(e)}")
    except AzureError as e:
        logger.error(f"Azure error: {str(e)}")
    except Exception as e:
        logger.error(f"An error occurred: {str(e)}")
    
    return success


def read_folder_structure():
    file_path = os.path.join(os.getcwd(), "flask_app", "templates", "template_py.json")   #"python_app"
    template_json_file = open(file_path)
    json_strt = json.load(template_json_file)

    project_folder = os.path.join(os. getcwd(),"project")
    os.mkdir(project_folder)
    create_folder_structure(json_strt,project_folder)

def create_folder_structure(json_strt,project_folder):
    for itemfile in json_strt:
        if itemfile['type'] == 'file':
            file_path = os.path.join(project_folder,itemfile['name'])
            with open(file_path, 'x') as fp:
                pass
        elif itemfile['type'] == 'folder':
            project_folder = os.path.join(project_folder,itemfile['name'])
            os.mkdir(project_folder)
            if "components" in itemfile:
                create_folder_structure(itemfile["components"],project_folder)

def read_create_python_folder_structure(app_code):
    file_path = os.path.join(os.getcwd(), "flask_app", "templates", "template_py.json")
    template_json_file = open(file_path)
    json_strct = json.load(template_json_file)
    create_python_folder_structure(json_strct, app_code, "Python")

def create_python_folder_structure(py_json_struct, app_code, name):
    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    for item in py_json_struct:
        if item['type'].lower() == 'file':
            item_blob_name = blob_name + "/" + app_code + "/" + name + "/" + item['name']
            #f"{blob_name}\\{app_code}\\{name}\\item['name']"
            # Create a file blob 
            blob_client = blob_service_client.get_blob_client(container=container_name, blob=item_blob_name)
            blob_client.upload_blob("", overwrite=True)

def read_create_react_folder_structure(app_code):
    file_path = os.path.join(os.getcwd(), "flask_app", "templates", "template_react.json")
    template_json_file = open(file_path)
    json_strct = json.load(template_json_file)
    create_react_folder_structure(json_strct, app_code, "React")

def create_react_folder_structure(react_json_struct, app_code, name):
    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    for item in react_json_struct:
        if item['type'].lower() == 'file':
            blob_path = blob_name + "/" + app_code + "/" + name + "/" + item['name']
            # Create a file blob
            blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_path)
            blob_client.upload_blob("", overwrite=True)
        elif item['type'].lower() == 'folder':
            folder_path = blob_name + "/" + app_code + "/" + name
            if "src" in item:
                src_folder = folder_path + "/src"
                for subitem in item['src']:
                    if subitem['type'].lower() == 'file':
                        if subitem['name'] in ['Navbar.js','Navbar.css']:
                            pass
                        else:
                            src_path = src_folder + "/" + subitem['name']
                            blob_client = blob_service_client.get_blob_client(container=container_name, blob=src_path)
                            blob_client.upload_blob("", overwrite=True)
         
def get_api_names(source_code):
    try:
        tree = ast.parse(source_code)
        functions=[]
        
        for node in ast.walk(tree):
            
            if isinstance(node, ast.FunctionDef):
                input=[]
                output_params=[]
                function_name = node.name
                for decorator in node.decorator_list:
                    if isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Attribute):
                        if decorator.func.attr == 'route':
                            route = decorator.args[0].s
                            
                            for arg in decorator.keywords:
                                if arg.arg == 'methods' and isinstance(arg.value, ast.List):
                                    methods = [val.s for val in arg.value.elts]
                                    if methods:
                                        method = methods[0]
                                    
                
                # Extract variables assigned from request.args.get() using regex
                    regex_args = r"(\w+)\s*=\s*request\.args\.get\("
                    output_params = re.findall(regex_args, ast.get_source_segment(source_code, node))

                    # Extract return values for GET methods using regex
                    regex_return = r"return\s+(.*)"
                    returns = re.findall(regex_return, ast.get_source_segment(source_code, node))

        
                    pattern = r"(\w+)\s*=\s*request\.get_json\(\)"
                    # Find variable assignments using regex
                    request_var = re.findall(pattern, ast.get_source_segment(source_code, node))
                    if len(request_var)>0:
                        pattern=re.escape(request_var[0])+r"\['(.*?)'\]"
                        input = re.findall(pattern, ast.get_source_segment(source_code, node))
                    
                # methods = re.findall(r'@app.route\(.*?, methods=\[(.*?)\]\)', ast.get_source_segment(source_code, node))
                # Add variables and return values to function_variables_returns dictionary
                functions.append( {
                    'route': route,
                    'method':method,
                    'input': input,
                    'output':output_params,
                    'return_value':returns
                })
        api_prompt=''      
        for index,function in enumerate(functions):
            in_params = ', '.join(function['input'])
            out_params = ', '.join(function['output'])
            return_params = ', '.join(function['return_value'])
        
            if function['method']=='GET':
                
                api_prompt+=f'\napi {index+1}\nroute:{function["route"]}\ninput parameters:{in_params}\nquery parameters:{out_params}\nreturn response:{return_params}\nmethods:{function["method"]}\n'
            else:
                api_prompt+=f'\napi {index+1}\nroute:{function["route"]}\ninput parameters:{in_params}\nmethods:{function["method"]}\n'
        
        return api_prompt
    except Exception as e:
        return ''
    
def split_react_css(code):
    
    """
    Function to split react script and css
    """
    delimiter = 'export default '

    split_index = code.find(delimiter)
    if (split_index != -1):
        while(split_index<len(code)):           
            if code[split_index]==';':
                react_script = code[:split_index+1]
                css_script = code[split_index+1:]
                break
            split_index+=1
    else:
        logger.error("Delimiter not found in the text.")
    css_script = re.sub(r"(//.*?$|/\*.*?\*/)", "", css_script, flags=re.MULTILINE | re.DOTALL)
    return react_script,css_script

def create_app_js(filenames,func_areas,app_js):
    if app_js:
        pattern = r'element={<(.+?)/>} />'
        matches = re.findall(pattern, app_js)
        components=[component for component in matches]
    else:
        components=[]
    
    new_components = [func.replace(' ', '').capitalize() for func in func_areas if func.replace(' ', '').capitalize() + '.js' in filenames]
    components.extend(new_components)
    routes=''
    imports=''
    links=''
    for i in range(len(components)):
        component=components[i]
        if i==0:
            
            route='<Route path="/" element={<'+component+'/>} />\n'
            link='<h3><Link to="/">'+component+'</Link></h3>\n'
        else:
            route='\t\t\t\t\t<Route path="/'+component+'" element={<'+component+ '/>} />\n'
            link='\t\t\t\t\t<h3><Link to="/'+component+'">'+component+'</Link></h3>\n'
        import_template=f"\nimport {component} from \'./components/{component}\';"
        imports+=import_template
        routes+=route
        links+=link
    template = """
import React from 'react';
import {{ BrowserRouter, Routes, Route }} from 'react-router-dom';
import {{ Link }} from 'react-router-dom';
{imports}
const App = () => {{
    return (
        <div className="app">
            <BrowserRouter>
                <div className='navBar'>
                    {links}
                </div>
                <Routes>
                    {routes}
                </Routes>
            </BrowserRouter>
        </div>
    );
}};
export default App;
"""
    app_file=template.format(imports=imports, routes=routes,links=links)
    return app_file

def folder_exists(folder_name):
    # List blobs in the container
    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    # Get a reference to the container
    container_client = blob_service_client.get_container_client(container_name)
    blobs_list = container_client.list_blobs()

    exists = False
    # Iterate over the blobs and check if the blob_exists
    try:
        folder_name_py = folder_name+"/"+"Python"
        folder_name_react = folder_name+"/"+"React"
        for blob in blobs_list:
            if (folder_name_py in blob.name) or ((folder_name_react in blob.name)):
                exists = True
                break
    except ResourceNotFoundError as e:
        logger.error(f"Blob or container not found: {str(e)}")
    except ServiceRequestTimeoutError as e:
        logger.error(f"Request to upload blob timed out: {str(e)}")
    except ClientAuthenticationError as e:
        logger.error(f"Authentication error or Invalid connection string: {str(e)}")
    except AzureError as e:
        logger.error(f"Azure error: {str(e)}")
    except Exception as e:
        logger.error(f"An error occurred: {str(e)}")
    return exists

def read_data_from_blob(foldername, filename):
    data = ''
    try:
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        container_client = blob_service_client.get_container_client(container_name)
        blob = get_blob_path(foldername, filename)
        blob_client = container_client.get_blob_client(blob=blob)
        data = blob_client.download_blob().readall()
        data = data.decode()
    except ResourceNotFoundError as e:
        logger.error(f"Blob or container not found: {str(e)}")
    except ServiceRequestTimeoutError as e:
        logger.error(f"Request to upload blob timed out: {str(e)}")
    except ClientAuthenticationError as e:
        logger.error(f"Authentication error or Invalid connection string: {str(e)}")
    except AzureError as e:
        logger.error(f"Azure error: {str(e)}")
    except Exception as e:
        logger.error(f"An error occurred: {str(e)}")
    return data

def get_blob_path(foldername, filename):
    try:
        if foldername or filename:
            blob = os.path.join(blob_name, foldername, filename)
        else:
            blob = blob_name
    except ResourceNotFoundError as e:
        logger.error(f"Blob or container not found: {str(e)}")
    except ServiceRequestTimeoutError as e:
        logger.error(f"Request to upload blob timed out: {str(e)}")
    except ClientAuthenticationError as e:
        logger.error(f"Authentication error or Invalid connection string: {str(e)}")
    except AzureError as e:
        logger.error(f"Azure error: {str(e)}")
    except Exception as e:
        logger.error(f"An error occurred: {str(e)}")
    
    return blob

# Function to upload files in a directory
def upload_directory(directory_path, relative_path=""):
    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    container_client = blob_service_client.get_container_client(container_name)
    for file_name in os.listdir(directory_path):
        file_path = os.path.join(directory_path, file_name)
        blob_path = os.path.join(relative_path, file_name)
        
        # Check if the current item is a file
        if os.path.isfile(file_path):
            # Create a BlobClient object for the file
            blob_client = container_client.get_blob_client(blob_path)

            # Upload the file to Azure Blob Storage
            with open(file_path, "rb") as file:
                blob_client.upload_blob(file, overwrite=True)
        else:
            # Recursively upload the subdirectory
            upload_directory(file_path, blob_path)

def get_templates(template, demoid, modeluid=None, fetchone=True):

    if modeluid is None:
        modeluid = str(ModelUID["GPT4"].value)

    prompt_template = get_prompts(template,demoid,modeluid,fetchone)
    if not prompt_template:
        prompt_template = get_prompts(template,demoid,modeluid,fetchone,custom=False)

    if not prompt_template :
        msg = f"No prompt found for mentioned template {template}"
        logger.error(msg)
        raise ValueError(msg)
    return prompt_template

def get_multiple_templates(template, demoid, modeluid=None, fetchone=False):

    if modeluid is None:
        modeluid = str(ModelUID["GPT4"].value)
    
    result = []
    prompts_with_demoId = []
    custom_prompt_result = get_prompts(template,demoid,modeluid,fetchone)
    if custom_prompt_result:
        if fetchone:
            return custom_prompt_result
        prompts_with_demoId = [item['Name'] for item in custom_prompt_result]
        default_prompts = list(set(template).symmetric_difference(set(prompts_with_demoId)))
    else:
        default_prompts = template

    if default_prompts:
        result = get_prompts(default_prompts,demoid,modeluid,fetchone,custom=False)

    if result:
        if fetchone:
            return result
        custom_prompt_result.extend(result)
    
    return custom_prompt_result
    
def get_prompts(filter, demoid, modeluid, fetchone=True, custom=True):
    from flask_app.dbutils import run_query
    if custom:
        status, result = run_query(prompt_custom_query,(tuple(filter),demoid,modeluid),fetchone=fetchone, cursor_factory=True)  
    else:
        status, result = run_query(prompt_default_query,(tuple(filter),modeluid),fetchone=fetchone, cursor_factory=True)
    if result:
        return result
    return []            

def get_modeluid(request_body):
    from flask_app.dbutils import run_query
    try:
        modeluid = None
        endpoint = None
        modelname = None
        if 'ModelDetails' in request_body and 'Endpoint' in request_body['ModelDetails'] and 'ModelName' in request_body['ModelDetails']:
            endpoint = request_body['ModelDetails']['Endpoint']
            modelname = request_body['ModelDetails']['ModelName']
        else:
            raise ValueError("ModelDetails or ModelName not found in request_body")
        status, modeluid = run_query(modeluid_query, (endpoint,modelname))
        if not status and not modeluid:
            raise ValueError(f"Unable to fetch modeluid details for the {endpoint} and {modelname}")
        modeluid = modeluid[0] if modeluid else None
        return modeluid
    except KeyError as e:
        logger.error(f"KeyError: {e}")
        raise ValueError("Error accessing keys in request_body")
    except Exception as e:
        logger.error(f"An error occurred: {e}")
        raise ValueError("An error occurred in get_modeluid function")




def generate_gpt_vision(prompt, model_details, asset_details, model_config, image_url=''):
    model_name = model_details["ModelName"]
    api_base = model_details["Endpoint"]
    deployment_name = model_details["DeploymentId"]
    encrypted_api_key = model_details["SecretKey"]
    api_key = readOpenAISecrets(api_base)

    if (not api_key or api_key == "") and encrypted_api_key:
        api_key = decrypt_username(encrypted_api_key)

    if not api_key or api_key == "":
        raise ValueError(f"key_gpt: {api_key} is empty for Model: {model_name}, Secret: {encrypted_api_key}")
    
    version = openai_api_version
    if model_name==GPT_4O:
        version = openai_api_version_gpt4o
    elif model_name==GPT_4TURBO:
        version = openai_api_version_4_turbo
    url = f"{api_base}/openai/deployments/{deployment_name}/chat/completions"
    params = {
        'api-version': version,
        'api-key': api_key
    }

    body = {
        "messages": [
        {
            "role": "user",
            "content": [
                    {
                        "type": "text",
                        "text": prompt
                    }
                ]
            }
        ],
        "max_tokens": model_config["max_tokens"],
        "temperature": model_config["temperature"]
    }
    if  image_url != '':
        if not image_url.startswith('data'):
            image_url = f"data:image/png;base64,{image_url}"
        body = {
            "messages": [
            {
                "role": "user",
                "content": [
                        {
                            "type": "text",
                            "text": prompt
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"{image_url}"
                            }
                        }
                    ]
                }
            ],
            "max_tokens": model_config["max_tokens"],
            "temperature": model_config["temperature"]
        }

    # logger.info(f"URL: {url}")
    # logger.info(f"Params: {params}")
    # logger.info(f"Body: {body}")
    # logger.info(f"Prompt: {prompt}")

    @retry(stop=stop_after_attempt(5), wait=wait_fixed(20), retry=retry_if_exception_type(requests.exceptions.RequestException))
    def make_request(url, params, body):
        response = requests.post(url, params=params, json=body)
        response.raise_for_status()  # Raise an exception for HTTP errors
        return response
    
    try:
        start=time.time()
        response = make_request(url, params, body)
        end = time.time()
        response_time=end-start
        logger.info(f"Response Time: {response_time}")
        logger.info("Request succeeded:", response.json())
    except requests.exceptions.RequestException as e:
        logger.error("Request failed after retries:", e)
        raise Exception("Request failed after retries:", e)


    if response.status_code != 200:
        raise requests.exceptions.RequestException(f"Error occured while generating code. Status: {response.status_code}, Reason: {response.reason}")
    response_json = json.loads(response.text)
    status=update_asset_details_image_models(model_name, api_key, response_json, response_time, asset_details, prompt)
    if not status:
        logger.error("Error updating asset details")
    generated_gpt4 = response_json["choices"][0]["message"]["content"]
    return generated_gpt4

def generate_claude3(prompt,model_details, asset_details, model_config, image_url=''):
    model_name = model_details["ModelName"]
    api_base = model_details["Endpoint"]
    deployment_name = model_details["DeploymentId"]
    encrypted_api_key = model_details["SecretKey"]
    api_key = readOpenAISecrets(api_base)

    if (not api_key or api_key == "") and encrypted_api_key:
        api_key = decrypt_username(encrypted_api_key)

    if not api_key or api_key == "":
        raise ValueError(f"key_gpt: {api_key} is empty for Model: {model_name}, Secret: {encrypted_api_key}")
    a,s = get_aws_keys(api_key)
    region = model_config['region_name']
    bedrock_version = aws_conf.get("aws_bedrock_version")
    max_tokens = bedrock_conf.get("max_tokens_sonnet")
    retry_config = Config(
        region_name = region,
        retries = {
            'max_attempts': 5,
            'mode': 'standard'
        }
    )
    bedrock_runtime = boto3.client(service_name='bedrock-runtime', region_name=region, aws_access_key_id=a, aws_secret_access_key=s, config=retry_config)
    message = [{"role": "user",
        "content": [
        {"type": "text", "text": prompt}
        ]}]
    
    if image_url !='':
        if image_url.startswith('data'):
            image_url = re.sub(r'^data:image/\w+;base64,', '', image_url)
        message = [{"role": "user",
            "content": [
            {"type": "image", "source": {"type": "base64",
                "media_type": "image/png", "data": image_url}},
            {"type": "text", "text": prompt}
        ]}]

    body = json.dumps(
        {
            "anthropic_version": str(bedrock_version),
            "messages": message,
            "max_tokens": int(max_tokens),
            "temperature": model_config['temperature'],
            "top_p": model_config['top_p'],
            "top_k": model_config['top_k'],
        })
    start=time.time()
    response = bedrock_runtime.invoke_model(body=body, modelId=model_name)
    end = time.time()
    response_time=end-start
    # logger.info(f"Body: {body}")
    # logger.info(f"Prompt: {prompt}")
    logger.info(f"Response Time: {response_time}")

    if response['ResponseMetadata']['HTTPStatusCode'] != 200:
        raise requests.exceptions.RequestException(f"Error occured while generating code. Status: {response['ResponseMetadata']['HTTPStatusCode']}")
    response_json = json.loads(response.get('body').read())
    status=update_asset_details_image_models(model_name, api_key, response_json, response_time, asset_details, prompt)
    if not status:
        logger.error("Error updating asset details")
    response = response_json["content"][0]["text"]
    return response

def get_aws_keys(keys: str) -> tuple:
    access = ""
    secret = ""
    ids = keys.split(';')
    for id in ids:
        if 'accesskey' in id:
            access = id.split(':')[1]
        if 'secretkeyid' in id:
            secret = id.split(':')[1]

    return (access, secret)

def gemini_credentials(modelDetails):
    llm_gemini = get_llm(modelDetails,'','SecretKey')
    return  llm_gemini.json_credentials 

# if __name__ == "__main__":
#     result = get_multiple_templates("figma_angular_gpt4v", "6be13e02-73e6-4556-8a2b-20bc68fa5f94", True)

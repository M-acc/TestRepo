#[MDM Details]
#GPT3
schema_gpt3 = "Design database with all required master and transactional \
    tables and columns for User Story. Keep all column names in small case.use 'SERIAL' datatype for all the primary keys.Append _"+"table_var" + " to the table names"
create_tab_gpt3 = "Create python script to create and insert " + "3" + " records using postgreSQL of dbname "+"postgres"+" username as "+"postgres" + " password " +"password" + ".Table creation should follow correct sequence in case of foreign key reference and create tables from schema given only.Keep all column names in small case.\
Data insertion should not contain special characters .Write codes inside python function " + "def db_scripts_"
create_tab_gpt3_2 ="(): Do not call this function after function generated"
#prompt4 = "Do not create scripts for tables mentioned as it is duplicate"
#prompt3 = "Create python script to select records of all tables generated using postgreSQL of dbname " +dbname +"user" +user +"password" +password+"Do not generate extra codes. Keep all column names in small case.\
#Write codes inside python function "+ function_name +"Do not call this function"
create_tab_sql_gpt3 = "Create script to create and insert" + "3" + "records using using postgreSQL of dbname " +"postgres" +" user " +"postgres" +" password " +"password" +". Table creation should follow correct sequence in case of foreign key reference and should not contain NOT NULL constraint.Keep all column names in small case.All the verbose should be commented."
#prompt6 = "Create script to select records of all tables generated using postgreSQL of dbname " +dbname +"user" +user +"password" +password + ". Keep all column names in small case."
create_tab_generic_gpt3 = "Create PLACEHOLDER script to create and insert " + "3" + " records using postgreSQL of dbname "+"postgres"+" username as "+"postgres" + " password " +"password" + ".Table creation should follow correct sequence in case of foreign key reference and create tables from schema given only.Keep all column names in small case.\
Data insertion should not contain special characters .Write codes inside PLACEHOLDER function "

#[API]
api_prompt1 = "Create python backend api script using flask framework to support functionality of following user stories:"
api_prompt2_gpt3 = " Post request data should be from the data variable. Use logging module to log info level logs,\
use log filename as app_logger.log. You can refer the postgres database schema and use psycopg2 library to connect \
postgres database, add conn rollback before execute. Use hardcoded localhost db connection string, postgres as user and password as password for database connection. \
Note: Do not put postgres database connection code in try except block. Refer the database schema:"
generic_api_prompt1 = "Create PLACEHOLDER to support functionality of following user stories:"
generic_api_prompt2 = "Post request data should be from the data variable. Do not write user story details in the code. Do not add unnecessary verbose in the code. You can refer the database schema and use required library to connect postgres database, add conn rollback before execute: refer the database schema: "
java_placeholder = "create java RESTful api script using Spring Boot framework and create controller classes which contain implementation of the REST APIs to"
dotnet_placeholder = "create .net script which contains RESTful api"
ruby_placeholder = "create RESTful api script using Ruby on rails framework."


# react
# react
react_prompt1="Generate a react page along with css and working controls using functional \
components by combining the requirements from stories below in a logical flow to \
create a working application along with dummy data. Do not duplicate functionality \
and give one tab for each functionality, with the first tab opened by default. \
Make sure to draw reference from any popular existing application, to replicate \
the UI functionality and application outlook. Do not have any dependency to any \
external files. All the buttons and search boxes should be functional. \
Do not use UseEffect hook. Consider the layout, navigation, visual aesthetics, \
and interactive elements for seamless user experience Stories:"
# angular_prompt ="Generate AngularJs page using functional components by combining the \
# requirements from stories below in a logical flow to create a working page \
# along with dummy data. Do not duplicate functionality. Make sure to use \
# any real world application.Do not have any dependency to any \
# external files.All the buttons and search boxes should be \
# functional. Do not use UseEffect hook. Stories:"
react_prompt2=".\n Integrate the page with python APIs running on port 5000 using\
only fetch API calls.add headers in fetch calls.All variables should be generated in snake_case.\
API names:"

dotnet_prompt1 = "Write .net  script  with models, controllers with route attributes and \
add http methods like [HttpPost()] end points as per userstory which reads connectionstring \
from appsettings.json using configuration.GetConnectionString('DefaultConnection').Value,\
implements api endpoints which contains RESTful api to support functionality of \
following user stories. Use ## separator to separate the files \
eg.##Models/filename.cs,##UsageSummary.We have already available Model folder path for all models files,Controllers for controller files.Complete code should be written .Don't give \
comment to write Implementations instead cover all the functionality in \
the generated functions. Do not generate files other than Models,Controllers. User Story:"

dotnet_prompt2 = ".Post request data \
should be from the data variable. Do not write user story details\
in the code. Do not add unnecessary verbose in the code,database \
schema:"

dotnet_prompt3 = ". After code generation Write the usage \
summary for generated api. Summary should be short and should\
contain the details of API name, method type and parameters \
required.Comment of filenames should follow proper directory structure "

dotnet_prompt4 = "Write .net  Data Access Layer code with interface using Summary, Models details,userstory and database schema. \
Use Npgsql database and read dburl from appsettings.json using configuration.GetSection(db_url).Value to connect to database. Summary"

dotnet_prompt5 = ".Use ## separator \
to separate the files eg.##DataAccess/filename.cs .We have already available Model folder for all models files,Controllers for controller files,Interface folder for all interface files and Repository folder for DataAccess Code "

dotnet_prompt6 =  ".Post request data should \
be from the data variable. Do not write user story details in the code. Do not add unnecessary \
verbose in the code.Database schema:"

angular_prompt = "Generate Angular page along with working controls using functional components \
by combining the requirements from stories below in a logical \
flow to create a working page. HTML and Typescript code should be generated with their respective file names. \
Do not create empty functions.\
and give one tab for each functionality, with the first tab opened by default. \
Make sure to draw reference from any popular existing application, to replicate \
the UI functionality and application outlook.\
Component class name should be unique and different from AppComponent. \
Do not generate app.component.html, app.component.ts and app.module.ts, \
Consider the layout, navigation, visual aesthetics, \
and interactive elements for seamless user experience\
user stories:"

angular_prompt2= "Post request data should be from the data variable. Do not add verbose in the code.\
Available API only for reference:"

angular_prompt3 = "Important: Do not return csharp code, only create only one html \
and one typescript and add seperator #### between script. Use only correct type annotations "

#Angular GPT 3.5
angular_prompt_gpt35 = "Generate Angular 2016 page along with working controls using functional components by \
combining the requirements from stories below in a logical flow to create a working \
page. Do not generate and use names app.componenet.html, app.componenet.ts and app.componenet.css in code. \
Do not create empty functions and give one tab for each functionality, \
with the first tab opened by default All the buttons and search boxes should be functional.\
Do not generate HTML tags: <html>, <head>, <title>, <body>. \
Consider the layout, navigation, visual aesthetics, \
and interactive elements for seamless user experience."

angular_prompt2_gpt35= " Do not add verbose in the code. "
angular_prompt21_gpt35 = "Use the APIs delimited by backticks to generate logic of functions in typescript: ```"
angular_prompt22_gpt35 = "``` "

angular_prompt3_gpt35 = "Important: Do not return csharp code, create only one html \
and one typescript and add seperator ####HTML for html and ####Typescript for Angular component code. \
Do not add any other separator except ####. Use only correct type annotations. "

 

#GPT 4
schema_gpt4= "Design database with all required master and transactional \
tables and columns for User Story. Keep all column names in small case.use SERIAL \
datatype for all the primary keys. Generate database design without scripts.Append _"+"table_var" + " to the table names"
    
create_tab_gpt4 = "For all tables, create script to create and insert " + "3" + " records using using postgreSQL of dbname " +"postgres" +" user " +"postgres" +" password " +"password" +". Table creation should follow correct sequence in case of foreign key reference and should not contain NOT NULL constraint.Keep all column names in small case.All the verbose should be commented."

api_prompt2 = " Post request data should be from the data variable. You can refer the postgres database schema and use psycopg2 library to connect postgres database \
using conn= psycopg2.connect(os.environ.get('db_url') cur = conn.cursor(), add conn rollback before execute: refer the database schema:"

react_prompt1_gpt4="Generate a react page along with css and working controls using functional \
components by combining the requirements from stories below in a logical flow to \
create a working application. Do not duplicate functionality \
and give one tab for each functionality, with the first tab opened by default. \
Make sure to draw reference from any popular existing application, to replicate \
the UI functionality and application outlook. Do not have any dependency to any \
external files. All the buttons and search boxes should be functional. \
Do not use UseEffect hook. Consider the layout, navigation, visual aesthetics, \
and interactive elements for seamless user experience \
Wrap all the buttons inside a div container with flexContainerRow class. \
Wrapping of div container with flexContainerRow class should happen only for button tags, but do not include other tags."

react_prompt2_gpt4 = " In the generated react page add a parent div with container class. \
Add the inline className 'flexContainerRow' to all the input, select and label tags in the code. \
Do not wrap up the className 'flexContainerRow' in a div and place the input, select and label tags inside a div. Stories:"

#gpt35
#api_prompt1_gpt35 = "Create python backend api script using flask framework to support functionality of following user stories.\
#Note:Consider one tab(four spaces) for indentation in python code and use lowercase for writing python code:"
api_prompt1_gpt35 ="Create python backend api script using flask framework to support functionality of following user stories:"

api_prompt2_gpt35 ="Generate all the relevant python apis for the user story.\
Post request data should be from the data variable. You can refer the postgres database schema and use psycopg2 library to connect postgres database \
using conn= psycopg2.connect(os.environ.get('db_url') cur = conn.cursor(), add conn rollback before execute: refer the database schema:"


react_prompt1_gpt35="Write code of react page along with css and working controls using functional \
components by combining the requirements from stories below in a logical flow to \
create a working application. Do not duplicate functionality \
and give one tab for each functionality, with the first tab opened by default. \
Make sure to draw reference from any popular existing application, to replicate \
the UI functionality and application outlook. Do not have any dependency to any \
external files. All the buttons and search boxes should be functional. \
Do not use UseEffect hook. Consider the layout, navigation, visual aesthetics, \
and interactive elements for seamless user experience \
Wrap all the buttons inside a div container with flexContainerRow class. \
Wrapping of div container with flexContainerRow class should happen only for button tags, but do not include other tags."

#Dotnet GPT3
dotnet_prompt1_gpt3 = "Write .net  script  with models, controllers with route attributes and \
add http methods like [HttpPost()] end points as per userstory which reads connectionstring \
from appsettings.json using configuration.GetConnectionString('DefaultConnection').Value,\
implements api endpoints which contains RESTful api to support functionality of \
following user stories. Use ## separator to separate the files \
eg.##Models/filename.cs,##UsageSummary.We have already available Model folder path for all models files,Controllers for controller files.\
Comment of filenames should follow proper directory structure .Complete code should be written .Don't give \
comment to write Implementations instead cover all the functionality in \
the generated functions.Do not generate files other than Models,Controllers. User Story:"

dotnet_prompt2_gpt3 = ".Post request data \
should be from the data variable.Use log4net to add logs and use constructor to initialise the logs.Do not write user story details\
in the code. Do not add unnecessary verbose in the code,database \
schema:"

dotnet_prompt3_gpt3= "After code generation Write the short usage summary for generated api \
(should contain the details of API name, method type and parameters required with proper name and datatype of parameter) and \
 model summary(should contain the details of namespace and properties)."

dotnet_prompt4_gpt3 = "Write .net  Data Access Layer code with interface in separate file using Summary, Models details and database schema. \
Use Npgsql database and read dburl from appsettings.json using configuration.GetSection(db_url).Value to connect to database. Summary"

dotnet_prompt5_gpt3 = ".Use ## separator \
to separate the files eg.##DataAccess/filename.cs.Do not use any other separator except ## .Imprtant:Response should contain newline character.We have already available \
Model folder for all models files,Controllers for controller files,Interface folder for all interface files and Repository folder for DataAccess Code "

dotnet_prompt6_gpt3 =  ".Post request data should \
be from the data variable. Use log4net to add logs and use constructor to initialise the logs.\
Do not write user story details in the code .Do not generate Models,Controllers code. Do not add unnecessary \
verbose in the code.Database schema:"

java_prompt = "Create a Springboot application with java classes models, controllers,services, repository with respective annotations like @SpringBootApplication, @RestController, @Service, @Repository. \
Add import statements in each class with their interdependencies. Generate getter and setters in classes do not leave comment for implementation.\
Add http methods with annotations like @GetMapping or @PostMapping end points as per userstory. \
Use ## separator to separate the files and generate file names with proper package structure eg.##src/main/java/com/app/SampleApplication.java. Complete code should be written don't give \
comment to write Implementations instead cover all the functionality in the generated functions. User Story :"


java_prompt2 = "\n Database schema:"

java_prompt3 =" After code generation Write the usage \
summary for generated api. Summary should be short and should\
contain the details of API name, method type and parameters required. Generated code should be inside doc string ''' code ''''."

language_translation_prompt="Translate the given App Name to the mentioned Language, if you can't directly translate, use something closest to the possible App Name. Language: {language}. App Name: {app_name}. Return only the translated text, do not add any verbose."

# Queries
modeluid_query = """Select "ModelUId" from "AIModel" where "Endpoint"= %s and "ModelName"= %s"""
nonFunctionalComponent_query = """SELECT * FROM "UserStory" WHERE "SessionId" = %s AND "TransactionId" = %s AND "Data" ->> 'NonFunctionalComponent' is null  AND "Data" ->>  'FunctionalComponent' is not null ; """
nonFunctionalComponentLimitOne_query = """SELECT * FROM "UserStory" WHERE "SessionId" = %s AND "TransactionId" = %s AND "Data" ->> 'NonFunctionalComponent' is null  AND "Data" ->>  'FunctionalComponent' = (SELECT ("Data" ->>  'FunctionalComponent') as "FunctionalComponent" FROM "UserStory" WHERE "SessionId" = %s AND "TransactionId" = %s AND "Data" ->> 'NonFunctionalComponent' is null AND "Data" ->>  'FunctionalComponent' is not null Limit 1); """
userstories_UId_query = """SELECT * FROM "UserStory" WHERE \"UserStoryUId\" IN %s"""
codeGenInsert_query = """INSERT INTO "CodeGenerationRequest" ("CodeGenerationUId", "RequestUId", "SessionUId","FunctionalArea","FunctionalAreaStatus","UserStories","TechnologyStack","FolderName","CreatedOn","CreatedByUser","OverallStatus", "Body","DemographicUId","AppName","Version","WorkSpaceName","WorkSpaceUId","WorkSpaceTypeUId","WorkspaceProvisioned","ModifiedByUser","Verbose", "SelectedConfiguration", "FigmaURL", "FigmaPageName", "CodeGenImageUploadUId", "ComponentType", "WorkflowUId") VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
codeGenInsertArch_query = """INSERT INTO "CodeGenerationRequest" ("CodeGenerationUId", "RequestUId", "SessionUId","FunctionalArea","FunctionalAreaStatus","UserStories","TechnologyStack","FolderName","CreatedOn","CreatedByUser","OverallStatus", "Body","DemographicUId","AppName","Version","WorkSpaceName","WorkSpaceUId","WorkSpaceTypeUId","WorkspaceProvisioned","ModifiedByUser","Verbose", "SelectedConfiguration", "FigmaURL", "FigmaPageName", "CodeGenImageUploadUId", "ComponentType","ArchitectureComponents", "WorkflowUId","ModelName","ModelEndpoint") VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
brownfieldcodeGenInsert_query = """INSERT INTO "CodeGenerationRequest" ("CodeGenerationUId", "RequestUId", "SessionUId","Body","TechnologyStack","FolderName","Verbose","OverallStatus","CreatedOn","CreatedByUser","ModifiedByUser","DemographicUId","Version","AppName","WorkSpaceName","WorkSpaceUId","WorkSpaceTypeUId","WorkspaceProvisioned","IsBrownField", "SelectedConfiguration", "FigmaURL", "FigmaPageName", "CodeGenImageUploadUId", "ComponentType", "WorkflowUId") VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s, %s,%s,%s,%s,%s,%s)"""
codeGenImageInsert_query = """INSERT INTO "CodeGenerationRequest" ("CodeGenerationUId", "RequestUId", "SessionUId","FunctionalArea","FunctionalAreaStatus","UserStories","TechnologyStack","FolderName","CreatedOn","CreatedByUser","OverallStatus", "Body","DemographicUId","AppName","Version","WorkSpaceName","WorkSpaceUId","WorkSpaceTypeUId","WorkspaceProvisioned","ModifiedByUser","Verbose", "CodeGenImageToCodeUploadUId", "SelectedConfiguration") VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
codeGenImageToCode_query = """INSERT INTO "CodeGenImageToCode" ("CodeGenImageToCodeUId", "MasterLibMountPath", "MasterLibName", "MasterPageMountPath","MasterPageName","GeneratedCodeFolderName","ConsiderUserStories","DemographicUId","WorkflowUId","IsDemo","SessionUId","RowStatusUId","CreatedOn","CreatedByUser","ModifiedOn","ModifiedByUser", "RequestUId") VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
FigmaFrontendInsert_query = """INSERT INTO "CodeGenerationRequest" ("CodeGenerationUId", "RequestUId", "SessionUId","FunctionalArea","FunctionalAreaStatus","UserStories","TechnologyStack","FolderName","CreatedOn","CreatedByUser","OverallStatus", "Body","DemographicUId","AppName","Version","WorkSpaceName","WorkSpaceUId","WorkSpaceTypeUId","WorkspaceProvisioned","ModifiedByUser","Verbose", "SelectedConfiguration", "FigmaURL", "FigmaPageName", "ComponentType", "WorkflowUId","Framework") VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
storyPublish_query = """SELECT * FROM "UserStory" WHERE "SessionId" = %s AND "Data" ->> 'Title' = %s ORDER BY "CreatedOn" DESC; """
usuid_query = """SELECT "UserStoryUId" from "UserStory" WHERE "Data"->>'Title'=%s AND \"SessionId\"=%s"""
cssFileUpload_query = """SELECT "FileContent" FROM "CSSFileUploads" WHERE "CSSFileUploadUId" = %s """
requestStatus_query = """SELECT * FROM "CodeGenerationRequest" WHERE "RequestUId" = %s"""
insertAsset_query = """INSERT INTO "AssetLog" ("AssetLogUId", "SessionUId","FeatureName","SubFeatureName","ModelName", "PromptCost","CompletionCost","SubscriptionId","PromptToken","CompletionToken","ResponseTime","Prompt","CreatedOn","UserEmailId","CreatedByUser", "ModifiedByUser", "RowStatusUId", "DemographicUId", "ActivityLogUId", "IsSuccess", "Endpoint") VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
assetDetails_query = """SELECT "PromptCost","CompletionCost" FROM "Cost" WHERE "ModelName" = %s ; """
updateCodeGen_query = """UPDATE "CodeGenerationRequest" SET "FunctionalAreaStatus" = %s , "Verbose" = %s WHERE "RequestUId" = %s and "FunctionalArea" = %s"""
updateOverall_query = """UPDATE "CodeGenerationRequest" SET "OverallStatus" = %s  WHERE "RequestUId" = %s"""
updateOverall_query1 = """UPDATE "CodeGenerationRequest" SET "OverallStatus" = %s , "Verbose" = %s WHERE "RequestUId" = %s"""
updateFileNameAngular_query = """UPDATE "CodeGenerationRequest" SET "FileNames" = %s , "FolderName" = %s WHERE "RequestUId" = %s and "FunctionalArea" = %s"""
updateBrownFieldCodeGenFileName_query = """UPDATE "CodeGenerationRequest" SET "FileNames" = %s , "FolderName" = %s WHERE "RequestUId" = %s"""
updateFileName_query = """UPDATE "CodeGenerationRequest" SET "FileNames" = %s , "FolderName" = %s WHERE "RequestUId" = %s and "FunctionalArea" = %s"""
updateCodeGenSeq_query = """UPDATE "CodeGenerationRequest" SET "FunctionalAreaStatus" = %s , "Verbose" = %s WHERE "RequestUId" = %s and "FunctionalArea" = %s"""
updateComponentCodeGenSeq_query = """UPDATE "CodeGenerationRequest" SET "FunctionalAreaStatus" = %s , "Verbose" = %s , "FileNames" = %s , "FolderName" = %s WHERE "RequestUId" = %s and "FunctionalArea" = %s"""
updateOverallSeq = """UPDATE "CodeGenerationRequest" SET "OverallStatus" = %s  WHERE "RequestUId" = %s"""
updateOverallSeq1 = """UPDATE "CodeGenerationRequest" SET "OverallStatus" = %s , "Verbose" = %s WHERE "RequestUId" = %s"""
updateFileNameSeq = """UPDATE "CodeGenerationRequest" SET "FileNames" = %s , "FolderName" = %s WHERE "RequestUId" = %s and "FunctionalArea" = %s"""
updateFileNameAngSeq = """UPDATE "CodeGenerationRequest" SET "FileNames" = %s , "FolderName" = %s WHERE "RequestUId" = %s and "FunctionalArea" = %s"""
updateComponentCodeRequestBody = """UPDATE "CodeGenerationRequest" SET "ComponentCodeRequestBody" = %s  WHERE "RequestUId" = %s"""
updateComponentCodeMappingResponse = """UPDATE "CodeGenerationRequest" SET "ComponentsMappingResponse" = %s  WHERE "RequestUId" = %s"""
fetchComponentCodeMappingResponse = """SELECT "ComponentsMappingResponse" FROM "CodeGenerationRequest" WHERE "RequestUId" = %s"""
fetchComponentCodeFileNames = """SELECT "FileNames" FROM "CodeGenerationRequest" WHERE "RequestUId" = %s and "FunctionalArea" = %s"""
updateFeatureStoryGenRequestBody = """UPDATE "CodeGenerationRequest" SET "Body" = %s  WHERE "RequestUId" = %s"""


fetchTech_query = """SELECT "DemographicUId" FROM "Demographic" where "AssociatedClientUID"=%s AND "AssociatedDeliveryConstructUId"=%s ORDER BY "ModifiedOn" DESC;"""
AppArch_query = """SELECT "TechnologyComponentUId" FROM "ApplicationArchitectureTechnology" where "ApplicationArchitectureUId" in (SELECT  "AppArchitectureUId" FROM "ApplicationArchitecture" where "DemographicUid" =%s AND "UseCase"= %s AND "ComponentName" in %s ORDER BY "ModifiedOn" DESC );"""
AppArch_query1 = """SELECT "TechnologyComponentUId" FROM "ApplicationArchitectureTechnology" where "ApplicationArchitectureUId" in (SELECT  "AppArchitectureUId" FROM "ApplicationArchitecture" where "DemographicUid" =%s AND "UseCase"= %s AND "ComponentName"=%s ORDER BY "ModifiedOn" DESC  );"""
Tech_query = """ SELECT "Technology" FROM "TechnologyComponent" where "TechnologyComponentUId" = %s; """
Tech_query1 = """ SELECT "Technology" FROM "TechnologyComponent" where "TechnologyComponentUId" = %s; """
selectversion_query="""SELECT max("Version") FROM "CodeGenerationRequest" where "AppName" = %s AND "DemographicUId" = %s AND "OverallStatus" = %s;"""
workspace_query= """ SELECT "WorkspaceUId", "Name","WorkspaceTypeUId" FROM "WorkSpace" where "WorkspaceUId" = (SELECT "WorkspaceUId"
	FROM "Demographic"  where "DemographicUId"=%s);"""
sessionfetchquery = """SELECT "SessionId","TransactionId" FROM "UserStory" where "DemoGraphicUId"=%s order by "CreatedOn" desc LIMIT 1 """
blobInsert_query = """INSERT INTO "BlobFolderDeletionRequest" ("BlobFolderDeletionUId","FolderName", "ErrorMessage", "DemographicUId","CreatedOn","ModifiedOn","CreatedByUser","ModifiedByUser") VALUES (%s,%s,%s,%s,%s,%s,%s,%s)"""
blobupdateIsdelete = """UPDATE "BlobFolderDeletionRequest" SET "IsDeleted" = %s  WHERE "FolderName" = %s; """
blobupdateerrormsg = """UPDATE "BlobFolderDeletionRequest" SET "ErrorMessage" = %s  WHERE "FolderName" = %s; """
updateFigmaFoldername = """UPDATE "CodeGenerationRequest" SET "FolderName" = %s, "AppName" = %s  WHERE "RequestUId" = %s"""
getFigmaToken = """SELECT "Value" FROM "DemographicAttribute" WHERE "AttributeUId" = %s AND "DemographicUId" = %s AND "RowStatusUId" = %s"""
updateFigmaFiles = """UPDATE "CodeGenerationRequest" SET "FileNames" = %s, "FunctionalArea" = %s WHERE "RequestUId" = %s"""
updateFileNameSegment = """UPDATE "CodeGenerationRequest" SET "FileNames" = %s , "FolderName" = %s WHERE "RequestUId" = %s"""
updateFunAreaStatusSegment = """UPDATE "CodeGenerationRequest" SET "FunctionalAreaStatus" = %s , "Verbose" = %s WHERE "RequestUId" = %s """
updateFileNameFigma = """UPDATE "FigmaReactRequest" SET "FileName" = %s,"Verbose"=%s WHERE "RequestUId" = %s AND "NodeId"=%s AND "IsPage"=%s"""
FigmaRequestInsert_query = """INSERT INTO "FigmaReactRequest" ("FigmaRequestUId", "RequestUId", "NodeId","NodeName","FileKey","Status","IsPage","CreatedOn","CreatedByUser","ModifiedByUser","DemographicUId") VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
updateFigmaComponentStatus= """UPDATE "FigmaReactRequest" SET "Status" = %s,"Verbose"=%s  WHERE "RequestUId" = %s AND "NodeId"=%s AND "IsPage"=%s"""
updateFigmahierarchy = """UPDATE "CodeGenerationRequest" SET "Body" = %s  WHERE "RequestUId" = %s"""
figmarequestStatus_query = """SELECT * FROM "FigmaReactRequest" WHERE "RequestUId" = %s AND "IsPage"=%s"""
updateVerbose = """UPDATE "CodeGenerationRequest" SET "Verbose" = %s  WHERE "RequestUId" = %s"""
updateFileNameSeq_java = """UPDATE "CodeGenerationRequest" SET "FileNames" = %s  WHERE "RequestUId" = %s and "FunctionalArea" = %s"""
FigmaRequestPageNodeInsert_query="""INSERT INTO "FigmaReactRequest" ("FigmaRequestUId", "RequestUId", "NodeId","NodeName","IsPage","PageNodes","FileKey","CreatedOn","CreatedByUser","ModifiedByUser","DemographicUId") VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
figmapagenode_query = """SELECT "PageNodes","IndexNames" FROM "FigmaReactRequest" WHERE "NodeId" = %s and "FileKey"=%s and "IsPage"=%s order by "ModifiedOn" DESC"""
updateIndexNames= """UPDATE "FigmaReactRequest" SET "IndexNames" = %s WHERE "RequestUId" = %s AND "NodeId"=%s AND "IsPage"=%s"""
updateOverallFigma = """UPDATE "CodeGenerationRequest" SET "OverallStatus" = %s, "FunctionalAreaStatus" = %s WHERE "RequestUId" = %s"""
updateOverallFigma1 = """UPDATE "CodeGenerationRequest" SET "OverallStatus" = %s ,"FunctionalAreaStatus" = %s, "Verbose" = %s WHERE "RequestUId" = %s"""
request_fetch = '''select "Verbose" from "CodeGenerationRequest" where "RequestUId" = %s and "Verbose" != ''  '''
brownfield_request_fetch = '''select "Body" from "CodeGenerationRequest" where "RequestUId" = %s and "Verbose" != ''  '''
# aimodeluidfetchquery = """SELECT "AIModelUId" FROM "AIModelDemographic" where "DemographicUId"=%s order by "CreatedOn" desc """
# modelnamefetchquery = """SELECT "ModelName" FROM "AIModel" where "AIModelUId"=%s """
aiModelNamefetchquery = """SELECT "ModelName", "Endpoint", "DeploymentName", "SecretKey" FROM "AIModel" WHERE "RowStatusUId" = %s AND "AIModelUId" = ANY (SELECT "AIModelUId" FROM "AIModelDemographic" WHERE "DemographicUId" = %s AND "RowStatusUId" = %s)"""
imageFetchQuery = """SELECT "ImagesList" FROM "CodeGenImageUpload" WHERE "CodeGenImageUploadUId" = %s"""
imageListFetchQuery = """SELECT "ImagesData" FROM "CodeGenImageToCodeUpload" WHERE "CodeGenImageToCodeUploadUId" = %s"""
updateOverallBrownFieldCodeGen = """UPDATE "CodeGenerationRequest" SET "OverallStatus" = %s WHERE "RequestUId" = %s"""
updateOverallBrownFieldCodeGen1 = """UPDATE "CodeGenerationRequest" SET "OverallStatus" = %s, "Verbose" = %s WHERE "RequestUId" = %s"""
modelCounterQuery = """SELECT * FROM "ModelsCounter" WHERE "DemographicUId" = %s"""
modelsCounterInsert = """INSERT INTO "ModelsCounter" ("DemographicUId","TotalSubscription", "Counter") VALUES (%s,%s,%s)"""
modelsCounterUpdate = """UPDATE  "ModelsCounter" SET "TotalSubscription"= %s, "Counter" =%s, "ModifiedOn"=%s WHERE  "DemographicUId" = %s"""
codeGenInsert_react_native_query = """INSERT INTO "CodeGenerationRequest" ("CodeGenerationUId", "RequestUId", "SessionUId","FunctionalArea","FunctionalAreaStatus","UserStories","TechnologyStack","FolderName","CreatedOn","CreatedByUser","OverallStatus", "Body","DemographicUId","AppName","Version","WorkSpaceName","WorkSpaceUId","WorkSpaceTypeUId","WorkspaceProvisioned","ModifiedByUser","Verbose", "WorkflowUId") VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
apimConfigModelNamefetchquery="""SELECT "Key", "Value" FROM "Setting" WHERE "Instance" = %s AND "RowStatusUId" = %s"""
aiModelNameNoDemofetchquery = """SELECT "ModelName", "Endpoint", "DeploymentName", "SecretKey" FROM "AIModel" WHERE "RowStatusUId" = %s"""
vectorgeneratedquery = """SELECT "APIStatus"->0->>'IsVectorGenerated' AS "IsVectorGenerated" FROM "CodeGenerationRequest" WHERE "RequestUId"=%s AND "AppName" = %s AND "DemographicUId" = %s ORDER BY "CreatedOn" DESC LIMIT 1"""
updateBrownFieldCodeGen = """UPDATE "CodeGenerationRequest" SET "APIStatus" = jsonb_set(jsonb_set(jsonb_set("APIStatus", '{0, Name}', %s),'{0, Status}', %s),'{0, IsVectorGenerated}', %s), "Tokens" = %s, "SelectedConfiguration" = %s WHERE "RequestUId" = %s AND "AppName" = %s AND "DemographicUId" = %s"""
updateBrownFieldCodeGenAPI1 = """UPDATE "CodeGenerationRequest" SET "APIStatus" = jsonb_set(jsonb_set(jsonb_set("APIStatus", '{0, Name}', %s),'{0, Status}', %s),'{0, IsVectorGenerated}', %s), "OverallStatus" = %s WHERE "RequestUId" = %s AND "AppName" = %s AND "DemographicUId" = %s"""
updateBrownFieldCodeGenAPI1Verbose = """UPDATE "CodeGenerationRequest" SET "APIStatus" = jsonb_set(jsonb_set(jsonb_set("APIStatus", '{0, Name}', %s),'{0, Status}', %s),'{0, IsVectorGenerated}', %s), "OverallStatus" = %s, "Verbose" = %s WHERE "RequestUId" = %s AND "AppName" = %s AND "DemographicUId" = %s"""
updateBrownFieldCodeGenAPI2 = """UPDATE "CodeGenerationRequest" SET "APIStatus" = jsonb_set(jsonb_set(jsonb_set("APIStatus", '{1, Name}', %s),'{1, Status}', %s),'{1, IsVectorGenerated}', %s), "OverallStatus" = %s WHERE "RequestUId" = %s AND "AppName" = %s AND "DemographicUId" = %s"""
updateBrownFieldCodeGenAPI2Verbose = """UPDATE "CodeGenerationRequest" SET "APIStatus" = jsonb_set(jsonb_set(jsonb_set("APIStatus", '{1, Name}', %s),'{1, Status}', %s),'{1, IsVectorGenerated}', %s), "OverallStatus" = %s, "Verbose" = %s WHERE "RequestUId" = %s AND "AppName" = %s AND "DemographicUId" = %s"""
updateBrownFieldCodeGenAPI3 = """UPDATE "CodeGenerationRequest" SET "APIStatus" = jsonb_set(jsonb_set("APIStatus", '{2, Name}', %s),'{2, Status}', %s), "OverallStatus" = %s WHERE "RequestUId" = %s AND "AppName" = %s AND "DemographicUId" = %s"""
updateBrownFieldCodeGenAPI3Verbose = """UPDATE "CodeGenerationRequest" SET "APIStatus" = jsonb_set(jsonb_set("APIStatus", '{2, Name}', %s),'{2, Status}', %s), "OverallStatus" = %s, "Verbose" = %s WHERE "RequestUId" = %s AND "AppName" = %s AND "DemographicUId" = %s"""
brownfieldrequestStatus_query = """SELECT * FROM "CodeGenerationRequest" WHERE "AppName" = %s AND "DemographicUId" = %s AND "APIStatus"->0->>'IsVectorGenerated'='True' ORDER BY "CreatedOn" DESC LIMIT 1 """
brownfieldSimilarFilesUpdate = """UPDATE "CodeGenerationRequest" SET "SimilarFiles" = %s WHERE "RequestUId" = %s AND "AppName" = %s AND "DemographicUId" = %s"""
brownfieldFilesUpdate = """UPDATE "CodeGenerationRequest" SET "UserSelectedFiles" = %s WHERE "RequestUId" = %s AND "AppName" = %s AND "DemographicUId" = %s"""
#brownfieldpollVectorLoad_query = """SELECT "RequestUId", "APIStatus"->0->>'Status' AS Status, "APIStatus"->0->>'IsVectorGenerated' AS IsVectorGenerated FROM "CodeGenerationRequest" where "RequestUId"=%s AND "APIStatus"->0->>'Name'=%s """
brownfieldpollVectorLoad_query = """SELECT "RequestUId", "APIStatus"->0->>'Status' AS Status, "APIStatus"->0->>'IsVectorGenerated' AS IsVectorGenerated, "APIStatus" FROM "CodeGenerationRequest" where "RequestUId"=%s """
brownFieldToken_query = """UPDATE "CodeGenerationRequest" SET "Tokens"=%s WHERE "RequestUId" = %s AND "AppName" = %s AND "DemographicUId" = %s"""
#brownfieldpollVectorSimilarity_query = """SELECT "RequestUId", "APIStatus"->1->>'Status' AS Status,"APIStatus"->1->>'IsVectorGenerated' AS IsVectorGenerated, "SimilarFiles" FROM "CodeGenerationRequest" where "RequestUId"=%s  AND "APIStatus"->1->>'Name'=%s """
brownfieldpollVectorSimilarity_query = """SELECT "RequestUId", "APIStatus"->1->>'Status' AS Status,"APIStatus"->1->>'IsVectorGenerated' AS IsVectorGenerated, "SimilarFiles", "APIStatus" FROM "CodeGenerationRequest" where "RequestUId"=%s"""
updateBrownFieldTokens = """UPDATE "CodeGenerationRequest" SET "TokensConsumed" = '{"TotalTokens": %s, "InputTokens": %s, "OutputTokens": %s}' WHERE "RequestUId" = %s AND "AppName" = %s AND "DemographicUId" = %s"""
greenfieldDetails_query="""SELECT * FROM "GreenfieldCodeGenRequest" WHERE "RequestUId" = %s"""
greenfieldInsert="""INSERT INTO "GreenfieldCodeGenRequest" ("GreenFieldUId", "RequestUId", "SessionUId", "InitiatedModuleName", "SummaryStatus", "FolderStatus", "DBSchemaStatus", "PlannerStatus", "CodeStatus", "Verbose", "CreatedOn", "CreatedByUser", "ModifiedByUser","DemographicUId", "WorkSpaceName", "WorkSpaceUId", "WorkSpaceTypeUId", "WorkspaceProvisioned") VALUES ( %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
updateGreenfieldCodeGenStatus= """UPDATE "GreenfieldCodeGenRequest" SET "SummaryStatus" = %s,"FolderStatus" = %s,"DBSchemaStatus" = %s,"PlannerStatus" = %s,"CodeStatus" = %s,"Verbose"=%s  WHERE "GreenFieldUId"=%s"""
greenfieldRequestStatus_query = """SELECT * FROM "GreenfieldCodeGenRequest" WHERE "RequestUId" = %s"""
folderName_query="""SELECT "FolderName" FROM "CodeGenerationRequest" WHERE "RequestUId" = %s """
updateGreenfieldFiles= """UPDATE "GreenfieldCodeGenRequest" SET "GeneratedFiles" = %s,"FileGenerationPercentage" = %s WHERE "GreenFieldUId"=%s"""
read_verbose="""SELECT "Verbose" FROM "CodeGenerationRequest" WHERE "RequestUId" = %s """
updateCodeGenmodule_query = """UPDATE "CodeGenerationRequest" SET "GreenFieldModule" = %s WHERE "RequestUId" = %s"""
updateVersion_query = """UPDATE "CodeGenerationRequest" SET "Version" = %s WHERE "RequestUId" = %s"""


#[Kafka Prompts]

prompt_kadmin="""generate code for Kafka Admin for creating, deleting and listing all topics within the Kafka ecosystem. Use ## separator to separate the file eg. ##application.properties for properties and ##pom.xml for dependencies.Do not add unneccessary verbose""" 
prompt_kserial="""generate code for kafka serialization to convert the object into bytes using pre-built method Serializer with ObjectMapper and explicitly include JsonSerializer. Use ## separator to separate the files \
eg. ##application.properties for properties and ##pom.xml for dependencies.Do not add unneccessary verbose in the response.""" 
prompt_kdeserial="""generate code for kafka deserialization to transform back the bytes into the object using pre-built Deserializer, ObjectMapper and JsonDeserializer.Use ## separator to separate the files \
eg. ##application.properties for properties and ##pom.xml for dependencies.Do not add unneccessary verbose in the response."""
prompt_kinterceptor="""generate code for kafka interceptor to implment functionality to add additional task to producer and consumer.Use ## separator to separate the files \
eg. ##application.properties for properties and ##pom.xml for dependencies.Do not add unneccessary verbose in the response.""" 
prompt_kssl="""generate code for kafka SSL Configuration to configure SSL for Apache Kafka.Use ## separator to separate the files \
eg. ##application.properties for properties and ##pom.xml for dependencies.Do not add unneccessary verbose in the response.""" 
prompt_kfoundation="""generate code for foundation-kafka-lib using latest jdk, SpringBoot and apache kafka.
The kafka-common-lib provides the following functionalities:\n\n1. Kafka Admin:
Implement functionality for creating, deleting and viewing topics within the Kafka ecosystem. \n\n2.
Serialization: Implement functionality to convert the object into bytes using pre-built serializer and ObjectMapper.
\n\n3. Deserialization: Implement functionality to transform back the bytes into the object using pre-built serializer and 
ObjectMapper. \n\n4. Interceptors: implment functionality to add additional task to producer and consumer. 
\n\n4. ssl common configuration: configure SSL for Apache Kafka. Use ## separator to separate the files \
eg. ##application.properties for properties and ##pom.xml for dependencies.Do not add unneccessary verbose in the response.""" 
prompt_kcommonlib="""generate code for foundation-kafka-lib using latest jdk, SpringBoot and apache kafka.The kafka-common-lib provides\ the following functionalities:\n\n1. Kafka Admin:Implement functionality for creating, deleting and viewing topics within the Kafka ecosystem. \n\n2. Serialization: Implement functionality to convert the object into bytes using StringSerializer, ShortSerializer, IntegerSerializer, LongSerializer, DoubleSerializer, BytesSerializer. \n\n3. Deserialization: Implement functionality to transform back the bytes into the objectusing StringSerializer, ShortSerializer, IntegerSerializer, LongSerializer, DoubleSerializer, BytesSerializer. \n\n4. Interceptors: implment functionality to add additional task to producer and consumer. \n\n4. ssl common configuration: configure SSL for Apache Kafka. Use ## separator to separate the files \
eg. ##application.properties for properties and ##pom.xml for dependencies.Do not add unneccessary verbose in the response.""" 
prompt_kproducer="""generate code for Kafka Producer to create a message using MessageBuilder and write messages on the topic using letest version of apache kafka, springboot.Use ## separator to separate the files \
eg. ##application.properties for properties and ##pom.xml for dependencies.Do not add unneccessary verbose in the response.""" 
prompt_kconsumer="""generate code for Kafka Consumer with help of KafkaListener for reading messages from topics and processing them and also implement blocking retry to attempt consuming a message again if the initial attempt fails due to a temporary error using letest version of apache kafka, springboot.Use ## for filenames like ##application.properties for properties and ##pom.xml for dependencies.Do not add unneccessary verbose"""
prompt_kavros="""generate a Java code for an Avro serializer that will be integrated into KafkaProducer. The serializer should produce a message that takes input data and parse in Avro schema and generate avrorecord in the form of key value using avaro GenericRecord. These keys and values should be automatically registered in the Schema Registry. All ProducerConfig values should be put in Java Properties. Finally, KafkaProducer should flush and close. while generating code use the latest version of Apache Kafka and Spring Boot.Use ## for filenames like ##application.properties for properties and ##pom.xml for dependencies.Do not add unneccessary verbose"""
prompt_kavrod="""Generate Java code for an Avro deserializer that will be integrated into KafkaConsumer. The consumer should subscribe array as list of topic and use ConsumerRecords. All ConsumerConfig and avaro deserializer config values should be put in Java Properties. Finally, Consumer should close. while generating code use the latest version of Apache Kafka and Spring Boot. Use ## separator to separate the files \
eg. ##application.properties for properties and ##pom.xml for dependencies.Do not add unneccessary verbose in the response."""
prompt_khealth ="""genrate a java code for health check up of kafka-connect. Implement the logic for the actual health check in the service where It should be getting state and get connector status also implement a boolean method to check whether task is running. while generating code use the latest version of Apache Kafka and Spring Boot.Use ## separator to separate the files \
eg. ##application.properties for properties and ##pom.xml for dependencies.Do not add unneccessary verbose in the response."""

##DocumentDB Prompts

prompt_doc_db1="""Write a code for AWS Document DB configuration which extends AbstractReactiveMongoConfiguration  and properties \
should be configurable. Also generate code for checking whether MongoDB server is up or down by\
using MongoClientOptions builder with exception handling.Use ## separator to separate the files \
eg.##application.properties  for properties, ##pom.xml for dependencies.Do not add unneccessary verbose in the response."""

prompt_doc_db2 = """Write code to create a custom repository by extending ReactiveMongoRepository for all \
CRUD(Create, read, update, delete) operations.Important note : use latest version of JDK, spring Boot and Spring Data MongoDB\
Reactive for generating the code.Use ## separator to separate the files \
eg.##application.properties  for properties, ##pom.xml for dependencies.Do not add unneccessary verbose in the response."""

# Validator Prompt
prompt_validator="""Create a Custom Validator interface for Reactive Spring Boot using JDK 17. This interface will provide \
the basic structure for all future validators. The validator will validate a custom object T. ```java public interface \
Validator<T> { Mono<ValidationResult> validate(T object); } ```. Use ## separator to separate the files \
eg. ##application.properties for properties and ##pom.xml for dependencies.Do not add unneccessary verbose in the response."""

prompt_enricher="""Create a Custom Enricher interface for Reactive Spring Boot using JDK 17. \
This interface will contain all the basic functionalities of Enricher. It is responsible for\
 converting/mapping one model/DTO to another. Use mapStruct for mapping objects.\
Use ## separator to separate the files \
eg.##filenames.Do not add unneccessary verbose and statements in the response."""
prompt_integrator="""Create a Custom Integrator interface for Reactive Spring Boot using JDK 17.This interface \
will contain all the basic functionalities of Integrator.It will accept the input request and will\
transform it into required format for connectors using mapper.Use mapStruct mapper for mapping objects.Do\
not generate pom.xml file.Use ## separator to separate the files \
eg.##filenames.Do not add unneccessary verbose and statements in the response."""
prompt_data_transform="""Generate interface and utility classes to transform data step-by-step or parellel for Reactive Spring Boot\
application using JDK  17. It should support both simple transformation and datapipeline transformation. Simple transformatio\
should support both synchronous and asynchronous data processing.Use ## separator to separate the files \
eg.##filenames.Do not add unneccessary verbose in the response."""
prompt_common_lib1="""Generate a library code with interface and custom class for consistent and structured exception handling of Reactive Spring Boot Application using JDK 17. \
Use ## to mark filenames like ##sampleJava.java for java files. Do not add unneccessary verbose""" 
prompt_common_lib2="""Generate configurable decorator for http request response logging of Reactive Spring Boot Application using JDK 17. Logs should be saved in logging files. These logging files should be generated date wise. Use ## to mark filenames like\
 ##sampleJava.java for java files. Do not add unneccessary verbose"""
prompt_helper="""Generate a Helper class for Reactive Spring Boot Application. Helper class contains Mapstruct mapper for Integrator, Validator and Enricher beans. Integrator: '''First, let's define the `Integrator` interface:\n\n```java\nimport reactor.core.publisher.Mono;\n\npublic interface Integrator<T, R> {\n    Mono<R> integrate(T request);\n}\n```\n\nIn this interface, `T` is the type of input request and `R` is the type of response.\n\nNext, let's define a mapper using MapStruct:\n\n```java\nimport org.mapstruct.Mapper;\n\n@Mapper\npublic interface RequestMapper {\n    ConnectorRequest mapToConnectorRequest(InputRequest inputRequest);\n}\n```\n\nIn this mapper, we are transforming an `InputRequest` into a `ConnectorRequest`.\n\nNow we can implement our integrator:\n\n```java\nimport org.springframework.stereotype.Component;\nimport reactor.core.publisher.Mono;\n\n@Component\npublic class CustomIntegrator implements Integrator<InputRequest, OutputResponse> {\n\n    private final Connector connector;\n    private final RequestMapper requestMapper;\n\n    public CustomIntegrator(Connector connector,\n                            RequestMapper requestMapper) {\n        this.connector = connector;\n        this.requestMapper = requestMapper;\n    }\n\n    @Override\n    public Mono<OutputResponse> integrate(InputRequest inputRequest) {\n        ConnectorRequest connectorReq = requestMapper.mapToConnectorRequest(inputRequest);\n        return connector.connect(connectorReq)\n                .map(this::transformToOutputResponse);\n    }\n\n   // Add your transformation logic here to convert ConnectorResponse to OutputResponse.\n   private OutputResponse transformToOutputResponse(ConnectorResponse response){\n       // Transformation logic goes here.\n       return new OutputResponse();\n   }\n}\n```\n\nIn this implementation, we are injecting a `Connector` and our `requestMapper`. When the integrate method is called with an Input Request (`InputRequst`) it maps it to a Connector Request (`connectorReq`) using our mapper. Then it calls the connect method on our injected connector with that mapped request. The result from that call (a reactive stream of type Mono<ConnectorResponce>) is then transformed into an output response (`OutputResponce`). \n\nPlease replace 'InputRequst', 'OutputResponce', 'connectorReq' and 'connector' with your actual classes or interfaces.''', Validator: '''Your code snippet is almost correct, but it seems like you forgot to import the necessary classes. Here's how you can define a custom Validator interface in Reactive Spring Boot using JDK 17:\n\n```java\nimport reactor.core.publisher.Mono;\n\npublic interface Validator<T> {\n    Mono<ValidationResult> validate(T object);\n}\n```\n\nIn this code:\n\n- `Mono` is a class from Project Reactor that implements the Publisher interface and returns 0 or 1 emissions. It's used for non-blocking operations in reactive programming.\n- `Validator` is an interface with a single method `validate()`. This method takes an object of type T and returns a Mono of ValidationResult.\n- `ValidationResult` would be another custom class that you'd need to create. This class would contain the result of the validation (whether it was successful or not) and any relevant messages.\n\nPlease note that this code assumes that you have already created a ValidationResult class. If not, here's a simple example:\n\n```java\npublic class ValidationResult {\n\n    private boolean valid;\n    private String message;\n\n    // constructors, getters, setters...\n}\n```\n\nThis simple ValidationResult contains only two fields: one for indicating whether the validation was successful (`valid`) and one for storing any relevant messages (`message`). You can customize this class according to your needs.''', Enricher: '''In order to create a custom enricher interface for Reactive Spring Boot using JDK 17, you would need to define an interface that outlines the basic functionalities of an Enricher. Here's a simple example:\n\n```java\nimport org.mapstruct.Mapper;\nimport reactor.core.publisher.Mono;\n\n@Mapper(componentModel = \"spring\")\npublic interface CustomEnricher {\n\n    <T, R> Mono<R> enrich(T source);\n\n}\n```\n\nThis is a very basic example and doesn't do much. It simply defines an `enrich` method that takes in a generic object `T` and returns a reactive `Mono<R>`.\n\nHowever, MapStruct does not support reactive types out of the box. You would need to manually handle the conversion from/to reactive types.\n\nHere's how you could do it:\n\n```java\nimport org.mapstruct.Mapper;\nimport org.mapstruct.MappingTarget;\nimport reactor.core.publisher.Mono;\n\n@Mapper(componentModel = \"spring\")\npublic abstract class CustomEnricher {\n\n    public <T, R> Mono<R> enrich(Mono<T> sourceMono, @MappingTarget R target) {\n        return sourceMono.flatMap(source -> {\n            map(source, target);\n            return Mono.just(target);\n        });\n    }\n\n    protected abstract <T, R> void map(T source, @MappingTarget R target);\n\n}\n```\n\nIn this version of `CustomEnricher`, we're defining two methods: \n\n- The first one is our public API method that clients will use. It takes in a `Mono<T>` (a reactive stream of T) and an instance of the target type to populate.\n- The second one is an abstract method that subclasses will have to implement. This is where the actual mapping logic goes.\n\nPlease note that this code might not work as expected if your mapping logic involves blocking calls or I/O operations because it doesn't respect Reactor's threading model. In such cases you might want to consider using Project Reactor's operators like `.publishOn()`, `.subscribeOn()`, etc., or other non-blocking alternatives for your I/O operations.\n\nAlso note that MapStruct can generate implementations for interfaces annotated with @Mapper but cannot generate implementations for abstract classes so you'll have to provide them yourself.'''. Use ## separator to separate the files \
eg. ##application.properties for properties and ##pom.xml for dependencies.Do not add unneccessary verbose in the response."""

prompt_logmask = """ Write java code in springboot for masking and logging. It should \
have logback and logstash features and put all configurations of logging like encoder \
pattern in logback-sping.xml. It should accept object type and convert object into \
string using ObjectMapper writeValueAsString method. Standard output for select \
fields with timestamp and date. There should be mask features in java using JsonPath \
to find type of sensitive fields(creditcard number, phone number, Id, Password, \
emailid) and use string replace mathod to replace them with masked values. The properties \
for this application should be stored in application.properties file, while dependencies \
are to be placed in pom.xml file. Use ## separator to separate the files \
eg. ##application.properties for properties and ##pom.xml for dependencies.Do not add unneccessary verbose in the response."""

prompt_custom_query = """SELECT "PromptUId", "PromptId", "Name", "Template", "RowStatusUId", "Description", "DemographicUId", "ModelUId" FROM "Prompt" where "Name" in %s AND "DemographicUId"= %s AND "ModelUId"= %s AND "RowStatusUId"='00100000-0000-0000-0000-000000000000';"""
prompt_default_query = """SELECT "PromptUId", "PromptId", "Name", "Template", "WorkFlowUId", "RowStatusUId", "DemographicUId", "ModelUId" FROM "Prompt" where "Name" in %s AND "DemographicUId" IS NULL AND "ModelUId"= %s  AND "RowStatusUId"='00100000-0000-0000-0000-000000000000';"""

# general
question = ['AppCode_General']

# class diagram
class_diagram = ['AppCode_Class_Diagram']

# database
promptTemplate = ['AppCode_DB_SQL_PromptTemplate']
refineTemplate = ['AppCode_DB_RefineTemplate']
python_db_connector = ['AppCode_Python_DB_Connector']
SQL_CreateTemplate = ['AppCode_DB_SQL_CreateTemplate']
SQL_InsertTemplate = ['AppCode_DB_SQL_InsertTemplate']
relevantSchemaTemplate = ['AppCode_DB_RelevantSchemaTemplate']

# codegen langchain
python_api = ['AppCode_Python_MO']
python_react = ['AppCode_Python_MO_React']
dotnet = ['AppCode_Dotnet_MO']
angular  = ['AppCode_Dotnet_MO_Angular']
react_nodejs = ['AppCode_NodeJs_MO_React']
javascript = ['AppCode_NodeJs_MO_Javascript']
java_monolith = ['AppCode_Java_MO_Model','AppCode_Java_MO_Repository','AppCode_Java_MO_Controller']
react_java =['AppCode_Java_MO_React']
angular_java = ['AppCode_Java_MO_Angular']



# microservice
java_microservice_yaml = ['AppCode_Java_MS_Service_YAML_Gen','AppCode_Class_Diagram',  'AppCode_Java_MS_Service_v2','AppCode_Java_MS_React','AppCode_Java_MS_Angular']
java_microservice = ['AppCode_Class_Diagram', 'AppCode_Java_MS_Model', 'AppCode_Java_MS_Repository', 'AppCode_Java_MS_Service', 'AppCode_Java_MS_Controller','AppCode_Java_MS_React', 'AppCode_Java_MS_Angular']
node_microservice = ['AppCode_NodeJs_MS_Model', 'AppCode_NodeJs_MS_Service', 'AppCode_NodeJs_MS_Controller', 'AppCode_NodeJs_MS_EventHandler', 'AppCode_NodeJs_MS_Architecture', 'AppCode_NodeJs_MS_React_AWS']
dotnet_microservice = ['AppCode_Dotnet_MS','AppCode_Dotnet_MS_Angular','AppCode_Class_Diagram']
dotnet_microservice_react = ['AppCode_Dotnet_MS_Models','AppCode_Dotnet_MS_Interfaces','AppCode_Dotnet_MS_Service_Repo','AppCode_Dotnet_MS_Controller','AppCode_Class_Diagram','AppCode_Dotnet_MS_React']

# segmented
segmented_python_api_template = ['AppCode_Segmented_Python_API']
segmented_angular_template =['AppCode_Segmented_Angular']
dotnet_api_segmented = ['AppCode_Segmented_Dotnet_API']
dotnet_api_db_segmented = ['AppCode_Segmented_Dotnet_API_DB']
java_api_segmented_monolith = ['AppCode_Segmented_Java_API_MO_Model', 'AppCode_Segmented_Java_API_MO_Repository', 'AppCode_Segmented_Java_API_MO_Controller']
segmented_react = ['AppCode_Segmented_React']

# vision
figma_angular_gpt4v = ['figma_angular_gpt4v']

#figma react
figma_react_gpt4 = ['figma_react_gpt4']

# codegen component 
codegen_components_template = ['CodeGen_Components_Mapping','CodeGen_Components_Code']

#codegen_frontend
codegen_layered_template = ['Codegen_Angular', 'Codegen_Yaml']

#Figma_frontend
figma_frontend=['figma_frontend']

#greenfield_agent
multiagent_templates = ['Folder_Structure_Gen','DB_Schema_Gen','Planner_Gen','Feature_Summary_Gen','Overall_Summary_Gen','Instructions_Gen','Associated_Files_Gen','Linkage_Gen','Code_Gen_Multiagent']

# Models used
GPT_4_32K = 'gpt-4-32k'
GPT_4O = 'gpt-4o'
GPT_4TURBO = 'gpt-4-turbo'
GPT_4_VISION_PREVIEW = 'gpt-4-vision-preview'
ANTHROPIC_CLAUDE_V2 = 'anthropic.claude-v2:1'
ANTHROPIC_CLAUDE_3_SONNET_V1 = 'anthropic.claude-3-sonnet-20240229-v1:0'
GCP_GEMINI_PRO = 'gemini-pro'
GCP_GEMINI_1DOT5_PRO_001 = 'gemini-1.5-pro-001'
models = [GPT_4_32K, GPT_4O, ANTHROPIC_CLAUDE_V2, ANTHROPIC_CLAUDE_3_SONNET_V1, GCP_GEMINI_PRO, GCP_GEMINI_1DOT5_PRO_001,GPT_4TURBO]
angular_models = [GPT_4_VISION_PREVIEW, GPT_4O,GPT_4TURBO, ANTHROPIC_CLAUDE_3_SONNET_V1, GCP_GEMINI_1DOT5_PRO_001]
react_models = [GPT_4_32K, GPT_4O, GPT_4TURBO, ANTHROPIC_CLAUDE_V2, ANTHROPIC_CLAUDE_3_SONNET_V1, GCP_GEMINI_1DOT5_PRO_001]
xd_models = [GPT_4_VISION_PREVIEW, GPT_4O, GPT_4TURBO, ANTHROPIC_CLAUDE_3_SONNET_V1, GCP_GEMINI_1DOT5_PRO_001]
brownfield_models = [ANTHROPIC_CLAUDE_V2, ANTHROPIC_CLAUDE_3_SONNET_V1]
html_models = [GPT_4_32K, GPT_4O, GPT_4TURBO]
react_native_models = [GPT_4_32K, GPT_4O,GPT_4TURBO]
image_models = [ANTHROPIC_CLAUDE_3_SONNET_V1, GPT_4TURBO, GPT_4_VISION_PREVIEW, GPT_4O, GCP_GEMINI_1DOT5_PRO_001]
from logging.handlers import TimedRotatingFileHandler
import pandas as pd
import os
import jwt
from jwt.algorithms import RSAAlgorithm
import logging
import base64
import requests
import configparser
from jwt.exceptions import (
        InvalidTokenError, DecodeError, InvalidSignatureError,
        ExpiredSignatureError, InvalidAudienceError, InvalidIssuerError,
        InvalidKeyError, ImmatureSignatureError, InvalidAlgorithmError,
        MissingRequiredClaimError, InvalidIssuedAtError)
from requests.exceptions import (RequestException, ConnectionError,
        HTTPError, ConnectTimeout, ReadTimeout, InvalidURL)
import json
from json.decoder import JSONDecodeError
import threading
import time
import re
import cryptography
from cryptography.fernet import InvalidToken
from flask import jsonify
from pymongo import MongoClient
from pymongo.errors import (ConfigurationError, ConnectionFailure,
        ExecutionTimeout, InvalidURI, ServerSelectionTimeoutError,
        InvalidOperation)
# From string to UUID conversion. Used in mongo query
from uuid import UUID
# UUID type, should be explicitly set for correct conversion from db driver
from bson.binary import STANDARD
# Object that faciliate to set UUID's codec
from bson.codec_options import CodecOptions
import os
from datetime import datetime
import sys, traceback
from requests import status_codes ,codes

from ai_core.configs.settings import FORGEROCK

# if this module run as program, then replace .configs with configs
if __name__ == '__main__':
    from configs.settings import (SECRET_KEY, ALGORITHMS, AUDIENCE,
            ISSUER, WORKITEM_URL, REQUIREMENT_URL,MSF_URL, APP_SERVICE_UID,ITERATION_ENTITY_UID,
            DELIVERABLE_ENTITY_UID, MILESTONE_ENTITY_UID,USER_STORY_TYPE_UID,REQUIREMENT_ENTITY_UID,
             BATCH_SIZE, FORTRESS,WINDOWS_AUTH,
            CONNECT_TIMEOUT, READ_TIMEOUT, AUTH_TYPE, ACCESS_TOKEN_URL, AZURE_AD,
            USERNAME, PASSWORD, PHOENIX_RESOURCE_ID, HANDLER, LOG_LEVEL,
            THREAD_BATCH_COUNT, WAIT_TIME, get_configparser_obj,
            get_encryptor_key,WorkItems,Requirements,Milestones,Deliverables,
            Iterations,Risks,Issues,Defects,get_language_api ,MAX_RETRY ,HADOOP_DOMAIN)
else:
    from .configs.settings import (SECRET_KEY, ALGORITHMS, AUDIENCE,
            ISSUER, WORKITEM_URL, REQUIREMENT_URL,MSF_URL, APP_SERVICE_UID,ITERATION_ENTITY_UID,
            DELIVERABLE_ENTITY_UID, MILESTONE_ENTITY_UID,USER_STORY_TYPE_UID,REQUIREMENT_ENTITY_UID,
             BATCH_SIZE, FORTRESS,WINDOWS_AUTH,
            CONNECT_TIMEOUT, READ_TIMEOUT, AUTH_TYPE, ACCESS_TOKEN_URL, AZURE_AD,
            USERNAME, PASSWORD, PHOENIX_RESOURCE_ID, HANDLER, LOG_LEVEL,
            THREAD_BATCH_COUNT, WAIT_TIME, get_configparser_obj,
            get_encryptor_key,WorkItems,Requirements,Milestones,Deliverables,
            Iterations,Risks,Issues,Defects,get_language_api,MAX_RETRY,HADOOP_DOMAIN)

if AUTH_TYPE == WINDOWS_AUTH:
    from requests_negotiate_sspi import HttpNegotiateAuth

if AUTH_TYPE == AZURE_AD:
    if __name__ == '__main__':
        from configs.settings import (CLIENT_ID, TENANT_ID, OPEN_ID_URL,
                GRANT_TYPE, GT_CLIENT_CREDENTIALS, GT_PASSWORD)
    else:
        from .configs.settings import (CLIENT_ID, TENANT_ID, OPEN_ID_URL,
                GRANT_TYPE, GT_CLIENT_CREDENTIALS, GT_PASSWORD)

if AUTH_TYPE == FORGEROCK:
    if __name__ == '__main__':
        from configs.settings import (CLIENT_ID, OPEN_ID_URL, 
                GRANT_TYPE, GT_CLIENT_CREDENTIALS, GT_PASSWORD)
    else:
        from .configs.settings import ( CLIENT_ID, OPEN_ID_URL, 
                GRANT_TYPE, GT_CLIENT_CREDENTIALS, GT_PASSWORD)

# last recent access_token
RECENT_ACCESS_TOKEN:str = ''

# constants required to query
WORKITEMS = "workitems"
REQUIREMENTS = "requirements"
REQUIREMENT_TYPE_UID = "RequirementTypeUId"
REQUIREMENT_EXTERNAL_ID = "RequirementExternalId"
REQUIREMENT_ID = "RequirementId"
REQUIREMENT_ASSOCIATIONS = "RequirementAssociations"
TITLE = "Title"
DESCRIPTION = "Description"
WORKITEM_TYPE_UID = "WorkItemTypeUId"
WORKITEM_EXTERNAL_ID = "WorkItemExternalId"
WORKITEM_ID = "WorkItemId"
WORKITEM_ASSOCIATIONS = "WorkItemAssociations"
WORKITEM_ATTRIBUTES = "WorkItemAttributes"
WORKITEM_ASSOCIATION_UID = "WorkItemAssociationUId"
ASSOCIATION_TYPE_UID = "AssociationTypeUId"
ITEM_EXTERNAL_ID = "ItemExternalId"
DISPLAY_NAME = "DisplayName"
VALUE = "Value"

#added by mei for msp testing
ITERATIONS='Iterations'
ITERATIONS_CHANGELOGS='IterationsChangelogs'
DELIVERABLES='Deliverables'
DELIVERABLES_CHANGELOGS='DeliverablesChangelogs'
MILESTONES='Milestones'
MILESTONES_CHANGELOGS='MilestonesChangelogs'
PHOENIX_ENTITY_COLLECTION_NAME = {MILESTONES: 'clients.milestones',DELIVERABLES:'clients.deliverables',ITERATIONS:'iterations',ITERATIONS_CHANGELOGS:'iterations.changelogs',DELIVERABLES_CHANGELOGS:'clients.deliverables.changelogs',MILESTONES_CHANGELOGS:'clients.milestones.changelogs'}

#Precompute ignore DC scenarion
from .literals import IGNORE_DCS


class CallbackRetryExceededError(Exception):
    """ Exception class for invoke API method raised when RetryCount reached its limit"""
    def __init__(self):
        pass


def retry_invoke(attempt, func, *args, **kwargs):
    """
    Retries invoking 'func' by passing 'args'. If 'attempt' > MAX_RETRY
    throws CallbackRetryExceededError. This retry function is added in order to accomodate invoke_api , 
    There is already a method with same name in this file, but parameters are different 
    TO DO: check with sudhir once
    The caller of this method should've 'retry_attempt' as one of the
    key-value param, to make this work as expected"""
    logger.info(f"Retrying '{func.__name__}()' for {attempt} time")
    if attempt >= MAX_RETRY:
        logger.warning(f"Invoking '{func.__name__}' exceeded max retry "
                       f"attempt: '{attempt}'. Raising 'CallbackRetryExceededError'. ")
        raise CallbackRetryExceededError
    return func(*args, retry_attempt=attempt)
    
def invoke_api(kwargs: dict, http_method: str,retry_attempt=0):
    """
    Invoke API over HTTP(GET, POST). Retry if either Connection/Read timeout or
    any Gatewaytimeout or service_unavailable.
    Return request.Response object & errors, a dict representing errors in details
    if any.
    """
    resp = None
    errors = None
    logger.debug(f"The keyword arguments are {kwargs}")
    logger.debug(f"Invoking {kwargs['url']}")
    try:
        if http_method == 'GET':
            # del kwargs['headers']["UserEmailId"]
            resp = requests.get(**kwargs)
                
        elif http_method == 'POST':
            
            resp=requests.post (**kwargs)  
        # We retry if API timeout or unavailable hoping to get some response
        if resp.status_code in [
            codes.gateway_timeout,  # 504, invoked API is timing out
            codes.request_timeout,  # 408, may be we're not connected to network
            codes.service_unavailable  # 503, may be temporarily unavailable?
        ]:
            resp, errors = retry_invoke(retry_attempt, invoke_api,kwargs, http_method,
                                 retry_attempt=retry_attempt)
        elif resp.status_code != codes.OK:
            errors = dict(
                State="Failed",
                Msg=("Fatal HTTP error has occured. Requires user intervention"
                     " to rectify"),
                Verbose=dict(
                    URL=kwargs['url'],
                    HTTP_CODE=resp.status_code,
                    HTTP_RESP=resp.text
                )
            )
            logger.error(f"HTTP error occured, while calling: kwargs['url']"
                         f". HTTP_CODE: {resp.status_code}, HTTP_RESP: {resp.text}")
    except (requests.exceptions.ConnectTimeout, requests.exceptions.ReadTimeout):
        retry_attempt += 1
        logger.warning(f"Either 'ConnectTimeout' or 'ReadTimeout'  "
                       f"occured, while calling URL: {kwargs['url']}, retrying {retry_attempt} "
                       f"attempt again")
        try:
            resp, errors = retry_invoke(retry_attempt, invoke_api,kwargs,http_method,
                                  retry_attempt=retry_attempt)
        except CallbackRetryExceededError:
            errors = dict(
                State="Failed",
                Msg="Exceeded max retry attempts calling callback url,",
                Verbose=dict(
                    Exception=CallbackRetryExceededError.__name__,
                    Attempts=retry_attempt,
                    URL=kwargs['url'],
                    HTTP_CODE=resp and resp.status_code,
                    HTTP_RESP=resp and resp.text
                ),
            )
            logger.error(f"Attempted {retry_attempt} times to call url: "
                         f"{kwargs['url']} & failed. Last attempt error: "
                         f"HTTP_CODE: {resp and resp.status_code}, HTTP_RESPONSE: {resp and resp.text}")
    return resp, errors


class AppFilter(logging.Filter):
    def __init__(self, app,clientUId, deliveryConstructUId, assemblyNamespace="", correlationUId=""):
        self.app=app
        self.clientUId = clientUId
        self.deliveryConstructUId=deliveryConstructUId
        self.assemblyNamespace=assemblyNamespace
        self.correlationUId=correlationUId
        
    def filter(self, record):
        record.app_name = self.app
        record.ClientUId = self.clientUId
        record.DeliveryConstructUId = self.deliveryConstructUId
        record.AssemblyNamespace = self.assemblyNamespace
        record.CorrelationUId = self.correlationUId
        
        message = record.getMessage().replace("\n", "\\n")
        excep, value, trace = sys.exc_info()
        record.info = message
        
        if excep is None:
            record.title = ""
            # record.info = message
            record.Exception = ""
        else:
            record.title = excep.__name__
            # record.info = message
            tb = traceback.format_exc().replace("\n", "\\n")
            record.Exception = tb
        
        return True

def get_logger(app,Cleintid='', Dcid='',name: str =__name__, config_fpath: str = None,filename: str =None):
    """
    create a logger object either reading logging configuration from
    a file or create logger which logs to console."""

    if config_fpath:
        logger.debug(f"configuration file supplied to initialize "
            f"logger object: '{config_fpath}")
        config = get_configparser_obj(config_fpath)
        log_dir = config.get('app_log', 'log_dir')
        try:
            if not os.path.isdir(log_dir):
                logger.warning(f"\tNo '{log_dir}' present, creating one")
                os.mkdir(log_dir)

            logger.debug(f"{log_dir} (now) present")
        except Exception as e:
            logger.error(f"Some error while checking/creating '{log_dir}'")
            logger.warning(f"Assuming PWD as log dir: {os.getcwd()}")
            log_dir = os.getcwd()
            log_dir = os.path.join(log_dir, "Logs")
            if not os.path.isdir(log_dir):
                logger.warning(f"\tNo '{log_dir}' present, creating one")
                os.mkdir(log_dir)

        #logfile = os.path.join(log_dir, config.get('app_log', 'filename'))
        if not filename:
            filename=config.get('app_log', 'filename')
          
        logfile = os.path.join(log_dir,filename)
        logger.info(f"Initializing logger obj, log file is '{logfile}'")
        log_format = config.get('app_log', 'format')
        max_bytes = int(config.get('app_log', 'max_log_bytes'))
        backups = int(config.get('app_log', 'backups'))
        _when = str(config.get('app_log', 'rollover_time'))
        # "log_level" will hold value of type String from R4.0, 
        # this is OCD requirement to support "MyWizardLogLevel" placeholder
        log_level = config.get('app_log', 'log_level')
        log_level = log_level.upper()
        if log_level == 'ALL' or log_level == 'DEBUG':
            log_level = logging.DEBUG
        elif log_level == 'INFO':
            log_level = logging.INFO
        elif log_level == 'WARN':
            log_level = logging.WARN
        elif log_level == 'ERROR':
            log_level = logging.ERROR
        elif log_level == 'FATAL':
            log_level = logging.FATAL
        else:
            msg = "Configuration attr 'log_level' is not to one of these: \
                'ALL', 'DEBUG', 'INFO', 'WARN', 'ERROR' or 'FATAL'. This is a required \
                value. This value is supplied from 'MyWizardLogLevel' placeholder in the configuration."
            logger.error(msg)
            raise ValueError(msg)
        
        nlogger = logging.getLogger(name)
        # this is to check if multple handlers are not attached to the logger object.
        #if not nlogger.hasHandlers():
        handler = TimedRotatingFileHandler(logfile, when=_when, backupCount=backups)
        formatter = logging.Formatter(log_format)
        handler.setFormatter(formatter)
        nlogger.addHandler(handler)
    else:
        log_format = '{"LogType":"%(levelname)s","DateTime":"%(asctime)s","AppService":"%(app_name)s","Message": "%(info)s" ,"Component":"%(filename)s","SubComponent":"%(funcName)s","Title":"%(title)s","ClientUId":"%(ClientUId)s", "DeliveryConstructUId":"%(DeliveryConstructUId)s","AssemblyNamespace":"%(pathname)s","CorrelationUId":"%(CorrelationUId)s","Exception":"%(Exception)s"}'
        log_level = 'DEBUG'
        
        nlogger = logging.getLogger(name)
        if len(nlogger.handlers) == 0:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(log_format)
            handler.setFormatter(formatter)
            nlogger.addHandler(handler)

    nlogger.setLevel(log_level)
    nlogger.addFilter(AppFilter(app,Cleintid, Dcid))

    return nlogger

# Initialize default logger for this module
app='AI Core Commons'
logger = get_logger(app)

__version__ = ".NetCoreMigration"

def timeit(func):
    def wrapper(*args, **kwargs):
        st = time.perf_counter()
        out = func(*args, **kwargs)
        et = time.perf_counter()
        logger.info("Time taken by '%s' is %f" %(func.__name__, et-st))
        return out
    wrapper.__name__ = func.__name__
    return wrapper

def get_conn_str_elements(connection_string):
    """
    utility method to grab various elements of database connection string.
    Throws AttributeError when no match found

    param: connection string
    return: tuple of length 6, of the following order,
    (username, password, hostname, port, databasename, ssl)
    """
    logger.debug(connection_string)
    pattern = re.compile("""
    \w+://
    ([\w\W\d\D]+):          # username
    ([\w\W\d\D]+)?          # password
    @([\w\d\-\%\W\D]+):     # hostname
    (\d{5})                 # port
    \/([\w\-\d\W\D]+)\?     # databasename
    [\d\D\w\W]*ssl=(\w+)    # ssl flag
    """, re.VERBOSE)
    match = pattern.match(connection_string)
    try:
        if match:
            mt = match.groups()
            if len(mt) == 5:
                # if 'ssl' flag is missing from the connection string set it explicitly
                logger.warn("no 'ssl' param found in connection string, explicityly setting to 'false'")
                mt += ('false',)
        else:
            # connection string might not have user:password prepended to 
            # hostname, mostly incase of 'localhost' scenario
            pattern = re.compile("""
            \w+://
            ([\w\d\-\%\W\D]+):      # hostname
            (\d{5})                 # port
            \/([\w\-\d\W\D]+)\?     # databasename
            [\d\D\w\W]*ssl=(\w+)    # ssl flag
            """, re.VERBOSE)
            match = pattern.match(connection_string)
            mt = match.groups()
            if len(mt) == 3:
                # if 'ssl' flag is missing from the connection string set it explicitly
                logger.warn("no 'ssl' param found in connection string, explicityly setting to 'false'")
                mt += ('false',)
            # add username, password fields to return value
            mt = (None, None) + mt

        # the order of the tuple
        #(username, password, hostname, port, databasename, ssl)
        logger.debug(mt)
    except AttributeError as e:
        m = """Not all fields are available in 'connection string'. Expected
        connection string format is:
        [<username>:<password>]@<host>:<port>/<dbname>?<ssl=[true|false].
        Set correct connection string to get away with this exception
        contents within [] are optional
        contents within <> are *required*"""
        logger.critical(m)
        raise AttributeError(m)

    return mt
def get_conn_str_elements_old(connection_string):
    """
    utility method to grab various elements of database connection string.
    Throws AttributeError when no match found

    param: connection string
    return: tuple of length 6, of the following order,
    (username, password, hostname, port, databasename, ssl)
    """
    logger.debug(connection_string)
    pattern = re.compile("""
    \w+://
    ([\w\W\d\D]+):          # username
    ([\w\W\d\D]+)?          # password
    @([\w\d\-\%\W\D]+):     # hostname
    (\d{5})                 # port
    \/([\w\-\d\W\D]+)\?     # databasename
    [\d\D\w\W]*ssl=(\w+)    # ssl flag
    """, re.VERBOSE)
    match = pattern.match(connection_string)
    try:
        mt = match.groups()
        logger.debug(len(mt))
        if len(mt) == 5:
            # if 'ssl' flag is missing from the connection string set it explicitly
            logger.warn("no 'ssl' param found in connection string, explicityly setting to 'false'")
            mt += ('false',)

        # the order of the tuple
        #(username, password, hostname, port, databasename, ssl)
        logger.debug(mt)
    except AttributeError as e:
        m = """Not all fields are available in 'connection string'. Expected
        connection string format is:
        <username>:<password>@<host>:<port>/<dbname>?<ssl=[true|false].
        Set correct connection string to get away with this exception"""
        logger.critical(m)
        raise AttributeError(m)

    return mt

def set_logger(l):
    """
    Set logging object of the consumer of this module. Idea is to send
    log messages included in this module to consumer's logging handler if they
    need

    param: l, logging object
    returns None
    """
    global logger
    if l is not None and isinstance(l, logging.Logger):
        logger.debug("setting logger of consumer")
        logger = l
    else:
        logger.warning("You either setting 'None' or object is"
                " not an instance of 'logging'")

def get_db_configuration(config_fpath: str):
    from ai_core.configs.file_encryptor import get_configparser_obj
    config = get_configparser_obj(config_fpath)

    dburl = config.get('mongodb.details', 'connectionString')
    dburl = dburl.replace('amp;','')
    certfile = config.get('mongodb.details', 'certificatePath')
    ca_certs= config.get('mongodb.details', 'certificateCAPath')
    return dburl, certfile, ca_certs

def get_db_connection(dbclient, dburl: str, certfile: str, ca_certs: str):
    from ai_core.commons import get_conn_str_elements
    (username, password, hostname, \
            port, databasename, ssl_flag) = get_conn_str_elements(dburl)
    if ssl_flag.lower() == "true":
        client = dbclient(
            dburl,
            ssl = True,
            ssl_certfile = certfile,
            ssl_ca_certs = ca_certs,
            connect=False)
    elif ssl_flag.lower() == "false":
        client = dbclient(dburl, connect=False)
    else:
        raise Exception("SSL flag in DB conn string is incorrectly set")
    return client.get_database()

def decode_base64_padding(data, altchars=b'+/'):
    """Decode base64, padding being optional.

    :param data: Base64 data as an ASCII byte string
    :returns: The decoded byte string.

    """
    data = re.sub(rb'[^a-zA-Z0-9%s]+' % altchars, b'', data)  # normalize
    missing_padding = len(data) % 4
    if missing_padding:
        data += b'='* (4 - missing_padding)
    return base64.b64decode(data, altchars)

def _get_kid_(token):
    """
    'kid' Specifies the thumbprint for the public key that's used to
    sign this token. 'kid' is encoded in header section of the token"""
    # 3 parts of standard JWT
    (header, payload, signature) = token.split(".")
    # d_header is byte-string
    if AUTH_TYPE == FORGEROCK:
        d_header = decode_base64_padding(header.encode('ascii'))
    else :
        d_header = base64.standard_b64decode( header )  
    str_header = str(d_header, 'utf-8')
    json_header = json.loads(str_header)
    return json_header["kid"]

def _get_jwks_uri_():
    """
    URL for publicly available keys
    """
    resp = requests.request(url=OPEN_ID_URL, method="GET").json()
    jwks_uri = resp["jwks_uri"]
    return jwks_uri

def validate_auth_token(token):
    """
    refer documentation from https://docs.microsoft.com/en-us/azure/active-directory/develop/access-tokens#validating-tokens
    step 1: get thumbprint(kid value)
    step 2: get URL for public signing key from a standard URL with CLIENT_ID
    step 3: get public signing from step 2 url
    step 4: find entry which matches kid in the output
    step 5: form public key from various fields
    step 6: decode token using public token
    """
    (kid, jwks_uri) = _get_kid_(token), _get_jwks_uri_()
    # get azure issued public signing keys for the client
    public_sign_keys = requests.request(url=jwks_uri, method="GET").json()
    sign_key = None
    key_json=None
    for key in public_sign_keys["keys"]:
        if kid == key["kid"]:
            key_json = '''{ \
                "kty":"%s", \
                "alg":"RS256", \
                "use":"%s", \
                "kid":"%s", \
                "n":"%s", \
                "e":"%s" \
                }''' %(key['kty'], key['use'], key['kid'], key['n'], key['e'])

    logger.debug(key_json)
    public_key = RSAAlgorithm.from_jwk(key_json)
    decoded_token = jwt.decode(token, public_key, algorithms='RS256',audience=AUDIENCE, issuer=ISSUER)
    return decoded_token


def validate_azure_ad_token(token):
    """
    refer documentation from https://docs.microsoft.com/en-us/azure/active-directory/develop/access-tokens#validating-tokens
    step 1: get thumbprint(kid value)
    step 2: get URL for public signing key from a standard URL with CLIENT_ID
    step 3: get public signing from step 2 url
    step 4: find entry which matches kid in the output
    step 5: form public key from various fields
    step 6: decode token using public token
    """
    decoded_token = validate_auth_token(token)
    return decoded_token

def validate_forgerock_token(token):
   decoded_token = validate_auth_token(token)
   return decoded_token

def decode_token(token):
    """
    Decrypts JWT Token using secret_key and validate authenticity
    using audience, issuer. All three are read from ai_core_config.ini
    file, which is deployment specific. secret_key is aslo a 'base64'
    encoded string.

    param: token, a mywizard-phoenix issued token
    returns: decoded json from token

    this method doesn't supress any exceptions that jwt.decode() throws,
    becuase consumer can handle the way they want. for list all exceptions,
    read documentation at: https://pyjwt.readthedocs.io/en/latest/api.html
    """
    if AUTH_TYPE == AZURE_AD:
        decoded_jwt = validate_azure_ad_token(token)
    elif AUTH_TYPE == FORTRESS:
        decoded_jwt = jwt.decode(
            token,
            base64.standard_b64decode( SECRET_KEY ),
            algorithms=ALGORITHMS,
            verify=True,
            audience=AUDIENCE,
            issuer=ISSUER,
            )
    elif AUTH_TYPE == FORGEROCK:
        decoded_jwt = validate_forgerock_token(token)
   
    elif AUTH_TYPE == WINDOWS_AUTH:
        decoded_jwt = True
    return decoded_jwt

@timeit
def get_workitem(token, validate_token=True,
        timeout=(CONNECT_TIMEOUT, READ_TIMEOUT), fetch_via="db", **kwargs):
    if fetch_via.lower() == "api":
        return get_workitem_via_api(token, validate_token, timeout, **kwargs)

    db = _get_database_()
    col = db.get_collection(
            "clients.workitems", CodecOptions(uuid_representation=STANDARD))
    logger.debug("got collection object")
    #cursor = col.find(
    #        _get_where_clause_(WORKITEMS, kwargs),
    #        _get_select_fields_(WORKITEMS))

    pipe =[
        {"$match": _get_where_clause_(WORKITEMS, kwargs)},
        {"$lookup":_get_lookup_(WORKITEMS)},
        {"$project":_get_select_fields_(WORKITEMS)}
        ]
    cursor = col.aggregate(pipeline=pipe)
    out = {"WorkItems": []}
    logger.debug("Queried, got cursor obj, looping...")
    trouble_records = []
    for c in cursor:
        w = {
            "WorkItemTypeUId": str(c["WorkItemTypeUId"]) if "WorkItemTypeUId" in c else "",
            "WorkItemExternalId": c["WorkItemExternalId"] if "WorkItemExternalId" in c else "",
            "WorkItemUId": str(c["WorkItemUId"]) if "WorkItemUId" in c else "",
            "WorkItemId": c["WorkItemId"] if "WorkItemId" in c else "",
            "WorkItemAssociations": c["WorkItemAssociations"] if "WorkItemAssociations" in c else [],
            # requires conversion from uuid to str conversion
            "WorkItemAttributes": c["WorkItemAttributes"] if "WorkItemAttributes" in c else [],
            }

        # Have flat attributes from WA
        for i, da in enumerate(w["WorkItemAttributes"]):
            attrs = ['StateUId', 'State', 'Title', 'Description',
                    'AcceptanceCriteria', 'EffortEstimated', 'EffortCompleted',"TypeUId"]
            try:
                if da['Name'] in attrs:
                    if 'UId' in da['Name']:
                        w[da['Name']] = str( da['IdValue'] ) if 'IdValue' in da and da['IdValue'] else ""
                    else:
                        w[da['Name']] = da['Value'] if 'Value' in da and da['Value'] else ""
            except KeyError as e:
                trouble_records.append(w)

        if len(trouble_records) > 0:
            msg = "Required 'Name' within 'WorkItemAttributes' is missing for \
                these records: %s" %trouble_records
            logger.error(msg)
            raise KeyError(msg)

        # Convert any UUID value to string
        for e in w["WorkItemAssociations"]:
            e["WorkItemAssociationUId"] = str(e["WorkItemAssociationUId"]) if "WorkItemAssociationUId" in e else ""
            e["AssociationTypeUId"] = str(e["AssociationTypeUId"]) if "AssociationTypeUId" in e else ""
            e["WorkItemTypeUId"] = str(e["WorkItemTypeUId"]) if "WorkItemTypeUId" in e else ""

        out['WorkItems'].append(w)
    logger.debug("No. of records fetched: %d" %len(out["WorkItems"]))
    return out

@timeit
def get_workitem_new(token, validate_token=True,
        timeout=(CONNECT_TIMEOUT, READ_TIMEOUT), fetch_via="db", **kwargs):
    if fetch_via.lower() == "api":
        return get_workitem_via_api_new(token, validate_token, timeout, **kwargs)

    db = _get_database_()
    col = db.get_collection(
            "clients.workitems", CodecOptions(uuid_representation=STANDARD))
    logger.debug("got collection object")
    cursor = col.find(
            _get_where_clause_(WORKITEMS, kwargs),
            _get_select_fields_(WORKITEMS))
    out = {"WorkItems": []}
    logger.debug("Queried, got cursor obj, looping...")
    trouble_records = []
    workitem_list=[]
    for c in cursor:
        w = {
            "WorkItemTypeUId": str(c["WorkItemTypeUId"]) if "WorkItemTypeUId" in c else "",
            "WorkItemExternalId": c["WorkItemExternalId"] if "WorkItemExternalId" in c else "",
            "WorkItemUId": str(c["WorkItemUId"]) if "WorkItemUId" in c else "",
            "WorkItemId": c["WorkItemId"] if "WorkItemId" in c else "",
            "WorkItemAssociations": c["WorkItemAssociations"] if "WorkItemAssociations" in c else [],
            # requires conversion from uuid to str conversion
            "WorkItemAttributes": c["WorkItemAttributes"] if "WorkItemAttributes" in c else [],
            }

        # Have flat attributes from WA
        for i, da in enumerate(w["WorkItemAttributes"]):
            attrs = ['StateUId', 'State', 'Title', 'Description',
                    'AcceptanceCriteria', 'EffortEstimated', 'EffortCompleted']
            try:
                if da['Name'] in attrs:
                    if 'UId' in da['Name']:
                        w[da['Name']] = str( da['IdValue'] ) if 'IdValue' in da and da['IdValue'] else ""
                    else:
                        w[da['Name']] = da['Value'] if 'Value' in da and da['Value'] else ""
            except KeyError as e:
                trouble_records.append(w)

        if len(trouble_records) > 0:
            msg = "Required 'Name' within 'WorkItemAttributes' is missing for \
                these records: %s" %trouble_records
            logger.error(msg)
            raise KeyError(msg)

        # Convert any UUID value to string
        for e in w["WorkItemAssociations"]:
            e["WorkItemAssociationUId"] = str(e["WorkItemAssociationUId"]) if "WorkItemAssociationUId" in e else ""
            e["AssociationTypeUId"] = str(e["AssociationTypeUId"]) if "AssociationTypeUId" in e else ""
            e["WorkItemTypeUId"] = str(e["WorkItemTypeUId"]) if "WorkItemTypeUId" in e else ""

        #out['WorkItems'].append(w)
        workitem_list.append(w)
    logger.debug("total workitems fetched %d" %len(workitem_list))
    workitem_list_final=dc_validator(workitem_list)
    logger.debug("total workitems fetched post Muti DC validation %d" %len(workitem_list_final))
    out['WorkItems']=workitem_list_final
    logger.debug("No. of records fetched: %d" %len(out["WorkItems"]))
    return out

def convet_columns_data_type(entity_key,out_data):
    if entity_key ==  ITERATIONS or entity_key ==  ITERATIONS_CHANGELOGS:
        df_phoenix_data = pd.DataFrame(out_data[entity_key])
        if not df_phoenix_data.empty:
            requ_cols = list(set(['EndOn', 'IterationExternalId', 'IterationUId', 'Name', 'StartOn', '_id']) - set(df_phoenix_data.columns.tolist()))
            if requ_cols:
                df_phoenix_data[requ_cols]=""
            dc_asso = df_phoenix_data[df_phoenix_data['IterationAssociations'].notnull()]
            dc_asso = dc_asso[dc_asso.astype(str)['IterationAssociations'] != '[]']
            dc_asso['IterationAssociations'] = dc_asso['IterationAssociations'].apply(lambda x : list(map(lambda y: {'EntityUId':str(y['EntityUId'] if 'EntityUId' in y else ""),'ItemExternalId':str(y['ItemExternalId'] if 'ItemExternalId' in y else ""),'ItemAssociatedUId':str(y['ItemAssociatedUId'] if 'ItemAssociatedUId' in y else "")},x)))
            dc_asso_null_data = df_phoenix_data[~(df_phoenix_data['IterationAssociations'].notnull()) | (df_phoenix_data.astype(str)['IterationAssociations'] == '[]')]
            concat_df = pd.concat([dc_asso_null_data,dc_asso])

            concat_df[['EndOn', 'IterationExternalId', 'IterationUId', 'Name', 'StartOn', '_id']] =concat_df[['EndOn', 'IterationExternalId', 'IterationUId', 'Name', 'StartOn', '_id']].astype(str)
            records = concat_df.to_dict(orient='records')
        else:
            records=[]

    elif entity_key == DELIVERABLES or entity_key == DELIVERABLES_CHANGELOGS:
        df_phoenix_data = pd.DataFrame(out_data[entity_key])
        if not df_phoenix_data.empty:
            requ_cols = list(set(['ActualEndOn', 'ActualStartOn', 'CommittedEndOn', 'CommittedStartOn',  'DeliverableExternalId', 'DeliverableUId', 'EffortCompleted', 'EffortEstimated', 'EffortRemaining', 'EffortVariance', 'ForecastEndOn', 'ForecastStartOn', 'PercentDurationCompleted', 'PercentEffortCompleted', 'PhysicalPercentCompleted', 'PriorityUId', 'StateUId', 'Title', 'TotalEffort', '_id']) - set(df_phoenix_data.columns.tolist()))
            if requ_cols:
                df_phoenix_data[requ_cols]=""
            dc_asso = df_phoenix_data[df_phoenix_data['DeliverableAssociations'].notnull()]
            dc_asso = dc_asso[dc_asso.astype(str)['DeliverableAssociations'] != '[]']
            dc_asso['DeliverableAssociations'] = dc_asso['DeliverableAssociations'].apply(lambda x : list(map(lambda y: {'EntityUId':str(y['EntityUId'] if 'EntityUId' in y else ""),'ItemExternalId':str(y['ItemExternalId'] if 'ItemExternalId' in y else ""),'ItemAssociatedUId':str(y['ItemAssociatedUId'] if 'ItemAssociatedUId' in y else "")},x)))

            dc_asso_null_data = df_phoenix_data[~(df_phoenix_data['DeliverableAssociations'].notnull()) | (df_phoenix_data.astype(str)['DeliverableAssociations'] == '[]')]
            concat_df = pd.concat([dc_asso_null_data,dc_asso])

            concat_df[['ActualEndOn', 'ActualStartOn', 'CommittedEndOn', 'CommittedStartOn',  'DeliverableExternalId', 'DeliverableUId', 'EffortCompleted', 'EffortEstimated', 'EffortRemaining', 'EffortVariance', 'ForecastEndOn', 'ForecastStartOn', 'PercentDurationCompleted', 'PercentEffortCompleted', 'PhysicalPercentCompleted', 'PriorityUId', 'StateUId', 'Title', 'TotalEffort', '_id']] =concat_df[['ActualEndOn', 'ActualStartOn', 'CommittedEndOn', 'CommittedStartOn',  'DeliverableExternalId', 'DeliverableUId', 'EffortCompleted', 'EffortEstimated', 'EffortRemaining', 'EffortVariance', 'ForecastEndOn', 'ForecastStartOn', 'PercentDurationCompleted', 'PercentEffortCompleted', 'PhysicalPercentCompleted', 'PriorityUId', 'StateUId', 'Title', 'TotalEffort', '_id']].astype(str)

            records = concat_df.to_dict(orient='records')
        else:
            records=[]

    elif entity_key ==MILESTONES or entity_key ==MILESTONES_CHANGELOGS:
        df_phoenix_data = pd.DataFrame(out_data[entity_key])
        if not df_phoenix_data.empty:
            requ_cols = list(set(['ActualEndOn', 'CommittedEndOn', 'EffortEstimated', 'ForecastEndOn', 'MilestoneExternalId', 'MilestoneUId', 'StateUId', 'Title','_id']) - set(df_phoenix_data.columns.tolist()))
            if requ_cols:
                df_phoenix_data[requ_cols]=""
            dc_asso = df_phoenix_data[df_phoenix_data['MilestoneAssociations'].notnull()]
            dc_asso = dc_asso[dc_asso.astype(str)['MilestoneAssociations'] != '[]']
            dc_asso['MilestoneAssociations'] = dc_asso['MilestoneAssociations'].apply(lambda x : list(map(lambda y: {'EntityUId':str(y['EntityUId'] if 'EntityUId' in y else ""),'ItemExternalId':str(y['ItemExternalId'] if 'ItemExternalId' in y else ""),'ItemAssociatedUId':str(y['ItemAssociatedUId'] if 'ItemAssociatedUId' in y else "")},x)))
            dc_asso_null_data = df_phoenix_data[~(df_phoenix_data['MilestoneAssociations'].notnull()) | (df_phoenix_data.astype(str)['MilestoneAssociations'] == '[]')]
            concat_df = pd.concat([dc_asso_null_data,dc_asso])
            concat_df[['ActualEndOn', 'CommittedEndOn', 'EffortEstimated', 'ForecastEndOn', 'MilestoneExternalId', 'MilestoneUId', 'StateUId', 'Title','_id']] =concat_df[['ActualEndOn', 'CommittedEndOn', 'EffortEstimated', 'ForecastEndOn', 'MilestoneExternalId', 'MilestoneUId', 'StateUId', 'Title','_id']].astype(str)

            records = concat_df.to_dict(orient='records')
        else:
            records=[]
    out_data[entity_key] = records
    return out_data

@timeit
def get_phoenix_entity_data_(phoenix_colleciton, endpoint, token, validate_token=True,
                            timeout=(CONNECT_TIMEOUT, READ_TIMEOUT), fetch_via="db", pipe=[], **kwargs):
    if fetch_via.lower() == "api":
        return get_phoenix_entity_data_via_api(endpoint, token, validate_token, timeout, **kwargs)

    db = _get_database_()
    # mv = MongoClient("mongodb://dbOwner:password@localhost:27017/RTA?authSource=RTA;ssl=false")
    # db = mv.get_database()
    col = db.get_collection(phoenix_colleciton, CodecOptions(uuid_representation=STANDARD))
    logger.debug("No. of records fetched: %s" % phoenix_colleciton)
    logger.debug("got collection object")
    cursor = col.aggregate(pipeline=pipe)
    out = {endpoint: [*cursor]}
    #    out = convet_columns_data_type(endpoint,out)
    # logger.debug("No. of records fetched: %s" % out)
    logger.debug("No. of records fetched: %d" % len(out[endpoint]))
    return out

@timeit
def get_phoenix_entity_data(entity_key,token, validate_token=True,
        timeout=(CONNECT_TIMEOUT, READ_TIMEOUT), fetch_via="db", **kwargs):

    if fetch_via.lower() == "api":
        return get_phoenix_entity_data_via_api(entity_key,token, validate_token,timeout,**kwargs)

    db = _get_database_()
    col = db.get_collection(PHOENIX_ENTITY_COLLECTION_NAME[entity_key], CodecOptions(uuid_representation=STANDARD))

    logger.debug("got collection object")
#    cursor = col.find(_get_where_clause_(entity_key, kwargs),
#            _get_select_fields_(entity_key))

    pipe =[
        {"$match": _get_where_clause_(entity_key, kwargs)},
        {"$lookup":_get_lookup_(entity_key)},
        {"$project":_get_select_fields_(entity_key)}
        ]
    cursor = col.aggregate(pipeline=pipe)
    out = {entity_key: [*cursor]}
    out = convet_columns_data_type(entity_key,out)
    logger.debug("No. of records fetched: %d" %len(out[entity_key]))
    return out

lang_dict = {}
@timeit
def get_language(token, validate_token=True,timeout=(CONNECT_TIMEOUT, READ_TIMEOUT), **kwargs):
    global lang_dict
    clientUId = kwargs['ClientUId']
    deliveryConstructUId = kwargs["DeliveryConstructUId"]
    resp = {}
    key2 = str(clientUId+deliveryConstructUId)
    if key2 in lang_dict:
        resp1 = lang_dict[key2]
        resp['language'] = resp1[0]
        resp['lang_Code'] = resp1[1]
        status_code = 200
        logger.info("get language from cache")
    else:
        if validate_token:
            logger.debug("decoding access token")
            decoded_token = decode_token(token)
        else:
            logger.warning("Not opting to decode_token().")
        resp={}
        r_kwargs = _get_request_api_kwargs_(get_language_api, timeout, kwargs)
        try:
           resp = requests.post(**r_kwargs)
           key1 = str(clientUId)+str(deliveryConstructUId)
           if resp.status_code == 200 and json.loads(resp.text)['is_default'] !="yes":
           ##to do 
           ## if it is  default dont store 
               
               lang_dict[key1]=(json.loads(resp.text)['language'],json.loads(resp.text)['lang_Code'])
           status_code = resp.status_code
           logger.info("get language from url")
        except requests.exceptions.RequestException as e:
            logger.error("get language request failed : "+str(e))
            return 500,e
        except  Exception as e:
            logger.error("get language request failed : "+str(e))
            return 500,e

        if resp.status_code !=200:
            logger.error("get language request failed : "+str(resp))
            resp = {}
        else:
            resp = resp.json()
    return status_code,resp

@timeit
def get_workitem_via_api(token, validate_token=True,
        timeout=(CONNECT_TIMEOUT, READ_TIMEOUT), **kwargs):
    """
    This method is just a facilitator for invoking Phoenix's workitem
    datafabric API. The invoker is supposed to handle all exceptions that
    "requests.exceptions" defines. For all exceptions refer here
    http://docs.python-requests.org/en/master/_modules/requests/exceptions/

    URL's are read from configuration, which
    can be configured for diff environments.

    this method throws any HTTP error codes as HTTPError exception if the
    response from Phoenix's API not 200.

    params:
    token: a token from Phoenix's world. Same is used to invoke datafabric
            API,
    validate_token: Default is 'False'. Set it to true if caller wants this
            method to authenticate before invoking Phoenix's workitem
    timeout: a tuple values, corresponds to 'requests' module's timeout option
            first value of the tuple is ConnectTimeout value, defaults to 5
            second value of the tuple is ReadTimeout, defaults to 40
            Both timeout values are configureable. Refer 'ai_core_configs.ini'
    **kwargs: key 'criteria' is dictionary contains all values that caller wants
            to send as body.raw field of request. Rest all key-value pairs
            are set as query parameters.

    returns: JSON, of Phoenix's API return value.
    """
    st = time.perf_counter()
    if validate_token:
        logger.debug("decoding access token")
        decoded_token = decode_token(token)
    else:
        logger.warning("Not opting to decode_token().")
    logger.info("access token is valid")

    out = {"msg": {"status": "success"}}
    requested_batch_size = None
    # 'json_key' is name of entity key in JSON output
    json_key = "WorkItems"
    r_kwargs = _get_request_api_kwargs_(WORKITEM_URL, timeout, kwargs)
    resp = requests.post(**r_kwargs)
    (workitems, total_rec_count, total_page_count, current_page,
            batch_size) = _get_api_response_keyvalues_(resp, json_key)
    if total_rec_count == 0:
        logger.info("TotalRecordCount: %d,Time taken: %f"
                %(total_rec_count, time.perf_counter() - st))
        out["WorkItems"] = workitems
        return out

    logger.info("Total rec count: %d, number of POST call require: %d"
            %(total_rec_count, total_page_count))
    # 'json_key' would be deleted once referenced
    r_kwargs['json_key'] = json_key
    _init_start_threads_(total_page_count, current_page,  r_kwargs, workitems)
    if total_rec_count != len(workitems):
        logger.critical("Only %d/%d records fetched. Check log for why" %(
            len(workitems), total_rec_count))
        out["msg"]["state"] = "failed"
        out["msg"]["desc"] = (
            "Only %d/%d records fetched. Reason may be "
            "CONNECT/READ timeout or SSLError exception."
            %(len(workitems), total_rec_count))
    else:
        logger.debug("total workitems fetched %d" %len(workitems))
    resp.raise_for_status()
    out["WorkItems"] = workitems
    return out

@timeit
def get_workitem_via_api_new(token, validate_token=True,
        timeout=(CONNECT_TIMEOUT, READ_TIMEOUT), **kwargs):
    """
    This method is just a facilitator for invoking Phoenix's workitem
    datafabric API. The invoker is supposed to handle all exceptions that
    "requests.exceptions" defines. For all exceptions refer here
    http://docs.python-requests.org/en/master/_modules/requests/exceptions/

    URL's are read from configuration, which
    can be configured for diff environments.

    this method throws any HTTP error codes as HTTPError exception if the
    response from Phoenix's API not 200.

    params:
    token: a token from Phoenix's world. Same is used to invoke datafabric
            API,
    validate_token: Default is 'False'. Set it to true if caller wants this
            method to authenticate before invoking Phoenix's workitem
    timeout: a tuple values, corresponds to 'requests' module's timeout option
            first value of the tuple is ConnectTimeout value, defaults to 5
            second value of the tuple is ReadTimeout, defaults to 40
            Both timeout values are configureable. Refer 'ai_core_configs.ini'
    **kwargs: key 'criteria' is dictionary contains all values that caller wants
            to send as body.raw field of request. Rest all key-value pairs
            are set as query parameters.

    returns: JSON, of Phoenix's API return value.
    """
    st = time.perf_counter()
    if validate_token:
        logger.debug("decoding access token")
        decoded_token = decode_token(token)
    else:
        logger.warning("Not opting to decode_token().")
    logger.info("access token is valid")

    out = {"msg": {"status": "success"}}
    requested_batch_size = None
    # 'json_key' is name of entity key in JSON output
    json_key = "WorkItems"
    r_kwargs = _get_request_api_kwargs_(WORKITEM_URL, timeout, kwargs)
    resp = requests.post(**r_kwargs)
    (workitems, total_rec_count, total_page_count, current_page,
            batch_size) = _get_api_response_keyvalues_(resp, json_key)
    if total_rec_count == 0:
        logger.info("TotalRecordCount: %d,Time taken: %f"
                %(total_rec_count, time.perf_counter() - st))
        out["WorkItems"] = workitems
        return out

    logger.info("Total rec count: %d, number of POST call require: %d"
            %(total_rec_count, total_page_count))
    # 'json_key' would be deleted once referenced
    r_kwargs['json_key'] = json_key
    _init_start_threads_(total_page_count, current_page,  r_kwargs, workitems)
    if total_rec_count != len(workitems):
        logger.critical("Only %d/%d records fetched. Check log for why" %(
            len(workitems), total_rec_count))
        out["msg"]["state"] = "failed"
        out["msg"]["desc"] = (
            "Only %d/%d records fetched. Reason may be "
            "CONNECT/READ timeout or SSLError exception."
            %(len(workitems), total_rec_count))
    else:
        logger.debug("total workitems fetched %d" %len(workitems))
    resp.raise_for_status()
    logger.debug("total workitems fetched %d" %len(workitems))
    workitems=dc_validator(workitems)
    logger.debug("total workitems fetched post Muti DC validation %d" %len(workitems))
    out["WorkItems"] = workitems
    return out

@timeit
def dc_validator(workitems):
    new_workitems=[]
    ignore_dcs = IGNORE_DCS.split(',')
    for i in workitems:
        only_dc=None
        for d in i['WorkItemDeliveryConstructs']:
            if d['DeliveryConstructTypeUId'] in ignore_dcs:
                continue
            if only_dc is None or only_dc == d['DeliveryConstructUId']:
                only_dc = d['DeliveryConstructUId']
                i['DeliveryConstructUId'] = only_dc
                consider_item = True
            elif only_dc is not None and only_dc != d['DeliveryConstructUId']:
                consider_item = None # we don't want to add this item to Filter
                break
            if consider_item :
                new_workitems.append(i)
    return new_workitems

@timeit
def get_phoenix_entity_data_via_api(entity_key,token, validate_token=True,timeout=(CONNECT_TIMEOUT, READ_TIMEOUT),**kwargs):
    """
    This method is just a facilitator for invoking Phoenix's workitem
    datafabric API. The invoker is supposed to handle all exceptions that
    "requests.exceptions" defines. For all exceptions refer here
    http://docs.python-requests.org/en/master/_modules/requests/exceptions/

    URL's are read from configuration, which
    can be configured for diff environments.

    this method throws any HTTP error codes as HTTPError exception if the
    response from Phoenix's API not 200.

    params:
    token: a token from Phoenix's world. Same is used to invoke datafabric
            API,
    validate_token: Default is 'False'. Set it to true if caller wants this
            method to authenticate before invoking Phoenix's workitem
    timeout: a tuple values, corresponds to 'requests' module's timeout option
            first value of the tuple is ConnectTimeout value, defaults to 5
            second value of the tuple is ReadTimeout, defaults to 40
            Both timeout values are configureable. Refer 'ai_core_configs.ini'
    **kwargs: key 'criteria' is dictionary contains all values that caller wants
            to send as body.raw field of request. Rest all key-value pairs
            are set as query parameters.

    returns: JSON, of Phoenix's API return value.
    """
#     entity_key = "Workitems"
    st = time.perf_counter()
    if validate_token:
        logger.debug("decoding access token")
        decoded_token = decode_token(token)
    else:
        logger.warning("Not opting to decode_token().")
    logger.info("access token is valid")

    out = {"msg": {"status": "success"}}
    requested_batch_size = None
    # 'json_key' is name of entity key in JSON output
    json_key = entity_key
    #url chgs as per entity key
    exec('global entity_url;entity_url='+str(entity_key))
    r_kwargs = _get_request_api_kwargs_(entity_url, timeout, kwargs)

    resp = requests.post(**r_kwargs)
    (entity_data, total_rec_count, total_page_count, current_page,batch_size) = _get_api_response_keyvalues_(resp, json_key)
    if total_rec_count == 0:
        logger.info("TotalRecordCount: %d,Time taken: %f" %(total_rec_count, time.perf_counter() - st))
        out[entity_key] = entity_data
        return out

    logger.info("Total rec count: %d, number of POST call require: %d" %(total_rec_count, total_page_count))
    # 'json_key' would be deleted once referenced
    r_kwargs['json_key'] = json_key

    _init_start_threads_(total_page_count, current_page,  r_kwargs, entity_data)

    if total_rec_count != len(entity_data):
        logger.critical("Only %d/%d records fetched. Check log for why" %(
            len(entity_data), total_rec_count))
        out["msg"]["state"] = "failed"
        out["msg"]["desc"] = ("Only %d/%d records fetched. Reason may be ""CONNECT/READ timeout or SSLError exception."%(len(workitems), total_rec_count))
    else:
        logger.debug("total "+json_key+" fetched %d" %len(entity_data))
    resp.raise_for_status()
    out[entity_key] = entity_data
#     print("Out" + str(out))
    return out

def fetch_async(tid, entities, json_key, retry_attempt=1, **kwargs):
    logger.debug("%s: running. " %tid)
    msg = "Error in thread %s:\n%s%s%s"
    try:
        resp = requests.post(**kwargs)
        resp.raise_for_status()
        logger.debug("%s: records fetched: %d" %(tid, len(resp.json()[json_key])))
        entities += resp.json()[json_key]
    except TypeError as e:
        logger.error(msg %(tid, "-"*8, str(e), "-"*8))
        retry_attempt += 1
        retry(retry_attempt, fetch_async, tid, entities, json_key, kwargs,
                retry_attempt=retry_attempt)
    except requests.exceptions.SSLError as e:
        logger.error(msg %(tid, "-"*8, str(e), "-"*8))
        retry_attempt += 1
        retry(retry_attempt, fetch_async, tid, entities, json_key, kwargs,
                retry_attempt=retry_attempt)
    except requests.exceptions.ReadTimeout as e:
        logger.error(msg %(tid, resp.json(), "-"*8, str(e), "-"*8))

def retry(attempt, func, *args):
    if attempt <= 3:
        logger.info("%s: RETRY ATTEMPT %d" %(tid, attempt))
        func(*args)
    else:
        logger.warning("%s: Max retry %d attempted" %(tid, attempt))

@timeit
def get_requirement(token, validate_token=True,
        timeout=(CONNECT_TIMEOUT, READ_TIMEOUT), fetch_via="db", **kwargs):
    if fetch_via.lower() == 'api':
        return get_requirement_via_api(token, validate_token, timeout, **kwargs)

    db = _get_database_()
    col = db.get_collection(
            "clients.requirements", CodecOptions(uuid_representation=STANDARD))
    logger.debug("got collection object")
    #cursor = col.find(
    #        _get_where_clause_(REQUIREMENTS, kwargs),
    #        _get_select_fields_(REQUIREMENTS))

    pipe =[
        {"$match": _get_where_clause_(REQUIREMENTS, kwargs)},
        {"$lookup":_get_lookup_(REQUIREMENTS)},
        {"$project":_get_select_fields_(REQUIREMENTS)}
        ]
    cursor = col.aggregate(pipeline=pipe)

    out = {"Requirements": []}
    logger.debug("Queried, got cursor obj, looping...")
    for c in cursor:
        r = {

                "RequirementTypeUId": str(c["RequirementTypeUId"]) if "RequirementTypeUId" in c else "",
                "RequirementExternalId": c["RequirementExternalId"] if "RequirementExternalId" in c else "",
                "RequirementId": c["RequirementId"] if "RequirementId" in c else "",
                "RequirementUId": c["RequirementUId"] if "RequirementUId" in c else "",
                "Title": c["Title"] if "Title" in c else "",
                "Description": c["Description"] if "Description" in c else "",
                "StateUId": str(c["StateUId"]) if "StateUId" in c else "",
                "RequirementAssociations": c["RequirementAssociations"] if "RequirementAssociations" in c else []
                }
        # Convert UUID value to string
        for e in r["RequirementAssociations"]:
            e["RequirementAssociationUId"] = str(e["RequirementAssociationUId"]) if "RequirementAssociationUId"  in e else ""
            e["AssociationTypeUId"] = str(e["AssociationTypeUId"]) if "AssociationTypeUId"  in e else ""

        out["Requirements"].append(r)
    logger.debug("No. of records fetched: %d" %len(out["Requirements"]))
    return out

# TODO:
# - configparser.InterpolationSyntaxError: '%' must be followed by '%' or '(', found:
# - handle above exception in decorator impl

def _get_database_():
    try:
        # import here, so we handle exception
        from .configs.settings import (CONNECTION_STRING, CERTIFICATE_PATH,
            CERTIFICATE_CA_PATH)

        # validate db connection string
        get_conn_str_elements(CONNECTION_STRING)

        logger.debug("validated conn string, getting conn obj")
        mc = MongoClient(CONNECTION_STRING, ssl_certfile=CERTIFICATE_PATH,
                ssl_ca_certs=CERTIFICATE_CA_PATH)
        return mc.get_database()
    except configparser.InterpolationSyntaxError as e:
        logger.critical("""Configured DB conn string has issue. Can't connect
        database. Fix issue to proceed.
        Exception: %s""" %e)
        raise configparser.InterpolationSyntaxError(e)

def _get_where_clause_(entity, kwargs):
    try:
        (cid, dcuid) = kwargs["clientUId"], kwargs["deliveryConstructUId"]
        clause = [
            {"ClientUId":UUID(cid)},
            # By default, select only ACTIVE records. ACTIVE records are those
            # that are in sync with Fabric & Tool.
            {"RowStatusUId":UUID("00100000-0000-0000-0000-000000000000")}
        ]
    except:
        pass
    if entity == WORKITEMS:
        logger.debug("Returning workitems WHERE clause")
        clause.append(
            {"WorkItemDeliveryConstructs.DeliveryConstructUId" : UUID(dcuid)})

        if "criteria" in kwargs:
            criteria = kwargs["criteria"]
            if "WorkItemTypeUId" in criteria:
                logger.debug("found 'WorkItemTypeUId' in criteria")
                clause.append( { "WorkItemTypeUId" : UUID(criteria["WorkItemTypeUId"]) } )
            if "releaseUId" in criteria:
                logger.debug("found 'releaseUId' in criteria")
                clause.append({"WorkItemAttributes": { '$elemMatch': { "Name":"ReleaseUId" ,"IdValue": UUID(criteria["releaseUId"])} }})
            if 'StateUIds' in criteria and "TypeUId" in criteria:
                logger.debug("found both 'StateUId' & 'TypeUId' in criteria")
                or_clause = []
                for suid in criteria["StateUIds"]:
                    for tuid in criteria["TypeUId"]:
                        or_clause.append({
                            'WorkItemAttributes.IdValue':{'$all': [UUID(suid), UUID(tuid)]}
                            })
                clause.append({"$or": or_clause})
            elif 'StateUIds' in criteria:
                logger.debug("found only 'StageUId' in criteria")
                # from R2.1, IdValue type is UUID, it was String
                temp_list = [UUID(i) for i in criteria["StateUIds"]]
                clause.append(
                        {"WorkItemAttributes.IdValue" : {"$in": temp_list}})
            elif "TypeUId" in criteria:
                logger.debug("found only 'TypeUId' in criteria")
                # filter 'Functional' or 'Non-Functional'
                # from R2.1, 'Function/Non-functional' are part of WorkItemAttributes
                # And we support list of value rather single value
                # prior to R2.1 they were in WorkItemExtensions
                temp_list = [UUID(i) for i in criteria["TypeUId"]]
                clause.append(
                        {"WorkItemAttributes.IdValue" : {"$in": temp_list}})

    elif entity == REQUIREMENTS:
        logger.debug("Returning requirements WHERE clause")
        clause.append({
            "RequirementDeliveryConstructs.DeliveryConstructUId" : UUID(dcuid)})
        if "criteria" in kwargs:
            rqTypeUId = "RequirementTypeUId"
            criteria = kwargs["criteria"]
            if rqTypeUId in criteria:
                # filter 'Functional' or 'Non-Functional'
                # from R2.1, we support list of values rather than single value
                temp_list = [UUID(v) for v in criteria[rqTypeUId]]
                clause.append({rqTypeUId : {"$in": temp_list}})
    elif entity == ITERATIONS or entity == ITERATIONS_CHANGELOGS:
        logger.debug("Returning iterations WHERE clause")
        (cid, dcuid) = kwargs["ClientUId"], kwargs["DeliveryConstructUId"]
        clause = [
        {"ClientUId":UUID(cid)}
        ]
        clause.append({"IterationDeliveryConstructs.DeliveryConstructUId" : UUID(dcuid)})
#        clause.append({"IterationAssociations.ItemAssociatedUId" : {"$exists" : True, "$ne" : ""}})
        if 'IterationUId' in kwargs:
            clause.append({"IterationUId":{"$in":list(map(lambda x: UUID(x),kwargs['IterationUId']))}})
    elif entity == DELIVERABLES or entity == DELIVERABLES_CHANGELOGS:
        logger.debug("Returning deliverables WHERE clause")
        (cid, dcuid) = kwargs["ClientUId"], kwargs["DeliveryConstructUId"]
        clause = [
        {"ClientUId":UUID(cid)}
        ]
        clause.append({"DeliverableDeliveryConstructs.DeliveryConstructUId" : UUID(dcuid)})
#        clause.append({"DeliverableAssociations.ItemAssociatedUId" : {"$exists" : True, "$ne" : ""}})
        if 'DeliverableUId' in kwargs:
            clause.append({"DeliverableUId":{"$in":list(map(lambda x: UUID(x),kwargs['DeliverableUId']))}})
    elif entity == MILESTONES or entity == MILESTONES_CHANGELOGS:
        logger.debug("Returning milestones WHERE clause")
        (cid, dcuid) = kwargs["ClientUId"], kwargs["DeliveryConstructUId"]
        clause = [
        {"ClientUId":UUID(cid)}
        ]
        clause.append({"MilestoneDeliveryConstructs.DeliveryConstructUId" : UUID(dcuid)})
#        clause.append({"MilestoneAssociations.ItemAssociatedUId" : {"$exists" : True, "$ne" : ""}})
        if 'MilestoneUId' in kwargs:
            clause.append({"MilestoneUId":{"$in":list(map(lambda x: UUID(x),kwargs['MilestoneUId']))}})

    # create an $and clause
    clause = {"$and": clause}
    logger.info("where_clause: ", clause)
    return clause

#get the loop values for entity association data
def _get_lookup_(entity):
    if entity == WORKITEMS:
        logger.debug("Returning WORKITEMS SELECT fields")
        return {
        'from': 'entityassociations',
        'let': { 'workItemUId': '$WorkItemUId' },
        'pipeline': [
            {
                '$match': {
                    '$and': [{ '$expr': { '$eq': ['$ItemUId', '$$workItemUId'] } },
                    { 'AssociatedWorkItemTypeUId': {'$eq': UUID(USER_STORY_TYPE_UID)}}
                    ]
                }
            }
        ], 'as': 'entityAssociationData'
    }
    elif entity == REQUIREMENTS:
        logger.debug("Returning REQUIREMENTS SELECT fields")
        return {
        'from': 'entityassociations',
        'let': { 'requirementUId': '$RequirementUId'},
        'pipeline': [
            {
                '$match': {
                    '$and': [{ '$expr': { '$eq': ['$ItemUId', '$$requirementUId'] } },
                    { '$and': [{ 'AssociatedEntityUId':  UUID(REQUIREMENT_ENTITY_UID)},
                                        {'EntityUId':UUID(REQUIREMENT_ENTITY_UID)}]}
                    ]
                }
            }
        ], 'as': 'entityAssociationData'
    }
    elif entity == ITERATIONS or entity == ITERATIONS_CHANGELOGS:
        logger.debug("Returning iterations SELECT fields")
        return {
        'from': 'entityassociations',
        'let': { 'iterationUId': '$IterationUId','workItemTypeUId':'$WorkItemTypeUId' },
        'pipeline': [
            {
                '$match': {
                    '$and': [{ '$expr': { '$eq': ['$ItemUId', '$$iterationUId'] } },
                    {'$or' : [{ '$and': [{ 'AssociatedEntityUId':  UUID(DELIVERABLE_ENTITY_UID)},
                                        {'EntityUId':UUID(ITERATION_ENTITY_UID)}]},
                                { '$and': [{ 'AssociatedEntityUId':  UUID(MILESTONE_ENTITY_UID)},
                                        {'EntityUId':UUID(ITERATION_ENTITY_UID)}]},
                                { '$and': [{ 'AssociatedEntityUId':  UUID(ITERATION_ENTITY_UID)},
                                        {'EntityUId':UUID(ITERATION_ENTITY_UID)}]}
                    ]},
                    ]
                }
            }
        ], 'as': 'entityAssociationData'
    }
    elif entity == MILESTONES or entity == MILESTONES_CHANGELOGS:
        logger.debug("Returning milestones SELECT fields")
        return {
        'from': 'entityassociations',
        'let': { 'milestoneUId': '$MilestoneUId'},
        'pipeline': [
            {
                '$match': {
                    '$and': [{ '$expr': { '$eq': ['$ItemUId', '$$milestoneUId'] } },
                    {'$or' : [{ '$and': [{ 'AssociatedEntityUId':  UUID(ITERATION_ENTITY_UID)},
                                        {'EntityUId':UUID(MILESTONE_ENTITY_UID)}]},
                                { '$and': [{ 'AssociatedEntityUId':  UUID(DELIVERABLE_ENTITY_UID)},
                                        {'EntityUId':UUID(MILESTONE_ENTITY_UID)}]},
                                { '$and': [{ 'AssociatedEntityUId':  UUID(MILESTONE_ENTITY_UID)},
                                        {'EntityUId':UUID(MILESTONE_ENTITY_UID)}]},
                    ]}]
                }
            }
        ], 'as': 'entityAssociationData'
    }
    elif entity == DELIVERABLES or entity == DELIVERABLES_CHANGELOGS:
        logger.debug("Returning deliverables SELECT fields")
        return {
        'from': 'entityassociations',
        'let': { 'deliverableUId': '$DeliverableUId' },
        'pipeline': [
            {
                '$match': {
                    '$and': [{ '$expr': { '$eq': ['$ItemUId', '$$deliverableUId'] } },
                    {'$or' : [{ '$and': [{ 'AssociatedEntityUId':  UUID(ITERATION_ENTITY_UID)},
                                        {'EntityUId':UUID(DELIVERABLE_ENTITY_UID)}]},
                                { '$and': [{ 'AssociatedEntityUId':  UUID(DELIVERABLE_ENTITY_UID)},
                                        {'EntityUId':UUID(DELIVERABLE_ENTITY_UID)}]},
                                { '$and': [{ 'AssociatedEntityUId':  UUID(MILESTONE_ENTITY_UID)},
                                        {'EntityUId':UUID(DELIVERABLE_ENTITY_UID)}]}
                    ]},
                    ]
                }
            }
        ], 'as': 'entityAssociationData'
    }


def _get_select_fields_(entity):
    if entity == WORKITEMS:
        logger.debug("Returning workitems SELECT fields")
        return {
            "WorkItemTypeUId":1,
            "WorkItemExternalId":1,
            "WorkItemId":1,
            "WorkItemUId": 1,
            "WorkItemAttributes.Name":1,
            "WorkItemAttributes.Value":1,
            "WorkItemAttributes.IdValue":1,
            "WorkItemAssociations": {
                '$map':
                {
                    'input': '$entityAssociationData', 'as': 'associationFilter',
                    'as': 'item',
                    'in':
                    {
                        'WorkItemAssociationUId': '$$item.EntityAssociationUId',
                        'AssociationTypeUId': '$$item.AssociationTypeUId',
                        'WorkItemTypeUId': '$$item.WorkItemTypeUId',
                        'WorkItemExternalId': '$$item.AssociatedWorkItemTypeUId',
                        'ItemExternalId': '$$item.AssociatedItemExternalId'
            }}}
            }

    elif entity == REQUIREMENTS:
        logger.debug("Returning requirements SELECT fields")
        return {
            "RequirementUId":1,
            "RequirementTypeUId":1,
            "RequirementExternalId":1,
            "RequirementId":1,
            "Title":1,
            "Description":1,
            "StateUId": 1,
            'RequirementAssociations': {
				'$map':
				{
					'input': '$entityAssociationData', 'as': 'associationFilter',
					'as': 'item',
					'in':
					{
						'RequirementAssociationUId': '$$item.AssociationItemUId',
						'AssociationTypeUId': '$$item.AssociationTypeUId',
						'ItemExternalId': '$$item.AssociatedItemExternalId'
			}}}
            }

    elif entity == ITERATIONS or entity == ITERATIONS_CHANGELOGS:
        logger.debug("Returning iterations SELECT fields")
        return {
            "IterationUId":1,
            "IterationExternalId":1,
            "Name":1,
            "StartOn":{ "$dateToString":{"format":"%Y-%m-%d %H:%M", "date":"$StartOn.DateTime"}},
            "EndOn":{ "$dateToString":{"format":"%Y-%m-%d %H:%M", "date":"$EndOn.DateTime"}},

            "IterationExtensions.FieldName":1,
            "IterationExtensions.FieldValue":1,
            'IterationAssociations': {
				'$map':
				{
					'input': '$entityAssociationData', 'as': 'associationFilter',
					'as': 'item',
					'in':
					{
						'EntityUId': '$$item.AssociatedEntityUId',
						'ItemAssociatedUId': '$$item.ItemAssociatedUId',
						'ItemExternalId': '$$item.AssociatedItemExternalId'
			}}}}

    elif entity == MILESTONES or entity == MILESTONES_CHANGELOGS:
        logger.debug("Returning milestones SELECT fields")
        return {
            "MilestoneUId":1,
            "MilestoneExternalId":1,
            "Title":1,
            "ActualEndOn":{ "$dateToString":{"format":"%Y-%m-%d %H:%M", "date":"$ActualEndOn.DateTime"}},
            "CommittedEndOn":{ "$dateToString":{"format":"%Y-%m-%d %H:%M", "date":"$CommittedEndOn.DateTime"}},
            "ForecastEndOn":{ "$dateToString":{"format":"%Y-%m-%d %H:%M", "date":"$ForecastEndOn.DateTime"}},
            "EffortEstimated":1,
            "StateUId":1,

            "MilestoneExtensions.FieldName":1,
            "MilestoneExtensions.FieldValue":1,
            'MilestoneAssociations': {
				'$map':
				{
					'input': '$entityAssociationData', 'as': 'associationFilter',
					'as': 'item',
					'in':
					{
						'EntityUId': '$$item.AssociatedEntityUId',
						'ItemAssociatedUId': '$$item.AssociatedItemUId',
						'ItemExternalId': '$$item.AssociatedItemExternalId'
			}}}
            }
    elif entity == DELIVERABLES or entity == DELIVERABLES_CHANGELOGS:
        logger.debug("Returning deliverables SELECT fields")
        return {
            "DeliverableUId":1,
            "DeliverableExternalId":1,
            "Title":1,
            "ForecastStartOn":{ "$dateToString":{"format":"%Y-%m-%d %H:%M", "date":"$ForecastStartOn.DateTime"}},
            "ForecastEndOn":{ "$dateToString":{"format":"%Y-%m-%d %H:%M", "date":"$ForecastEndOn.DateTime"}},
            "CommittedStartOn":{ "$dateToString":{"format":"%Y-%m-%d %H:%M", "date":"$CommittedStartOn.DateTime"}},
            "CommittedEndOn":{ "$dateToString":{"format":"%Y-%m-%d %H:%M", "date":"$CommittedEndOn.DateTime"}},
            "ActualStartOn":{ "$dateToString":{"format":"%Y-%m-%d %H:%M", "date":"$ActualStartOn.DateTime"}},
            "ActualEndOn":{ "$dateToString":{"format":"%Y-%m-%d %H:%M", "date":"$ActualEndOn.DateTime"}},
            "StateUId" : 1,
        	"PriorityUId" : 1,
        	"TotalEffort" : 1,
        	"EffortEstimated" : 1,
        	"EffortCompleted" : 1,
        	"EffortRemaining" : 1,
        	"EffortVariance" : 1,
        	"PercentEffortCompleted" : 1,
        	"PercentDurationCompleted" : 1,
        	"PhysicalPercentCompleted" : 1,

            "DeliverableExtensions.FieldName":1,
            "DeliverableExtensions.FieldValue":1,
            'DeliverableAssociations': {
				'$map':
				{
					'input': '$entityAssociationData', 'as': 'associationFilter',
					'as': 'item',
					'in':
					{
						'EntityUId': '$$item.AssociatedEntityUId',
						'ItemAssociatedUId': '$$item.AssociatedItemUId',
						'ItemExternalId': '$$item.AssociatedItemExternalId'
			}}}
            }

@timeit
def get_requirement_via_api(token, validate_token=True,
        timeout=(CONNECT_TIMEOUT, READ_TIMEOUT), **kwargs):
    st = time.perf_counter()
    if validate_token:
        logger.debug("decoding access token")
        decoded_token = decode_token(token)
    else:
        logger.warning("Not opting to decode_token().")
    logger.info("access token is valid")

    # 'json_key' is name of entity key in JSON output
    json_key = "Requirements"
    r_kwargs = _get_request_api_kwargs_(REQUIREMENT_URL, timeout, kwargs)
    resp = requests.post(**r_kwargs)

    (requirements, total_rec_count, total_page_count,
            current_page, batch_size) = _get_api_response_keyvalues_(resp, json_key)
    if total_rec_count == 0:
        logger.info("TotalRecordCount: %d,Time taken: %f"
                %(total_rec_count, time.perf_counter() - st))
        return {'Requirements': requirements}

    logger.info("Total rec count: %d, number of POST call require: %d"
            %(total_rec_count, total_page_count))
    # 'json_key' would be deleted once referenced
    r_kwargs['json_key'] = json_key
    _init_start_threads_(total_page_count, current_page, r_kwargs, requirements)
    if total_rec_count != len(requirements):
        logger.critical("Only %d/%d records fetched. Check log for why" %(
            len(requirements), total_rec_count))
    else:
        logger.info("total requirements fetched %d" %len(requirements))
    resp.raise_for_status()
    return {'Requirements': requirements}

def get_data_by_id(entity_type, ids, client_uid, delivery_construct_uid):
    clause = {
            "ClientUId":UUID(client_uid),
    }
    db = _get_database_()
    trouble_records = []
    if entity_type == "story":
        col = db.get_collection(
                "clients.workitems", CodecOptions(uuid_representation=STANDARD))

        clause["WorkItemId"] = {"$in":[int(value) for value in ids]}
        clause["WorkItemDeliveryConstructs.DeliveryConstructUId"] = UUID(delivery_construct_uid)
        fields = {"WorkItemAttributes.Name":1,"WorkItemAttributes.Value":1}
    #    logger.debug("got collection object")
        cursor = col.find(clause,fields)
        out = {"WorkItems": []}
    #    logger.debug("Queried, got cursor obj, looping...")
        for c in cursor:
            w = {
                    "WorkItemAttributes": c["WorkItemAttributes"] if "WorkItemAttributes" in c else [],
                    }
            # Have flat attributes from WA
            r = {}
            for i, da in enumerate(w["WorkItemAttributes"]):
                attrs = ['Title', 'Description']
                try:
                    if da['Name'] in attrs:
                            r[da['Name']] = da['Value'] if 'Value' in da and da['Value'] else ""
                except KeyError as e:
                    trouble_records.append(w)
            out['WorkItems'].append(r)
    if entity_type == "requirement":
        col = db.get_collection(
                "clients.requirements", CodecOptions(uuid_representation=STANDARD))
        clause["RequirementId"] = {"$in":[int(value) for value in ids]}
        clause["RequirementDeliveryConstructs.DeliveryConstructUId"] = UUID(delivery_construct_uid)
        fields = {"Title":1,"Description":1}
    #    logger.debug("got collection object")
        cursor = col.find(clause,fields)
        out = {"Requirements": []}
        r = {}
        for c in cursor:
            r = {
                "Title": c["Title"] if "Title" in c else "",
                "Description": c["Description"] if "Description" in c else "",
            }
            out["Requirements"].append(r)
    return out

def get_workitem_count(kwargs: dict, fetch_via='db'):
    if fetch_via.lower() == 'api':
        out = get_workitem_via_api(get_access_token(), **kwargs)
        return len(out['WorkItems'])
    db = _get_database_()
    col = db.get_collection(
            "clients.workitems", CodecOptions(uuid_representation=STANDARD))
    logger.debug("got collection object")
    count = col.count_documents( _get_where_clause_(WORKITEMS, kwargs) )
    logger.info(f"Found {count} WorkItems for '{kwargs}' when fetched via '{fetch_via}'")
    return count

def get_requirement_count(kwargs: dict, fetch_via='db'):
    if fetch_via.lower() == 'api':
        out = get_requirement_via_api(get_access_token(), **kwargs)
        return len(out['Requirements'])
    db = _get_database_()
    col = db.get_collection(
            "clients.requirements", CodecOptions(uuid_representation=STANDARD))
    logger.debug("got collection object")
    count = col.count_documents( _get_where_clause_(REQUIREMENTS, kwargs) )
    logger.info(f"Found {count} Requirements for '{kwargs}' when fetched via '{fetch_via}'")
    return count

# @timeit
def get_access_token(
        for_resource=PHOENIX_RESOURCE_ID, # defaults to phoenix resources
        timeout=(CONNECT_TIMEOUT, READ_TIMEOUT)):
    """
    Get 'access_token' for a protected resource. This method implements
    fetching access tokens for "Fortress" & "Azure AD" authentication types.

    UPDATE: If the AUTH_TYPE is Azure AD, it tries to serve last recent token, if the
    token is >3m & less than 1hr, assuming access token from Azure AD lives max 1hr

    This method reads its many required parameter values from
    'ai_core_configs.ini' file.

    @params:
    for_resource: Defaults to Phoenix(as a client here) resources.
    ONLY required in case of Asure AD auth type AND caller wants to access
    any other resource apart from Phoenix's. Eg: OCR wants to call back
    URL which caller of that API supplies in its request.
    timeout: tuple, connection & read timeout values. Default is (5, 40)
    """
    global RECENT_ACCESS_TOKEN
    if RECENT_ACCESS_TOKEN and AUTH_TYPE == AZURE_AD or RECENT_ACCESS_TOKEN and AUTH_TYPE == FORGEROCK:
        # TODO: Not sure the same logic works for FORTRESS,
        (header, payload, sig) = RECENT_ACCESS_TOKEN.split('.')  # as documented in _get_kid_()
        # IMP: we're adding '===' explicitly here to avoid 'binascii.Error: IncorrectPadding
        # this solution is from https://gist.github.com/perrygeo/ee7c65bb1541ff6ac770
        # so having excess padding char is fine, so...
        payload_dict = json.loads(base64.standard_b64decode(payload + "===").decode('utf-8'))
        expire_at = datetime.fromtimestamp(int(payload_dict['exp'])) # expiry value in Token
        now = datetime.now()
        if expire_at > now:
            timedelta = expire_at - now
            if timedelta.seconds >= 180 and timedelta.seconds < 3600:
                logger.warning(f"Returning last recent token, as its 'exp': {expire_at} is >3m & <1h")
                return RECENT_ACCESS_TOKEN
        RECENT_ACCESS_TOKEN = ''
        return get_access_token()
    msg = "Fetching access token from {}. URL: {}, QPARAM: {}, HEADER: {}"
    
    if AUTH_TYPE == AZURE_AD:
        params = {
                "client_id":CLIENT_ID,
                # the resource for which we're requesting access to
                "resource": for_resource,
                "client_secret":SECRET_KEY,
                }
        logger.info("grant_type configured is %s" %GRANT_TYPE)
        if GRANT_TYPE == GT_CLIENT_CREDENTIALS:
            params["grant_type"] = GT_CLIENT_CREDENTIALS
        elif GRANT_TYPE == GT_PASSWORD:
            params["grant_type"] = GT_PASSWORD
            params["scope"] = "openid"
            params["username"] = USERNAME
            params["password"] = PASSWORD
        else:
            # throw invalid configuration error
            logger.error("Invalid 'grant_type'. Configured: %s" %GRANT_TYPE)
            raise ValueError("""Invalid 'grant_type'. Configured value is'%s'.\
                    Valid values: '%s' or '%s'""" %(GRANT_TYPE, GT_PASSWORD,
                        GT_CLIENT_CREDENTIALS))
        logger.debug(msg.format(AUTH_TYPE, ACCESS_TOKEN_URL, params, ''))
        resp = requests.post(
                url=ACCESS_TOKEN_URL, data=params, timeout=timeout)
    if AUTH_TYPE == FORGEROCK:
        params = {
                "client_id":CLIENT_ID,
                # the resource for which we're requesting access to
                "resource": for_resource,
                "client_secret":SECRET_KEY
                }
        logger.info("grant_type configured is %s" %GRANT_TYPE)
        if GRANT_TYPE == GT_CLIENT_CREDENTIALS:
            params["grant_type"] = GT_CLIENT_CREDENTIALS
        else:
            # throw invalid configuration error
            logger.error("Invalid 'grant_type'. Configured: %s" %GRANT_TYPE)
            raise ValueError("""Invalid 'grant_type'. Configured value is'%s'.\
                    Valid values: '%s' or '%s'""" %(GRANT_TYPE, GT_PASSWORD,
                        GT_CLIENT_CREDENTIALS))
        logger.debug(msg.format(AUTH_TYPE, ACCESS_TOKEN_URL, params, ''))
        resp = requests.post(
                url=ACCESS_TOKEN_URL, data=params, timeout=timeout)
    elif AUTH_TYPE == FORTRESS:
        headers = { "username": USERNAME, "password": PASSWORD, }
        logger.debug(msg.format(AUTH_TYPE, ACCESS_TOKEN_URL, '', headers))
        resp = requests.post(
                url=ACCESS_TOKEN_URL, headers=headers, timeout=timeout)
    resp.raise_for_status()
    logger.debug("access_token %s" %resp.json()['access_token'])
    RECENT_ACCESS_TOKEN = resp.json()['access_token']
    return RECENT_ACCESS_TOKEN

def _get_phoenix_api_header_():
    header = {
        "Content-Type"  : "application/json",
        "AppServiceUId" : APP_SERVICE_UID,
        "UserEmailId"   : USERNAME
    }
    if AUTH_TYPE != WINDOWS_AUTH:
        # When 'auth' scheme is Azure or Fortress, we add 'Bearer *' in Authorization 
        # in the Header
        header["Authorization"] = "Bearer " + get_access_token()
        del header["UserEmailId"]
    return header
    
def _get_request_api_kwargs_(url, timeout, kwargs):
    
    if kwargs:
        logger.debug(kwargs)
        if ('criteria' in kwargs):
            # phoenix api's criteria set by caller
            data = json.dumps(kwargs['criteria'])
            # delete 'criteria', so that its not part of query-params
            del kwargs['criteria']
        else:
            data=None
        #Need to be reviewed    
        # else:
        #     # phoenix api request body's default value
        #     data = json.dumps({
        #         'ClientUId': kwargs['clientUId'],
        #         'DeliveryConstructUId': kwargs['deliveryConstructUId']})
        # phoenix api's query parameter
        params = kwargs
    else:
        data=None
        params=None

    header = _get_phoenix_api_header_()
    logger.debug("url: %s, header: %s, qparam: %s, body: %s" %(url, header, params, data))
    request_object = {'url': url, 'headers': header, 'data': data,
        'params': params, 'timeout': timeout}

    if AUTH_TYPE == WINDOWS_AUTH:
        # We add 'auth' attr to 'request' obj when authentication scheme is Windows
        # NOTE: we DON'T add this in the Header, 
        windows_auth = HttpNegotiateAuth()
        logger.debug("url: %s, auth: %s, qparam: %s, body: %s" %(url, windows_auth, params, data))
        request_object['auth'] = windows_auth

    return request_object

def _init_start_threads_(total_page_count, current_page, r_kwargs, workitems):
    threads = []
    data = json.loads(r_kwargs['data'])

    # 'json_key' is name of entity key in JSON output
    json_key = r_kwargs['json_key']
    # json_key isn't a request.post() kwargs, so delete it.
    del r_kwargs['json_key']

    for i in range(1, total_page_count):
        data['PageNumber'] = current_page + i
        r_kwargs['data'] = json.dumps(data)
        # IMP: Note: if every request to phoenix api requires a new token,
        # which is the case in AZURE auth type, then following code
        # needs to be uncommented.
        # r_kwargs['headers'] = json.dumps(_get_phoenix_api_header_())
        tid = str(data['PageNumber']) + "/" + str(total_page_count)
        logger.debug("Creating thread %s" %tid)
        th = threading.Thread(name=tid, target=fetch_async,
                args=(tid, workitems, json_key), kwargs=r_kwargs)
        threads.append(th)
        logger.debug("%s: starting" %tid)
        th.start()
        if(i%THREAD_BATCH_COUNT == 0):
            """Wait for sometime before you spawn next batch of 10 threads.
            why wait? b'se we don't want to bombard CPU with threds that
            jeopardise the resouce availability."""
            logger.debug("Spawned %d threads, now waiting for %d"
                    %(THREAD_BATCH_COUNT, WAIT_TIME))
            time.sleep(WAIT_TIME)

    for i, th in enumerate(threads):
        if th.is_alive():
            logger.debug("%s: still alive, waiting for it to complete"
                    %th.getName())
            th.join()
        else:
            logger.debug("%s: done. Not waiting" %th.getName())

def _get_api_response_keyvalues_(resp, entity_key):
    """Helper methods to grab common key-values from JSON output of
    Phoenix API"""
    # resp = requests.post(**r_kwargs)
    logger.debug(resp.status_code)
    resp.raise_for_status()
    resp_json = resp.json()
    entities = resp_json[entity_key]
    total_rec = resp_json["TotalRecordCount"]
    total_page = resp_json["TotalPageCount"]
    current_page = resp_json["CurrentPage"]
    batch_size = resp_json["BatchSize"]

    return (entities, total_rec, total_page, current_page, batch_size)

def _get_request_api_kwargs_msp(token,url, timeout, kwargs):
    header = _get_phoenix_api_header_()
    logger.debug(kwargs)
    if ('criteria' in kwargs):
        # phoenix api's criteria set by caller
        data = json.dumps(kwargs['criteria'])
        # delete 'criteria', so that its not part of query-params
        del kwargs['criteria']
    else:
        # phoenix api request body's default value
        data = json.dumps({
            'ClientUId': kwargs['clientUId'],
            'DeliveryConstructUId': kwargs['deliveryConstructUId']})
    # phoenix api's query parameter
    params = kwargs
#    logger.debug("url: %s, header: %s, qparam: %s, body: %s" %(url, token, params, data))
    return {'url': url, 'headers': header, 'data': data,
            'params': params, 'timeout': timeout}

@timeit
def get_changelog_via_api(token,timeout=(CONNECT_TIMEOUT, READ_TIMEOUT), **kwargs):

    st = time.perf_counter()
    out = {"msg": {"status": "success"}}
    requested_batch_size = None
    # 'json_key' is name of entity key in JSON output
    json_key = "EntityItem"
    r_kwargs = _get_request_api_kwargs_msp(token,MSF_URL, timeout, kwargs)
    resp = requests.post(**r_kwargs)
    (milestoneforecast, total_rec_count, total_page_count, current_page,
            batch_size) = _get_api_response_keyvalues_(resp, json_key)
    if total_rec_count == 0:
        logger.info("TotalRecordCount: %d,Time taken: %f"
                %(total_rec_count, time.perf_counter() - st))
        out["EntityItem"] = milestoneforecast
        return out

    logger.info("Total rec count: %d, number of POST call require: %d"
            %(total_rec_count, total_page_count))
    # 'json_key' would be deleted once referenced
    r_kwargs['json_key'] = json_key
    _init_start_threads_(total_page_count, current_page,  r_kwargs, milestoneforecast)
    if total_rec_count != len(milestoneforecast):
        logger.critical("Only %d/%d records fetched. Check log for why" %(
            len(milestoneforecast), total_rec_count))
        out["msg"]["state"] = "failed"
        out["msg"]["desc"] = (
            "Only %d/%d records fetched. Reason may be "
            "CONNECT/READ timeout or SSLError exception."
            %(len(milestoneforecast), total_rec_count))
    else:
        logger.debug("total entities fetched %d" %len(milestoneforecast))
    resp.raise_for_status()
    out["EntityItem"] = milestoneforecast
    return out
    
def get_rsp_changelog_via_api(changelog_endpoint, token, timeout=(CONNECT_TIMEOUT, READ_TIMEOUT), **kwargs):

    st = time.perf_counter()
    out = {"msg": {"status": "success"}}
    requested_batch_size = None
    # 'json_key' is name of entity key in JSON output
    json_key = "Entity"
    #exec('global changelog_url;changelog_url='+str(changelog_endpoint))
    token = get_access_token()
    changelog_url =  HADOOP_DOMAIN + str(changelog_endpoint)
    r_kwargs = _get_request_api_kwargs_msp(token,changelog_url, timeout, kwargs)
    print(r_kwargs)
    resp = requests.post(**r_kwargs)
    (changelogs, total_rec_count, total_page_count, current_page,
            batch_size) = _get_api_response_keyvalues_(resp, json_key)
    if total_rec_count == 0:
        logger.info("TotalRecordCount: %d,Time taken: %f"
                %(total_rec_count, time.perf_counter() - st))
        out["Entity"] = changelogs
        return out

    logger.info("Total rec count: %d, number of POST call require: %d"
            %(total_rec_count, total_page_count))
    # 'json_key' would be deleted once referenced
    r_kwargs['json_key'] = json_key
    data = json.loads(r_kwargs['data'])
    data['TotalRecordCount']= total_rec_count
    r_kwargs['data'] = json.dumps(data)
    _init_start_threads_(total_page_count, current_page,  r_kwargs, changelogs)
    if total_rec_count != len(changelogs):
        logger.critical("Only %d/%d records fetched. Check log for why" %(
            len(changelogs), total_rec_count))
        out["msg"]["state"] = "failed"
        out["msg"]["desc"] = (
            "Only %d/%d records fetched. Reason may be "
            "CONNECT/READ timeout or SSLError exception."
            %(len(changelogs), total_rec_count))
    else:
        logger.debug("total entities fetched %d" %len(changelogs))
    resp.raise_for_status()
    out['Entity'] = changelogs
    return out

@timeit
def get_slippage_data(criteria):
    iteration_uids = []
    deliverable_uids = []
    milestones_uids = []
    associated_iteration_id = []
    associated_deliverable_id = []
    associated_milestone_id = []

    logger.info("Fetching token")
    token = _get_phoenix_api_header_()
    logger.info("Fetching milestone")
    criteria.update({"Entity": "milestones","PageNumber": 1,"BatchSize": BATCH_SIZE})
    milestone = get_changelog_via_api(token,criteria=criteria)
    milestone_df = pd.DataFrame.from_dict(milestone["EntityItem"])
    if milestone_df.empty != True:
        milestones_uids = milestone_df["milestoneuid"].tolist()
    logger.info("total milestone fetched %d" %len(milestones_uids))


    logger.info("Fetching deliverable")
    criteria.update({ "Entity": "deliverables","PageNumber": 1,"BatchSize": BATCH_SIZE})
    deliverable = get_changelog_via_api(token,criteria=criteria)
    deliverable_df = pd.DataFrame.from_dict(deliverable["EntityItem"])
    if deliverable_df.empty != True:
        deliverable_uids = deliverable_df["deliverableuid"].tolist()
    logger.info("total delieverable fetched %d" %len(deliverable_uids))

    logger.info("Fetching iteration")
    criteria.update({ "Entity": "iterations","PageNumber": 1,"BatchSize": BATCH_SIZE})
    iteration = get_changelog_via_api(token,criteria=criteria)
    iteration_df = pd.DataFrame.from_dict(iteration["EntityItem"])
    if iteration_df.empty != True:
        iteration_uids = iteration_df["iterationuid"].tolist()
    logger.info("total iterations fetched %d" %len(iteration_uids))


    logger.info("Checking milestone associations")
    if milestone_df.empty != True:
        rslt_df = milestone_df.loc[milestone_df['milestoneassociations_entityuid'] == ITERATION_ENTITY_UID]
        if rslt_df.empty != True:
            associated_iteration_id.extend(rslt_df["milestoneassociations_itemassociateduid"].tolist())

        rslt_df = milestone_df.loc[milestone_df['milestoneassociations_entityuid'] == DELIVERABLE_ENTITY_UID]
        if rslt_df.empty != True:
            associated_deliverable_id.extend(rslt_df["milestoneassociations_itemassociateduid"].tolist())


    logger.info("Checking deliverable associations")
    if deliverable_df.empty != True:
        rslt_df = deliverable_df.loc[deliverable_df['deliverableassociations_entityuid'] == ITERATION_ENTITY_UID]
        if rslt_df.empty != True:
            associated_iteration_id.extend(rslt_df["deliverableassociations_itemassociateduid"].tolist())

        rslt_df = deliverable_df.loc[deliverable_df['deliverableassociations_entityuid'] == MILESTONE_ENTITY_UID]
        if rslt_df.empty != True:
            associated_milestone_id.extend(rslt_df["deliverableassociations_itemassociateduid"].tolist())

    logger.info("Checking iteration associations")
    if 'iterationassociations_entityuid' in iteration_df.columns.tolist() and iteration_df.empty != True:
        rslt_df = iteration_df.loc[iteration_df['iterationassociations_entityuid'] == DELIVERABLE_ENTITY_UID]
        if rslt_df.empty != True:
            associated_deliverable_id.extend(rslt_df["iterationassociations_itemassociateduid"].tolist())

        rslt_df = iteration_df.loc[iteration_df['iterationassociations_entityuid'] == MILESTONE_ENTITY_UID]
        if rslt_df.empty != True:
            associated_milestone_id.extend(rslt_df["iterationassociations_itemassociateduid"].tolist())

    missed_iteration_ids = set(associated_iteration_id)- set(iteration_uids)
    missed_milestone_ids = set(associated_milestone_id)-set(milestones_uids)
    missed_deliverable_ids = set(associated_deliverable_id)-set(deliverable_uids)

    logger.info("Fetching associated milestones")
    if len(missed_milestone_ids) != 0:
        criteria.update({"EntityUId":list(missed_milestone_ids),"Entity": "milestones"})
        missed_milestone = get_changelog_via_api(token,criteria=criteria)
        milestone_df = milestone_df.append(missed_milestone["EntityItem"],ignore_index=True)
    logger.info("total associated milestones %d" %len(missed_milestone_ids))

    logger.info("Fetching associated deliverables")
    if len(missed_deliverable_ids) != 0:
        criteria.update({"EntityUId":list(missed_deliverable_ids),"Entity": "deliverables"})
        missed_deliverable = get_changelog_via_api(token,criteria=criteria)
        deliverable_df = deliverable_df.append(missed_deliverable["EntityItem"],ignore_index=True)
    logger.info("total associated deliverables %d" %len(missed_deliverable_ids))


    logger.info("Fetching associated iterations")
    if len(missed_iteration_ids) != 0:
        criteria.update({ "Entity": "iterations","EntityUId":list(missed_iteration_ids)})
        missed_iteration = get_changelog_via_api(token,criteria=criteria)
        iteration_df = iteration_df.append(missed_iteration["EntityItem"],ignore_index=True)
    logger.info("total associated iterations %d" %len(missed_iteration_ids))

    logger.info("creating response json")
    merged_response = {"milestone":milestone_df,
    "deliverable":deliverable_df,"iteration":iteration_df}

    return(merged_response)
#w = get_slippage_data(criteria=criteria)

def handle_commons_api_exceptions(func):
    """ Helper decorator to catch common http, JWT, DB errors and respond proper
    error msg with HTTP status code
    """
    def _log_n_add_resp(resp, e):
        resp['verbose'] = "Exception: %s" %str(e)
        logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))

    def wrapper(*args, **kwargs):
        http_status_code = None
        resp = {"status": "fail"}
        try:
            return func(*args, **kwargs)
        except ExpiredSignatureError as e:
            resp['msg'] = ("Access token recieved has expired. Atleast 'exp' "
            "claim indicates that it has.")
            resp['verbose'] = _get_verbose_str_(ExpiredSignatureError.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), requests.codes.UNAUTHORIZED
        except DecodeError as e:
            resp['msg'] = "Falied to validate token. Hence can't decode token"
            resp['verbose'] = _get_verbose_str_(DecodeError.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), requests.codes.UNAUTHORIZED
        except InvalidSignatureError as e:
            resp['verbose'] = _get_verbose_str_(InvalidSignatureError.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), requests.codes.UNAUTHORIZED
        except InvalidAudienceError as e:
            resp["msg"] = "'aud' claim does not match one of the expected audience values. "
            resp['verbose'] = _get_verbose_str_(InvalidAudienceError.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), requests.codes.UNAUTHORIZED
        except InvalidIssuerError as e:
            resp["msg"] = "'iss' claim does not match the expected issuer values"
            resp['verbose'] = _get_verbose_str_(InvalidIssuerError.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), requests.codes.UNAUTHORIZED
        except ImmatureSignatureError as e:
            resp["msg"] = "Token’s 'nbf' claim represents a time in the future. "
            resp['verbose'] = _get_verbose_str_(ImmatureSignatureError.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), requests.codes.UNAUTHORIZED
        except InvalidAlgorithmError as e:
            resp["msg"] = "Specified algorithm in token is not recognized by PyJWT."
            resp['verbose'] = _get_verbose_str_(InvalidAlgorithmError.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), requests.codes.UNAUTHORIZED
        except MissingRequiredClaimError as e:
            resp["msg"] = "Required claim not present in claim-set."
            resp['verbose'] = _get_verbose_str_(MissingRequiredClaimError.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), requests.codes.UNAUTHORIZED
        except InvalidToken as e:
            resp["msg"] = """'Signature/app_key' couldn't digest encrypted credentials,\
            used in access token URL. Possible reason is 'app_key' used to \
            decrypt the ecrypted credentials is wrong/old. Generate fresh set of \
            encrypted credentials & configure all 3 outputs in config."""
            resp['verbose'] = _get_verbose_str_(InvalidToken.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), requests.codes.INTERNAL_SERVER_ERROR
        except HTTPError as e:
            resp["msg"] = ("HTTPError occured while calling one of the "
                "'phoenix core apis'. The HTTP response code reflects its "
                "response")
            resp["verbose"] = _get_verbose_str_(HTTPError.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), e.response.status_code
        except JSONDecodeError as e:
            resp["msg"] = ("Looks like for the entity(workitem or requirement) "
            "queried, phoenix returned with 'empty response' or 'no json "
            "response'. Expected is JSON. Couldn't decode JSON. Check your "
            "HTTP request.")
            resp["verbose"] = _get_verbose_str_(JSONDecodeError.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), requests.codes.INTERNAL_SERVER_ERROR
        except ServerSelectionTimeoutError as e:
            resp["msg"] = ("MongoDB server is unavailalbe to connect. "
                    "'mongod' may not be running at all on server where you're"
                    " trying to connect")
            resp['verbose'] = _get_verbose_str_(ServerSelectionTimeoutError.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), requests.codes.INTERNAL_SERVER_ERROR
        except InvalidURI as e:
            resp["msg"] = "Configured DB connection URI is invalid. Can't parse."
            resp['verbose'] = _get_verbose_str_(InvalidURI.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), requests.codes.INTERNAL_SERVER_ERROR
        except ExecutionTimeout as e:
            resp["msg"] = "Database operation timed out."
            resp['verbose'] = _get_verbose_str_(ExecutionTimeout.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), requests.codes.INTERNAL_SERVER_ERROR
        except ConnectionFailure as e:
            resp["msg"] = "Either connection to DB is lost or can't be made"
            resp['verbose'] = _get_verbose_str_(ConnectionFailure.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), requests.codes.INTERNAL_SERVER_ERROR
        except ConfigurationError as e:
            resp["msg"] = "Something in DB config is incorrectly configured."
            resp['verbose'] = _get_verbose_str_(ConfigurationError.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), requests.codes.INTERNAL_SERVER_ERROR
        except InvalidOperation as e:
            resp["msg"] = ("Looks like 'authSource' DB, from conn string, "
                    "doesn't have necessary authorization configured to "
                    "perform R/W operation for the connected user.")
            resp['verbose'] = _get_verbose_str_(InvalidOperation.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), requests.codes.INTERNAL_SERVER_ERROR
        except InvalidURL as e:
            resp["msg"] = "Configured 'phoenix core api URLs' is invalid"
            resp["verbose"] = _get_verbose_str(InvalidURL.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), requests.codes.INTERNAL_SERVER_ERROR
        except ReadTimeout as e:
            resp["msg"] = ("Server didn't respond in configured %d time"
                    %READ_TIMEOUT)
            resp["verbose"] = _get_verbose_str_(ReadTimeout.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), requests.codes.INTERNAL_SERVER_ERROR
        except ConnectTimeout as e:
            resp["msg"] = "Request timed out while connecting to server. "
            resp["verbose"] = _get_verbose_str(ConnectTimeout.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), requests.codes.INTERNAL_SERVER_ERROR
        except RequestException as e:
            resp["msg"] = "This is base exception. Check 'verbose' for more. "
            resp["verbose"] = _get_verbose_str_(RequestException.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            logger.error(e)
            return jsonify(resp), requests.codes.INTERNAL_SERVER_ERROR
        except ValueError as e:
            resp["msg"] = """One of the configuration in 'ai_core_commons.ini'\
                    is incorrectly configured.i"""
            resp["verbose"] = _get_verbose_str_(ValueError.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            return jsonify(resp), requests.codes.INTERNAL_SERVER_ERROR
        except KeyError as e:
            resp["msg"] = """One or more key missiong"""
            resp["verbose"] = _get_verbose_str_(KeyError.__name__, e)
            logger.error("%s\nException: %s"%(resp['msg'], resp['verbose']))
            return jsonify(resp), requests.codes.INTERNAL_SERVER_ERROR
    wrapper.__name__ = func.__name__
    return wrapper

def _get_verbose_str_(e_name, e_obj):
    """Helper method to form 'verbose' string with more details, targeted
    for API json response. If the exception is from 'requests.exceptions' module
    it will try add 'request' & 'response' attributes, none otherwise."""
    g = "Exception: %s, exception_msg: %s"
    try:
        verbose = (g + ", request_obj: [%s], response_obj: [%s]" %(
            e_name, str(e_obj),
            e_obj.request.__dict__ if e_obj.request.__dict__ else "",
            e_obj.response._dict__ if e_obj.response.__dict__ else ""))
    except AttributeError as e:
        logger.error("You can ignore following exception. [%s]" %str(e))
        verbose = (g %(e_name, str(e_obj)))
    return verbose



# if __name__ == '__main__':
#     # Phoenix token test

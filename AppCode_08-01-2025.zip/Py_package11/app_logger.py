import os, configparser
from datetime import datetime
from ai_core.configs.file_encryptor import get_configparser_obj
from ai_core.commons import get_logger
logHandler = list()

def get_alogger(Clientid='', Dcid=''):
    if len(logHandler) > 0:
        return logHandler[0]
    # config = configparser.ConfigParser()
    conf_file_path = os.path.join(os.path.dirname(__file__),"pythonconfig.ini")
    config = get_configparser_obj(conf_file_path)
    # config.read(conf_file_path)
    filename = config.get('app_log', 'filename')

    current_time = datetime.utcnow()
    current_time = current_time.strftime("%d-%m-%Y-%H-%M-%S")
    file_name = filename + '_' + current_time + '.log'
    logger = get_logger(app="GenWizard", name='GenWizard', filename=file_name, config_fpath=conf_file_path)
    logHandler.append(logger)

    return logger
from redis import Redis, ConnectionPool
from redis import ConnectionError, TimeoutError
from ai_core.configs.settings import EXPIRES, REDIS_URL, HEALTH_CHECK_INTERVAL
from ai_core.commons import logger
import sqlite3
import sys,traceback
import datetime
from dateutil.parser import parse
import json
import ast



class RedisConnection(Redis):
    def __init__(self, pool):
        logger.debug(f"creating Redis connection in pool: {pool}")
        super().__init__(
            connection_pool = pool,
            decode_responses = True,
            health_check_interval = HEALTH_CHECK_INTERVAL,
            retry_on_timeout=True)

    def get(self, *args, **kwargs):
        # Because we instantiated Redis from conn string, 'decode_responses'
        # doesn't seem to be working, hence override the behaviour
        v = super().get(*args, **kwargs)
        if v is not None:
            return v.decode('utf-8')
        return None

    def set(self, *args, **kwargs):
        # Sets expiration based on ai core config redis_cache expires value.
        # if we want custom value for the ttl pass ttl in seconds via ex parameter
        # Example: r.set(key, value, ex=30) <-- this will set the key to hold the value for 30 secs
        # use r.ttl(key) to check the ttl of the key in seconds
        
        if ('ex' in kwargs):
            super().set(*args, **kwargs)
        else:
            super().set(*args, **kwargs,ex=EXPIRES)
    
            
#to do -read dbname from config 
class SQLiteDatabase:
    
    def __init__(self, name='dbcache.db'):
        
        self.conn = None
        self.cursor = None

        

    """ Opens a new database connection."""
    def open_connection(self,name = 'dbcache.db'):
        
        try:
            self.conn = sqlite3.connect(name, timeout=10,detect_types=sqlite3.PARSE_DECLTYPES |
                                                        sqlite3.PARSE_COLNAMES);
            self.cursor = self.conn.cursor()
            logger.info("Connected to database!")
            #create table if it not exists
            listOfTables = self.cursor.execute(
                """SELECT name FROM sqlite_master WHERE type='table'
                AND name='ProductEntityTable'; """).fetchall()
 
            if listOfTables == []:
                logger.info('Table not found!')
              
                self.cursor.execute(
                "CREATE TABLE ProductEntityTable (id varchar(30), data json ,ClientUId varchar(20),DCUId varchar(20), EntityUId varchar(20), WorkItemTypeUId varchar(20) , CreatedOn TIMESTAMP ,unique (id,data,ClientUId,DCUId,EntityUId,WorkItemTypeUId))")
            else:
                logger.info('Table found!')
            
        except sqlite3.Error as e:
            logger.error("Error connecting to database!")
    
            
    """## Function to close a datbase connection."""
    def close_connection(self):
        
        if self.conn:
            
            self.cursor.close()
            self.conn.close()
            
    def splitkey(self,key):
        key_split = key.split('/')
        ClientUId = key_split[1]
        DCUId = key_split[2]
        EntityUId = key_split[3]
        WorkItemType = key_split[4]
        if len(key_split) > 5:
            keyname = key_split[5]
           
        else :
            keyname = "CNResponseDump"
        return ClientUId,DCUId,EntityUId,WorkItemType,keyname

    """ ## Function to fetch/query data from a database.
    """

    def get(self,key): 
        
        ClientUId,DCUId,EntityUId,WorkItemType ,keyname= self.splitkey(key)
        currentDateTime =parse(str(datetime.datetime.now()))
        #diff_time = datetime.timedelta(seconds=86400, microseconds=0)
        
        self.open_connection('dbcache.db')
        self.cursor.execute("SELECT data from ProductEntityTable where  ClientUId = ? and DCUId = ? and EntityUId=? and WorkItemTypeUId=? and id=? and datetime(CreatedOn) > datetime('now', '-24 Hour')",(str(ClientUId),json.dumps(DCUId),str(EntityUId),str(WorkItemType),keyname,) ) #DCUId=?,EntityUId=?,WorkItemType
        
        rows = self.cursor.fetchall()
        
        self.close_connection()
        # fetch data
        
        
        return rows
    
    """" ## Function to write data to the database.
    """
    
    def write(self,key,value):
        #method
        ClientUId,DCUId,EntityUId,WorkItemType ,keyname= self.splitkey(key)
        currentDateTime = datetime.datetime.now()
        #breakpoint()
        if keyname in ['StateUId', 'PriorityUId', 'TypeUId','State','Priority','Type']:
            self.open_connection('dbcache.db')
            self.cursor.execute("insert OR replace into ProductEntityTable values (?, ?,?,?,?,?,?) ", [keyname, json.dumps(value),str(ClientUId),json.dumps(DCUId),str(EntityUId),str(WorkItemType),currentDateTime])
            self.conn.commit()
            self.close_connection()
            
          
        else:
            self.open_connection('dbcache.db')
            for dict_item in value:
                
              #for key in dict_item:
                if "Name" in dict_item and dict_item["Name"] == "PriorityUId" :
                    #key = dict_item["DisplayName"]
                    key = "CNResponseDump"
                    self.cursor.execute("insert OR replace into ProductEntityTable values (?, ?,?,?,?,?,?) ", [key, json.dumps(dict_item),str(ClientUId),json.dumps(DCUId),str(EntityUId),str(WorkItemType),currentDateTime])
                    
                if "Name" in dict_item and dict_item["Name"] == "StateUId":
                    #key = dict_item["DisplayName"]
                    key = "CNResponseDump"
                    self.cursor.execute("insert OR replace into ProductEntityTable values (?, ?,?,?,?,?,?) ", [key, json.dumps(dict_item),str(ClientUId),json.dumps(DCUId),str(EntityUId),str(WorkItemType),currentDateTime])
                if "Name" in dict_item and dict_item["Name"] == "TypeUId":
                    #key = dict_item["DisplayName"]
                    key = "CNResponseDump"
                    self.cursor.execute("insert OR replace into ProductEntityTable values (?, ?,?,?,?,?,?) ", [key, json.dumps(dict_item),str(ClientUId),json.dumps(DCUId),str(EntityUId),str(WorkItemType),currentDateTime])
            self.conn.commit()
            self.close_connection()
            
           
            
            
           
        
        
        
    def exists(self,key):
         ClientUId,DCUId,EntityUId,WorkItemType ,keyname= self.splitkey(key)
         #To-do def read and write json test once
         self.open_connection('dbcache.db')
         self.cursor.execute("SELECT EXISTS(SELECT 1 from ProductEntityTable where  ClientUId = ? and DCUId = ? and EntityUId=? and WorkItemTypeUId=? and id=? and datetime(CreatedOn) > datetime('now', '-24 Hour'))",(str(ClientUId),json.dumps(DCUId),str(EntityUId),str(WorkItemType),keyname,) ) 
         rows = self.cursor.fetchall()
         found = True if (1,) in rows else False
         self.close_connection()
         return found 
     
        
     
         

class DBCacheManagerWrapper(): #DB remove
    """This class interfaces with 'wrapper class of DBcacheManager'. 
    Ensures a common ConnectionPool
    is used for all connection created from this class """
    pool = ConnectionPool.from_url(REDIS_URL)
    
    try:
        Redisobj=RedisConnection(pool) 
    except Exception as e:
        logger.error('Error Creating Redis Connection Object')
        Redisobj = None
    finally:
        try:
            dbobj=SQLiteDatabase()
        except Exception as e:
            #raise exception 
            dbobj= None
            logger.error('Error creating SQLite DB object')
    
    def __init__(self):
        
        if self.Redisobj is not None and self.dbobj is None:
            logger.warning("SQLite DB Object Creation fails")
        elif self.Redisobj is None and self.dbobj is not None:
            logger.warning("Redis Pool Connection fails") 
        elif self.Redisobj is  None and self.dbobj is None:
            logger.error("Both Redis and SQLite DB Object Creation fails")
            raise Exception
        else :
            logger.info("Both Objects are created")
        
    def set(self,key,value,ex=86000):
        redis_flag=1
        sql_flag = 1
        try:
            #set in redis
            
            self.Redisobj.set(key,json.dumps(value),ex=ex)
        except:
            #sys.excepthook = error_hook()
            redis_flag=0
            pass
        finally:
            #set in sqlite
            try:
                self.dbobj.write(key,value) 
            except:
                sql_flag=0
                logger.exception("Exception in setting data in db")
                tb = traceback.format_exc().split("\n")
                logger.error(tb)
                #raise Exception --add
        if not redis_flag and not sql_flag: #both set fails 
            logger.exception("Exception in setting data in both db and redis")
            tb = traceback.format_exc().split("\n")
            logger.error(tb)
          

            
    def get(self,key):
        """if in redis ,return value
	        else :
            look in sqllite db
            if found return value
            else :
            no key : return None """
        
        except_flag=0
        value=None
        try:
            value = self.Redisobj.get(key)
            if value:
                return ast.literal_eval(value) 
        except ValueError as e:
            except_flag=1
            logger.error("Malformed String.Unable to return from Redis")
            tb = traceback.format_exc().split("\n")
            logger.error(tb)
        
        except Exception as e:
            except_flag=1
            logger.error("Error connecting to Redis..Checking in DB")
            tb = traceback.format_exc().split("\n")
            logger.error(tb)
        if  value == None or except_flag == 1:
            try:
                value = self.dbobj.get(key)
                if value :
                    return ast.literal_eval(value[0][0])
                else:
                    return None
            except ValueError as e:
                except_flag=1
                logger.error("Malformed String.Unable to return from SQlite")
                tb = traceback.format_exc().split("\n")
                logger.error(tb)
                    
            except Exception as e: 
                logger.exception("Unknown exception while fetching data")
                tb = traceback.format_exc().split("\n")
                logger.error(tb)
            
    def exists(self,key):   
         except_flag=0
         found = False
         try:
             if self.Redisobj.exists(key) == 1:
                 found = True
                 return found 
         except Exception as e:
             except_flag=1
             logger.error("Error connecting to Redis..Checking in DB")
             tb = traceback.format_exc().split("\n")
             logger.error(tb)
         if found == False or except_flag==1:
             try:
                 found = self.dbobj.exists(key)
                 
             except Exception as e:
                 logger.error("Error connecting to DB")
                 tb = traceback.format_exc().split("\n")
                 logger.error(tb)
             return found 
            
    def pubsub(self,*args,**kwargs):
        # This is a redis pubsub method
        try:
            return self.Redisobj.pubsub(*args,**kwargs)
        
        except:
            logger.exception("Exception in calling pubsub method of redis")
            tb = traceback.format_exc().split("\n")
            logger.error(tb)

    def publish(self,*args,**kwargs):
        # This is a redis publish method
        try:
            return self.Redisobj.publish(*args,**kwargs)
        
        except:
            logger.exception("Exception while publishing to redis")
            tb = traceback.format_exc().split("\n")
            logger.error(tb)
    
    # def exists(self,*args,**kwargs):
    #     return self.Redisobj.exists(*args,**kwargs)
    
    def delete(self,*args,**kwargs):
        return self.Redisobj.delete(*args,**kwargs)

    def keys(self,*args,**kwargs):
        return self.Redisobj.keys(*args,**kwargs)
        
class CacheManager: 
    """This class interfaces with 'wrapper class of DBcacheManager'. 
    Ensures a common ConnectionPool
    is used for all connection created from this class
    """
    #pool = None
   
    wrapperobj = DBCacheManagerWrapper()
    def __init__(self):
        
        logger.info("Wrapper object created")
    @classmethod
    def connect(cls):
        if cls.wrapperobj is None:
            cls()
        
        return DBCacheManagerWrapper()
    def set(self,key,value,ex=86000):
        try:
            self.wrapperobj.set(key,value,ex)
            return True
        except Exception:
            return False
    def get(self,key):
        try:
            val=self.wrapperobj.get(key)
            return val
        except Exception:
            return None
        
    def exists(self,key):
        try:
            self.wrapperobj.exists(key)
            return True
        except Exception:
            return False

    
    



    
# class CacheManager:
#     """This class interfaces with 'redis' and 'sql'. Ensures a common ConnectionPool
#     is used for all connection created from this class
#     """
#     pool = None
#     def __init__(self):
#         try:
#             logger.info('Creating pool object')
#             CacheManager.pool = ConnectionPool.from_url(REDIS_URL)
#         except ValueError as e:
#             logger.error(
#                 f"Error occured while creating ConnectionPool. "
#                 f"Issue may be with redis URL configured. "
#                 f"Configured redis url: {REDIS_URL}")
#             raise e
#         except Exception as e:
#             logger.error('Unknown exception while creating "redis.ConnectionPool"')
#             raise e

#     @classmethod
#     def connect(cls):
#         if cls.pool is None:
#             cls()
        
#         return RedisConnection(CacheManager.pool)
   




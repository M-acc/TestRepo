from configparser import ConfigParser
import logging
from logging.handlers import RotatingFileHandler
import os, os.path
from cryptography.fernet import Fernet
import json
from ai_core.configs.file_encryptor import get_key_n_vec,read_json_file,get_arguments,AppDotJson,get_key_vec_from_local


from Crypto.Cipher import AES
from Crypto.Util import Padding
import base64

if __name__ == '__main__':
    from file_encryptor import get_configparser_obj, get_encryptor_key
else:
    from .file_encryptor import get_configparser_obj, get_encryptor_key
logger = logging.getLogger(__name__)
log_format = "%(asctime)s %(levelname)s] %(message)s [%(filename)s:%(funcName)s:%(lineno)d"
formatter = logging.Formatter(log_format)
# log output to console
HANDLER = logging.StreamHandler()
HANDLER.setFormatter(formatter)
LOG_LEVEL = logging.DEBUG

logger.addHandler(HANDLER)
logger.setLevel(LOG_LEVEL)

this_file_path = os.path.abspath(os.path.dirname(__file__))
conf_file = os.path.join(this_file_path, 'ai_core_configs.ini')
config = get_configparser_obj(conf_file)

logger.debug("Reading configuration values from: %s" %conf_file)
# Authentication schemes
AZURE_AD = 'AzureAD'
FORGEROCK = 'ForgeRock'
FORTRESS = 'Form'
WINDOWS_AUTH = 'WindowsAuthProvider'

# Grant types for Azure AD
GT_CLIENT_CREDENTIALS = "client_credentials"
GT_PASSWORD = "password"
AUTH_TYPE = config.get("auth_scheme", "authProvider")

ACCESS_TOKEN_URL = None

cloud, provider, files,secretKey , isCloudStorageKey = get_arguments(read_json_file("app.json"))

def get_key_and_vec_from_vault():
    # return aes_key ,aes_vector
    json_dict = read_json_file("app.json")
    cloud, provider, files,secretKey , isCloudStorageKey = get_arguments(json_dict)
    if cloud.lower() =="local":
        key,vec= get_key_vec_from_local()
    else:
        app_instance = AppDotJson(cloud=cloud, provider=provider, field=files, secretKey=secretKey)
        key,vec= get_key_n_vec(app_instance=app_instance)
        
    
    return key,vec

def encrypt_username(USERNAME):
    # key,vec=get_key_and_vec_from_vault()
    # encryption_key = base64.b64decode(key)
    # text = bytes(USERNAME,'utf-8')
    # text_padded = Padding.pad(text, AES.block_size)
    # iv = base64.b64decode(vec)
    # cipher = AES.new(encryption_key, AES.MODE_CBC, iv)
    # cipher_enc = cipher.encrypt(text_padded)
    # return base64.b64encode(cipher_enc).decode('ascii')
    return USERNAME

def encrypt_string(input_string):
    key,vec=get_key_and_vec_from_vault()
    encryption_key = base64.b64decode(key)
    text = bytes(input_string,'utf-8')
    text_padded = Padding.pad(text, AES.block_size)
    iv = base64.b64decode(vec)
    cipher = AES.new(encryption_key, AES.MODE_CBC, iv)
    cipher_enc = cipher.encrypt(text_padded)
    return base64.b64encode(cipher_enc).decode('ascii')

def decrypt(key, token):
    (bkey, btoken) = (key.encode("utf-8"), token.encode("utf-8"))
    f = Fernet(bkey)
    return f.decrypt(btoken)

if AUTH_TYPE == AZURE_AD:
    logger.debug("Using authentication scheme '%s'" %AUTH_TYPE)
    CLIENT_ID = config.get("azure_ad", "clientId")
    TENANT_ID = config.get("azure_ad", "tenantId")
    OPEN_ID_URL = config.get("azure_ad", "open_id_url")
    OPEN_ID_URL = OPEN_ID_URL.replace("{tenant}", TENANT_ID)
    PHOENIX_RESOURCE_ID = config.get("azure_ad", "resourceId")
    ACCESS_TOKEN_URL = config.get("azure_access_token", "url")
    ACCESS_TOKEN_URL = ACCESS_TOKEN_URL.replace("{tenant}", TENANT_ID)
    GRANT_TYPE = config.get("azure_ad", "grant_type")
    SECRET_KEY = config.get("azure_ad", "clientSecret")
    AUDIENCE = config.get("azure_ad", "audience")
    ISSUER = config.get("azure_ad", "issuer")
elif AUTH_TYPE == FORGEROCK:
    logger.debug("Using authentication scheme '%s'" %AUTH_TYPE)
    CLIENT_ID = config.get("forgerock", "clientId")
    PHOENIX_RESOURCE_ID = config.get("forgerock", "resourceId")
    #PHOENIX_RESOURCE_ID = None
    GRANT_TYPE = config.get("forgerock", "grant_type")
    SECRET_KEY = config.get("forgerock", "clientSecret")
    ISSUER = config.get("forgerock", "issuer")
    ACCESS_TOKEN_URL = config.get("forgerock_access_token", "url")
    AUDIENCE = config.get("forgerock", "audience")
    OPEN_ID_URL = config.get("forgerock", "open_id_url")
elif AUTH_TYPE == FORTRESS:
    logger.debug("Using authentication scheme '%s'" %AUTH_TYPE)
    ACCESS_TOKEN_URL = config.get("fortress_access_token", "tokenAPIUri")
    PHOENIX_RESOURCE_ID = None
    SECRET_KEY = config.get("fortress", "clientSecret")
    AUDIENCE = config.get("fortress", "audience")
    ISSUER = config.get("fortress", "issuer")
elif AUTH_TYPE == WINDOWS_AUTH:
    logger.debug("Using authentication scheme '%s'" %AUTH_TYPE)
    ACCESS_TOKEN_URL = None
    PHOENIX_RESOURCE_ID = None
    SECRET_KEY = None
    AUDIENCE = None
    ISSUER = None
    
# common attributes for any auth_type
logger.debug("Setting values from 'security' section")

ALGORITHMS = config.get("security", "algorithms").split(
        config.get("others", "value_separator"))
KEY = config.get("security", "app_key")
USERNAME = config.get("security", "username")
USERNAME_ENC = encrypt_username(USERNAME=USERNAME)
KEY_GPT3 = config.get("security", "key_gpt3")
KEY_GPT4 = config.get("security", "key_gpt4")
# KEY_GPT3_ENC = encrypt_string(KEY_GPT3)
# KEY_GPT4_ENC = encrypt_string(KEY_GPT4)
PASSWORD = config.get("security", "password")
MYWIZARD_SYSDATA_ADMIN = config.get("security", "mywizard_sysdata_admin")
MYWIZARD_SYSDATA_ADMIN_ENC = encrypt_username(USERNAME=MYWIZARD_SYSDATA_ADMIN)

is_encrypted = int(config.get("security", "credentials_encrypted"))
if is_encrypted:
    USERNAME = decrypt(KEY, USERNAME)
    USERNAME_ENC=encrypt_username(USERNAME=USERNAME)
    PASSWORD = decrypt(KEY, PASSWORD)
    MYWIZARD_SYSDATA_ADMIN = decrypt(KEY, MYWIZARD_SYSDATA_ADMIN)
    MYWIZARD_SYSDATA_ADMIN_ENC = encrypt_username(USERNAME=MYWIZARD_SYSDATA_ADMIN)

logger.debug("Setting values from 'phoenix_api_urls' section")
DOMAIN = config.get('phoenix_api_urls', 'domain')
DOMAIN = DOMAIN.rstrip('/') # remove excess '/' if any
DOMAIN += '/'
WORKITEM_URL = DOMAIN + config.get("phoenix_api_urls", "workitem").lstrip('/')
REQUIREMENT_URL = DOMAIN + config.get("phoenix_api_urls", "requirement").lstrip('/')
MSF_URL = DOMAIN + config.get("phoenix_api_urls", "MilestonesForecast").lstrip('/')
WorkItems = DOMAIN + config.get("phoenix_api_urls", "WorkItems").lstrip('/')
Requirements = DOMAIN + config.get("phoenix_api_urls", "Requirements").lstrip('/')
Milestones = DOMAIN + config.get("phoenix_api_urls", "Milestones").lstrip('/')
Deliverables = DOMAIN + config.get("phoenix_api_urls", "Deliverables").lstrip('/')
Iterations = DOMAIN + config.get("phoenix_api_urls", "Iterations").lstrip('/')
Risks = DOMAIN + config.get("phoenix_api_urls", "Risks").lstrip('/')
Issues = DOMAIN + config.get("phoenix_api_urls", "Issues").lstrip('/')
Defects = DOMAIN + config.get("phoenix_api_urls", "Defects").lstrip('/')

find_dependency = DOMAIN + config.get("phoenix_api_urls", "GetDependency").lstrip('/')
USER_STORY_TYPE_UID = config.get("workitem_type_uid","user_story")
EPIC_TYPE_UID = config.get("workitem_type_uid","epic")

if AUTH_TYPE == FORTRESS:
    ACCESS_TOKEN_URL = DOMAIN + ACCESS_TOKEN_URL
    
logger.debug("Setting values from 'get_language' section")
get_language_api = config.get("get_language","get_language_api")

logger.debug("Setting values from 'others' section")
APP_SERVICE_UID = config.get("others","appServiceUid")
CONNECT_TIMEOUT = float(config.get("others", "connect_timeout"))
READ_TIMEOUT = float(config.get("others", "read_timeout"))
ITERATION_ENTITY_UID  = config.get("others","iteration_entity_uid")
DELIVERABLE_ENTITY_UID = config.get("others","deliverable_entity_uid")
MILESTONE_ENTITY_UID = config.get("others","milestone_entity_uid")
NORTHSTAR_ENTITY_UID=config.get("others","northstar_entity_uid")
REQUIREMENT_ENTITY_UID = config.get("others","requirement_entity_uid")
WORKITEM_ENTITY_UID = config.get("others","workitem_entity_uid")
CATEGORY_ENTITY_UID = config.get("others","category_entity_uid")
KPI_ENITY_UID=config.get("others","kpi_enity_uid")
APP_NAME = config.get("others","app_name")
MAX_RETRY = int(config.get("others","retry"))



ACCEPTED_RECOMMENDATION_STATE_UID = config.get("recommendation_state_uid","accepted_recommendation_state_uid")
DRAFT_RECOMMENDATION_STATE_UID = config.get("recommendation_state_uid","draft_recommendation_state_uid")



CATEGORY_RECOMMENDATION_UID = config.get("recommendation_type_uids","category_recommendation_uid")
NORTHSTAR_RECOMMENDATION_UID = config.get("recommendation_type_uids","northstar_recommendation_uid")
ITKPI_RECOMMENDATION_UID = config.get("recommendation_type_uids","itkpi_recommendation_uid")
BIZKPI_RECOMMENDATION_UID = config.get("recommendation_type_uids","bizkpi_recommendation_uid")

logger.debug("setting values from 'row_status_uid' section")
ACTIVE_ROWSTATUS_UID = config.get('row_status_uids', 'active')
INACTIVE_ROWSTATUS_UID = config.get('row_status_uids', 'inactive')

logger.debug("Setting values from 'ignore_dcs' section")
IGNORE_DC_LIST = config.get('ignore_dcs', 'dcs').split(
        config.get('others', 'value_separator'))


WORKITEM_MERGE_URL = DOMAIN +config.get("phoenix_api_urls","WorkItems_Merge").lstrip('/')
REQUIREMENT_MERGE_URL = DOMAIN +config.get("phoenix_api_urls","Requirement_Merge").lstrip('/')
WORKITEM_QUERY_URL = DOMAIN +config.get("phoenix_api_urls","Workitem_Query").lstrip('/')
REQUIREMENT_QUERY_URL = DOMAIN +config.get("phoenix_api_urls","Requirement_Query").lstrip('/')
CATEGORY_QUERY_URL = DOMAIN + config.get("phoenix_api_urls","Category_Query").lstrip('/')
CATEGORY_FLAT_URL= DOMAIN + config.get("phoenix_api_urls","Category_Flat").lstrip('/')
CATEGORY_MERGE_URL= DOMAIN + config.get("phoenix_api_urls","Category_Merge").lstrip('/')
EX_QUERY_URL= DOMAIN + config.get("phoenix_api_urls","exclusion_query_url").lstrip('/')
SINGULAR_MERGE_URL = DOMAIN + config.get("phoenix_api_urls", "SINGULAR_MERGE_URL").lstrip('/')
PLURAL_MERGE_URL = DOMAIN + config.get("phoenix_api_urls", "PLURAL_MERGE_URL").lstrip('/')
GetAccountClientDeliveryConstructs = DOMAIN + config.get("phoenix_api_urls", "GetAccountClientDeliveryConstructs").lstrip('/')
ProductEntityClientPropertyValues = DOMAIN + config.get("phoenix_api_urls", "ProductEntityClientPropertyValues").lstrip('/')
GetDependency = DOMAIN + config.get("phoenix_api_urls", "GetDependency").lstrip('/')
RRA = DOMAIN + config.get("phoenix_api_urls", "RRA").lstrip('/')
# HADOOP_DOMAIN = config.get('phoenix_api_urls', 'HadoopApiDomain')
# HADOOP_DOMAIN = HADOOP_DOMAIN.rstrip('/') # remove excess '/' if any
HADOOP_DOMAIN = '/'



BATCH_SIZE = int(config.get("others","batch_size"))

get_language_vp_api = config.get("get_language","get_language_api")

logger.debug("Setting values from 'async' section")
THREAD_BATCH_COUNT = int(config.get("async", "thread_batch_count"))
WAIT_TIME = int(config.get("async", "wait_time"))

logger.debug("Setting values from 'database' section")
CONNECTION_STRING = config.get("database", "connectionString")
CERTIFICATE_PATH = config.get("database", "certificatePath")
CERTIFICATE_CA_PATH = config.get("database", "certificateCAPath")
# TrainEDAUsecases = config.get("rsp_dotnet_api","TrainEDAUsecases").rstrip("/")
# TrainEDAUsecases +='/'
# TrainEDAUsecases = DOMAIN + TrainEDAUsecases
# RunEDA = config.get("rsp_dotnet_api","RunEDA").rstrip("/")
# RunEDA   = DOMAIN + RunEDA
# SaveReleaseInfo = DOMAIN + config.get("rsp_dotnet_api", "SaveReleaseInfo").lstrip('/')
# PushViabilityScoreEntityRecommendation = config.get("rsp_dotnet_api","PushViabilityScoreEntityRecommendation").rstrip("/")
# PushViabilityScoreEntityRecommendation = DOMAIN + PushViabilityScoreEntityRecommendation + '/'
# GetRefreshedReleaseList = config.get("rsp_dotnet_api","GetRefreshedReleaseList").rstrip("/")
# GetRefreshedReleaseList = DOMAIN + GetRefreshedReleaseList
# PostEDA_BufferTime = int(config.get("rsp_dotnet_api", "posteda_buffertime"))

logger.debug("Setting values from 'redis_cache' section")
REDIS_URL = config.get('redis_cache', 'redis_url')
HEALTH_CHECK_INTERVAL = int(config.get('redis_cache', 'health_check_interval'))
EXPIRES = int(config.get('redis_cache', 'expires'))

if ACCESS_TOKEN_URL is None and AUTH_TYPE != WINDOWS_AUTH:
    logger.error("'url' value NOT set in either [azure/fortres_access_token]"
    "section of the cofiguration file. Set to proceed. Raising error.")
    raise ValueError(
            "Incorrect 'auth_scheme' value. Provide correct value in "
            "'ai_core_configs.ini' file")


if __name__ == '__main__':
    print(WAIT_TIME)
    
    

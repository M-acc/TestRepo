import io
import os
import sys
import json
import boto3
import base64
import logging
from os import stat
from io import BytesIO
import pyAesCrypt as pac
from binaryornot.check import is_binary
from inspect import Parameter, Signature
from botocore.exceptions import ClientError
from azure.keyvault.secrets import SecretClient
from azure.identity import DefaultAzureCredential
from configparser import ConfigParser, ExtendedInterpolation
import xml.etree.ElementTree as ET
# from settings import LOCAL_PROVIDER_PATH
from azure.core.exceptions import (
    ClientAuthenticationError,
    HttpResponseError,
    ServiceRequestError,
    ResourceNotFoundError,
    AzureError
)
import re

# this_file_path = os.path.abspath(os.path.dirname(__file__))
# conf_file = os.path.join(this_file_path, 'ai_core_configs.ini')
# config = get_configparser_obj(conf_file)
log_format = '%(asctime)s %(levelname)s] %(message)s [%(filename)s:%(funcName)s:%(lineno)d'
log_file_name = 'encrypt.log'
max_log_bytes = 5000000
backups = 5
log_level = 20
bufferSize = 64 * 1024
# LOCAL_PROVIDER_PATH = config.get("others","local_provider_path")
LOCAL_PROVIDER_PATH = "/etc/systemd/system/MyWIzard/Cryptography.xml"


_fields = ['Type', 'Provider', 'Fields']
params = [ Parameter(fname, Parameter.POSITIONAL_OR_KEYWORD) for fname in _fields]
sig = Signature(params)

def logging_func():
    logger = logging.getLogger(__name__)
    formatter = logging.Formatter(log_format)

    # log to console
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)

    # logger.addHandler(HANDLER)
    logger.addHandler(console_handler)
    logger.setLevel(log_level)
    return logger

logger=logging_func()
#setting the logging level to the below libraries to ERROR, as it is flooding the logfile with unnecessary content, 
#we can diable them too , instead set to ERROR so that we dont miss any important error messages from that module
for log_name, log_obj in logger.manager.loggerDict.items():
    if isinstance(log_obj,logging.Logger):
        for i in ['botocore','binaryornot','azure','chardet']:
            if i in log_name:
                log_obj.setLevel("ERROR")


class Error(Exception):
    pass

class NoResponseFromServiceProvider(Error):
    pass

class ParameterErrorForAzure(Error):
    pass

class ClientErrorForAWS(Error):
    pass

class ProviderError(Error):
    pass

def get_arguments(json_dict):
    err = "Please provide credentials for %s"
    provider = None
    files = None
    cloud = json_dict['Type']
    try:
        files = json_dict['Files']
        # breakpoint()
        isCloudStorageKey = json_dict['Files'][0]['IsCloudKeyStorage'] if 'IsCloudKeyStorage' in json_dict['Files'][0] else "false"
        if isCloudStorageKey == "true" or isCloudStorageKey == "True" :
            if cloud == 'AWS':
                provider = json_dict['AWSSecretManagerProvider']
                secretKey = json_dict['SecretKeyProvider']
            elif cloud == 'Azure':
                provider = json_dict['AzureKeyVaultProvider']
                secretKey = json_dict['SecretKeyProvider']
        else:
            cloud ="local"
            provider =""
            secretKey=""
            # print("yes")
        
        if provider is None:
            raise ProviderError

    except ProviderError:
        logger.error('No valid cloud service provider')
    except KeyError:
        logger.error(KeyError)
    except:
        logger.error(err % cloud)

    return cloud, provider, files , secretKey , isCloudStorageKey

class AppDotJson:
    def __init__(self, *,cloud, provider, field,secretKey):
        # breakpoint
        self.cloud = cloud
        self.provider = provider
        self.field = field
        self.secretKey =secretKey
        if self.cloud == 'AWS':
            self.region = self.provider['Region']
            self.secretname = self.provider['SecretName']
            self.version = self.provider['Version']
        elif self.cloud == 'Azure':
            self.uri = self.provider['KeyVaultUri']
            self.useridentity = self.provider['UserAssignedManagedIdentity']

def _verify_path_(path):
    '''
    verify the given path
    '''
    path = os.path.abspath(path)
    logger.debug(f"verifying path: {path}")
    file_exists = os.path.exists(path)
    pdir = os.path.dirname(path)
    dir_exists = os.path.exists(pdir)
    # breakpoint()
    logger.debug(f"its stats: file_exists: {file_exists}, dir_exists: {dir_exists}")
    return file_exists, dir_exists

def get_key_azure(*,uri, useridentity,secretKey):
    key = None
    try:
        # secretName = 'secretName'
        secretName=secretKey['KeyName']
        credential = DefaultAzureCredential(managed_identity_client_id=useridentity)
        client = SecretClient(vault_url=uri, credential=credential)
        try:
            key = client.get_secret(secretName).value
        except:
            raise ParameterErrorForAzure

    except ClientAuthenticationError as e:
        # Can occur if either tenant_id, client_id or client_secret is incorrect
        logger.critical("Azure SDK was not able to connect to Key Vault", e)
    except HttpResponseError as e:
        # Key Vault Name may be incorrect
        logger.critical("Possible wrong Vault name given", e)
    except ServiceRequestError:
        # Network error
        raise
    except ResourceNotFoundError as e:
        logger.error('Azure key vault you are trying to connect is not found')
        pass
    except AzureError as e:
        logger.critical("Azure SDK was not able to deal with the query", e)
    except ParameterErrorForAzure:
        logger.error('Wrong parameter is entered')
    except Exception as e:
        logger.error('Unknown error')

    return key

def get_key_aws(*,region_name, SecretName, api_version):
    
    import ast
    key = None
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    try:
        response = client.get_secret_value(SecretId=SecretName, VersionStage=api_version)
        response = response['SecretString']
        response  = ast.literal_eval(response)
        if 'Aes_Key' in response:
            key = response['Aes_Key']
        else:
            key = base64.b64decode(response['Aes_Key'])
            key = json.loads(key)
    except:
            logger.error('Authentication failed or missing required parameters, please check.')
    return key

def get_key(*,app_instance):
    key = None
    #exception class
    # provider exception
    # no key is provided from cloud services
    
    err = "cloud service provider %s"
    cloud = app_instance.cloud
    try:
        if cloud == 'AWS':
            region = app_instance.region
            secretname = app_instance.secretname
            api_version = app_instance.version
            key = get_key_aws(region_name=region, SecretName=secretname,
                                            api_version = api_version)
        elif cloud == 'Azure':
            uri = app_instance.uri
            useridentity = app_instance.useridentity
            secretKey = app_instance.secretKey

            key = get_key_azure(uri= uri, useridentity=useridentity,secretKey=secretKey)
        else:
            raise ProviderError

        if key == None:
            raise NoResponseFromServiceProvider
        return key

    except ProviderError:
        logger.error('Invalid cloud service provider, please provide a valid value')

    except NoResponseFromServiceProvider:
        logger.error(f"No response from cloud service provider {cloud}, please check the credentials and arguments passed!")
    # except:
    #     logger.error(err % type)
        # raise UnboundLocalError (err % type)

def get_key_n_vec(*,app_instance):
    key = None
    #exception class
    # provider exception
    # no key is provided from cloud services
    # breakpoint()
    err = "cloud service provider %s"
    cloud = app_instance.cloud
    try:
        if cloud == 'AWS':
            region = app_instance.region
            secretname = app_instance.secretname
            api_version = app_instance.version
            key,vec = get_key_n_vec_aws(region_name=region, SecretName=secretname,
                                            api_version = api_version)
        elif cloud == 'Azure':
            uri = app_instance.uri
            useridentity = app_instance.useridentity
            secretKey = app_instance.secretKey
            # breakpoint()
            key,vec = get_key_n_vec_azure(uri= uri, useridentity=useridentity,secretKey=secretKey)
        else:
            raise ProviderError

        if key == None:
            raise NoResponseFromServiceProvider
        return key,vec

    except ProviderError:
        logger.error('Invalid cloud service provider, please provide a valid value')

    except NoResponseFromServiceProvider:
        logger.error(f"No response from cloud service provider {cloud}, please check the credentials and arguments passed!")

def get_key_n_vec_azure(*,uri, useridentity,secretKey):
    key = None
    vec = None 
    # breakpoint()
    try:
        # secretName = 'secretName'
        secretName=secretKey['KeyName']
        vecName=secretKey['VectorName']
        credential = DefaultAzureCredential(managed_identity_client_id=useridentity)
        client = SecretClient(vault_url=uri, credential=credential)
        # breakpoint()
        try:
            key = client.get_secret(secretName).value
            vec = client.get_secret(vecName).value
        except:
            raise ParameterErrorForAzure

    except ClientAuthenticationError as e:
        # Can occur if either tenant_id, client_id or client_secret is incorrect
        logger.critical("Azure SDK was not able to connect to Key Vault", e)
    except HttpResponseError as e:
        # Key Vault Name may be incorrect
        logger.critical("Possible wrong Vault name given", e)
    except ServiceRequestError:
        # Network error
        raise
    except ResourceNotFoundError as e:
        logger.error('Azure key vault you are trying to connect is not found')
        pass
    except AzureError as e:
        logger.critical("Azure SDK was not able to deal with the query", e)
    except ParameterErrorForAzure:
        logger.error('Wrong parameter is entered')
    except Exception as e:
        logger.error('Unknown error')

    return key,vec

def get_key_n_vec_aws(*,region_name, SecretName, api_version):
    
    import ast
    key = None
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    try:
        response = client.get_secret_value(SecretId=SecretName, VersionStage=api_version)
        response = response['SecretString']
        response  = ast.literal_eval(response)
        if 'Aes_Key' in response:
            key = response['Aes_Key']
            vec = response['Aes_Vector']
        else:
            key = base64.b64decode(response['Aes_Key'])
            key = json.loads(key)
            vec = base64.b64decode(response['Aes_Vector'])
            vec = json.loads(vec)
        return key,vec

    except:
            logger.error('Authentication failed or missing required parameters, please check.')
    

def read_json_file(app_dot_json):
    json_dict = None
    with open(app_dot_json) as fh:
        json_dict = json.load(fh)
    logger.debug(f"read app.json, its content: {json_dict}")
    return json_dict

def _validate_app_dot_json_(json_dict):
    '''
    validate contents of app.json
    '''
    fextention = ".replaceme"
    err_msg = "No such file or directory: %s"
    err_cloud = "Please provide credentials for %s"
    if json_dict['Type']:
        if json_dict['Type'] == 'AWS':
            aws_list = set(['Region','SecretName','Version'])
            if 'AWSSecretManagerProvider' in json_dict:
                aws_dict = json_dict['AWSSecretManagerProvider']
                if not aws_list.issubset(aws_dict.keys()):
                    raise KeyError(err_cloud % json_dict['Type'])
            else:
                raise KeyError(err_cloud % json_dict['Type'])
        elif json_dict['Type'] == 'Azure':
            azure_list = set(['KeyVaultUri','UserAssignedManagedIdentity'])
            if 'AzureKeyVaultProvider' in json_dict:
                azure_dict = json_dict['AzureKeyVaultProvider']
                if not azure_list.issubset(azure_dict.keys()):
                    raise KeyError(err_cloud % json_dict['Type'])
            else:
                raise KeyError(err_cloud % json_dict['Type'])

        for i, file in enumerate(json_dict['Files']):
            file_exist, dir_exist = _verify_path_(file['SourceFilePath'])
            if not file_exist:
                logger.error(err_msg % file["SourceFilePath"])
                raise FileNotFoundError(err_msg % file["SourceFilePath"])
            file['SourceFilePath'] = os.path.abspath(file['SourceFilePath'])

            if "DestinationFilePath" in file:
                f_exists, d_exists = _verify_path_(file["DestinationFilePath"])
                if not d_exists:
                    raise FileNotFoundError(err_msg % file["DestinationFilePath"])
                file["DestinationFilePath"] = os.path.abspath(file["DestinationFilePath"])
            else:
                logger.warning("No 'DestinationFilePath' provided, 'SourceFilePath' will be overwritten")
                file["DestinationFilePath"] = os.path.abspath(file["SourceFilePath"]) + fextention
                #file["DestinationFilePath"] = os.path.abspath(file["SourceFilePath"])
                #file['SourceFilePath'] = os.path.abspath(file['SourceFilePath']) + fextention
            logger.info("'app.json', is valid")
    else:
        logger.critical("Please check if the App.json input is correct")


def convert(app_dot_json, operation):
    fextention = ".replaceme"
    
    try:
        json_dict = read_json_file(app_dot_json)
        logger.debug(f"validating file {app_dot_json}")
        try:
            cloud, provider, files , secretKey ,isCloudStorageKey = get_arguments(json_dict)

            # if cloud != "local":

            app_instance = AppDotJson(cloud=cloud, provider=provider, field=files, secretKey=secretKey)
            _validate_app_dot_json_(json_dict)
            config_file = json_dict['Files'][0]['SourceFilePath']
            # breakpoint()
            location_app_dot_json = os.path.dirname(os.path.abspath(app_dot_json))
            app_dot_json = os.path.join(location_app_dot_json, 'app.json')
            passw = get_encryptor_key(app_dot_json)
            
            if passw:
                for d in json_dict["Files"]:
                    if operation == 'encrypt':
                        if is_binary(d['SourceFilePath']):
                            logger.info("files are already encrypted since it is already a binary file")
                            continue
                        logger.info("creating encrypted file")
                        pac.encryptFile(d["SourceFilePath"], d["DestinationFilePath"], passw, bufferSize)
                        logger.debug("done")
                    elif operation == 'decrypt':
                        if  not is_binary(d['SourceFilePath']):
                            logger.info(f"{d['SourceFilePath']} is a plain text file , hence not decrypting")
                            continue
                        
                        logger.info("creating decrypted file")
                        pac.decryptFile(d["SourceFilePath"], d["DestinationFilePath"], passw, bufferSize)
                        logger.debug("done")
                    if fextention in d["DestinationFilePath"]:
                        logger.debug("renaming %s to %s" % (d["DestinationFilePath"], d["SourceFilePath"]))
                        os.remove(d["SourceFilePath"])
                        os.rename(d["DestinationFilePath"], d["SourceFilePath"])
                        logger.debug("done")
            else:
                logger.critical("Operation failed")
        except:
            logger.critical('Please check the content of app.json input file.')

    except IOError as e:
        logger.error(e)
        # raise IOError(e)
    except FileNotFoundError as e:
        logger.error('FileNotFoundError: %s' %str(e))
    except ValueError as e:
        logger.error(e)
        # raise ValueError(e)
    except PermissionError as e:
        logger.error(e)

def decrypt_file(infile, passw):
    output = None
    with open(infile, "rb") as efh:
        decrypt_stream = BytesIO()
        input_fsize = stat(infile).st_size
        pac.decryptStream(
                efh, decrypt_stream, passw, bufferSize, input_fsize)
        bytes_stream = decrypt_stream.getvalue()
        output = bytes_stream.decode('utf-8')
    return output

def get_key_vec_from_local():
    path = LOCAL_PROVIDER_PATH
    if os.path.exists(path):
        tree = ET.parse(path)
        root=tree.getroot()
        # print("yes")
        for elem in root:
            if elem.tag == 'Aes':
                for var in elem:
                    if var.tag == "Key":
                        key = var.text
                    if var.tag =="Vector":
                        vec = var.text
        return key,vec
    else:
        logger.critical("File Not found -Local Path")
        raise FileNotFoundError("local path - cryptography file not found") 
    
def get_key_from_local():
    # print("yes1")
    path = LOCAL_PROVIDER_PATH

    if os.path.exists(path):
    # path="/mnt/c/AI Core/AutomationProcess_29697/DEV/AI_Core_Services/precompute-R4.6/Cryptography.xml"
    # if 
        tree = ET.parse(path)
        root=tree.getroot()

        # for item in root:
        #     if item.tag=="Aes":
        #         return item
        # print("yes")
        # name = 'input2'
        for elem in root:
            if elem.tag == 'Aes':
                for var in elem:
                    if var.tag == "Key":
                        return var.text
    else :
        logger.critical("Local File Path not found")
        raise FileNotFoundError("local path file - cryptography file not found")

def get_openai_key_aws(*,region_name, SecretName, api_version):
    import ast
    key = None
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    try:
        response = client.get_secret_value(SecretId=SecretName, VersionStage=api_version)
        response = response['SecretString']
        response  = ast.literal_eval(response)

        open_ai_keys={}
        for i,j in response.items():
            if i.startswith("openai"):
                open_ai_keys[i]=j
        
        logger.info(f"Open ai key dict from aws {open_ai_keys}")
        return open_ai_keys

    except:
            logger.error('Authentication failed or missing required parameters, please check.')


def get_openai_key_azure(*,uri, useridentity,secretKey):
    key = None
    value =None
    vec = None 
    # breakpoint()
    try:
        # secretName = 'secretName'
        # secretName=secretKey['KeyName']
        # vecName=secretKey['VectorName']
        credential = DefaultAzureCredential(managed_identity_client_id=useridentity)
        client = SecretClient(vault_url=uri, credential=credential)
        # breakpoint()
        try:
            secret_properties = client.list_properties_of_secrets()
            open_ai_keys={}
            for secret in secret_properties:
                key=secret.name
                if key.startswith("openai"):
                    value=client.get_secret(secret).value
                    open_ai_keys[secret]=value
            # key = client.get_secret(secretName).value
            # vec = client.get_secret(vecName).value
            logger.info(f"Open ai key dict from azure {open_ai_keys}")
        except:
            raise ParameterErrorForAzure

    except ClientAuthenticationError as e:
        # Can occur if either tenant_id, client_id or client_secret is incorrect
        logger.critical("Azure SDK was not able to connect to Key Vault", e)
    except HttpResponseError as e:
        # Key Vault Name may be incorrect
        logger.critical("Possible wrong Vault name given", e)
    except ServiceRequestError:
        # Network error
        logger.error('Service request error')
    except ResourceNotFoundError as e:
        logger.error('Azure key vault you are trying to connect is not found')
    except AzureError as e:
        logger.critical("Azure SDK was not able to deal with the query", e)
    except ParameterErrorForAzure:
        logger.error('Wrong parameter is entered')
    except Exception as e:
        logger.error('Unknown error')

    return open_ai_keys

def get_OpenAI_key(*,app_instance):
    open_ai_keys = {}
    #exception class
    # provider exception
    # no key is provided from cloud services
    # breakpoint()
    err = "cloud service provider %s"
    cloud = app_instance.cloud
    try:
        if cloud == 'AWS':
            region = app_instance.region
            secretname = app_instance.secretname
            api_version = app_instance.version
            open_ai_keys = get_openai_key_aws(region_name=region, SecretName=secretname,
                                            api_version = api_version)
        elif cloud == 'Azure':
            uri = app_instance.uri
            useridentity = app_instance.useridentity
            secretKey = app_instance.secretKey
            # breakpoint()
            open_ai_keys= get_openai_key_azure(uri= uri, useridentity=useridentity,secretKey=secretKey)
        else:
            raise ProviderError

        if len(open_ai_keys) == 0 or open_ai_keys is None:
            raise NoResponseFromServiceProvider
        return open_ai_keys

    except ProviderError:
        logger.error('Invalid cloud service provider, please provide a valid value')

    except NoResponseFromServiceProvider:
        logger.error(f"No response from cloud service provider {cloud}, please check the credentials and arguments passed!")



def get_encryptor_key(app_dot_json):
    app_dot_json = os.path.abspath(app_dot_json)
    dir_name = os.path.dirname(app_dot_json)
    json_dict = read_json_file(app_dot_json)
    cloud, provider, files , secretKey ,isCloudStoragekey = get_arguments(json_dict)
    print("yes")
    if cloud =="local":
        print("yes")
        passw= get_key_from_local()
    else:
        app_instance = AppDotJson(cloud=cloud , provider=provider, field=files, secretKey=secretKey)
        passw = get_key(app_instance=app_instance)
    return passw

def get_configparser_obj(infile):
    """
    Helper method to get 'configparser' obj from '*.ini' file. Configuration
    file can either encrypted one or plain text.
    If the configuration is encrypted, it assumes 'app.json' file in the same
    location as param:infile. Uses 'app_name' key from the file to construct
    filename of the 'key' file, containing key to decrypt.

    param: infile, absolute path of configuration file(.ini)
    """
    try:
        if is_binary(infile):
            dir_name = os.path.abspath(os.path.dirname(infile))
            app_dot_json = os.path.join(dir_name, 'app.json')
            logger.info(f"{infile}: is encrypted. Decoding using key from {app_dot_json}" )
            passw = get_encryptor_key(app_dot_json)
            output = decrypt_file(infile, passw)
            fh = io.StringIO(output)
        else:
            logger.info(f"{infile}: is a plain text file")
            fh = open(infile, "r",encoding="utf-8")
        cp = ConfigParser(interpolation=ExtendedInterpolation())
        logger.debug("constructed 'configparser' obj, reading configuration")
        cp.read_file(fh)
        fh.close()
        return cp
    except ValueError as e:
        logger.error(e)
        raise ValueError(e)
    except FileNotFoundError as e:
        logger.error(e)
        raise FileNotFoundError(e)
    except PermissionError as e:
        logger.error(e)
        raise PermissionError(e)

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        prog='file_encryptor',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description='''
File Encryptor
--------------
    A wrapper arround 'pyAesCrypt' python module, to encrypt/decrypt
    list of files supplied via 'app.json' input file.
    --------------------
    'app.json' structure
    --------------------
    {
        "app_name": "APP_NAME",
        "files_to_encrypt":[
            {
                "input": "/path/to/file_2b_encrypted",
                "output: "/path/of/encrypted_file",
            },
            ...
        ]
    }

    Note:
    -----
    - "output" is optional, if absent, "input" file will be overwritten with
        encrypted content
    - "app_name", any valid one-word string
'''
    )
    parser.add_argument(
        '-e', '--encrypt', dest='in_encrypt', metavar='app_dot_json',
        help="'app.json', a JSON file containing files to be encrypted",
        nargs=1, default=None)
    parser.add_argument(
        '-d', '--decrypt', dest='in_decrypt', metavar='app_dot_json',
        help="'app.json', a JSON file containing files to be decrypted. \
                Mostly the same file that was supplied with '-e' option. \
                If 'output' was used in 'app.json', you will want to swap\
                'input' & 'output' key values.",
        nargs=1, default=None)

    args = parser.parse_args()
    if args.in_encrypt:
        convert(args.in_encrypt[0], 'encrypt')
    elif args.in_decrypt:
        convert(args.in_decrypt[0], 'decrypt')
    else:
        parser.print_help()
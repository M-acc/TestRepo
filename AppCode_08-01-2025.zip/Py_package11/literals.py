"""
This file contains literals which are either Entity, its attributes
or Pre-Compute components collection's attributes
"""

# Fabric specific
RequirementDeliveryConstructs = 'RequirementDeliveryConstructs'
RequirementDeliveryConstructUId = 'RequirementDeliveryConstructUId'
RequirementUId = 'RequirementUId'
RequirementTypeUId = 'RequirementTypeUId'

WorkItemDeliveryConstructs = 'WorkItemDeliveryConstructs'
WorkItemDeliveryConstructUId = 'WorkItemDeliveryConstructUId'
WorkItemUId = 'WorkItemUId'
WorkItemTypeUId = 'WorkItemTypeUId'
EntityEventMessageParams = 'EntityEventMessageParams'

NorthStarDeliveryConstructs = 'NorthStarDeliveryConstructs'
NorthStarDeliveryConstructUId = 'NorthStarDeliveryConstructUId'
NorthStarUId = 'NorthStarUId'

KPIDeliveryConstructs = 'KPIDeliveryConstructs'
KPIDeliveryConstructUId = 'KPIDeliveryConstructUId'
KPIUId = 'KPIUId'

#   common to both NorthStar & KPI
TypeUId = 'TypeUId'

ClientUId = 'ClientUId'
DeliveryConstructUId = 'DeliveryConstructUid'
CorrelationUId = 'CorrelationUId'
ItemUId = 'ItemUId'
EntityUId = 'EntityUId'
EntityTypeUId = 'EntityTypeUId'
RowStatusUId = 'RowStatusUId'
ModifiedAtSourceOn = 'ModifiedAtSourceOn'
CreatedOn = 'CreatedOn'
ModifiedOn = 'ModifiedOn'
Title = 'Title'
Description = 'Description'
CallbackLink = 'CallbackLink'
SenderApp = 'SenderApp'
RetryAttempt = 'RetryAttempt'
OutputPayload = 'OutputPayload'
InputPayload = 'InputPayload'
Status = 'Status'
EventType = 'EventType'
Ignore = 'Ignore'
IsInternalUpdateOnly = 'IsInternalUpdateOnly'

# Entities
WorkItem = 'WorkItem'
Requirement = 'Requirement'
NorthStar = 'NorthStar'
KPI = 'KPI'
Category = 'Category'
ExclusionKeyword = 'ExclusionKeyword'

# Pre-compute specific
EventUId = 'EventId'
DCEntityMap = 'DCEntityMap'
Attributes = 'Attributes'
Checksum = 'Checksum'
Data = 'Data'
Verbose = 'Verbose'
CallbackLinkResponse = 'CallbackLinkResponse'


#precomputre Ignore DC type list
IGNORE_DCS = '00200030-0000-0000-0000-000000000000,00200020-0000-0000-0000-000000000000,00200020-0010-0010-0000-000000000000,00200020-0010-0020-0000-000000000000,00200020-0010-0030-0000-000000000000,00800010-0010-0010-0000-000000000000,00800010-0010-0020-0000-000000000000,00800010-0010-0030-0000-000000000000,00800010-0010-0040-0000-000000000000'



